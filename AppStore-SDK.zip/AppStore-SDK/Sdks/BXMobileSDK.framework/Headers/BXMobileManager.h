#import <Foundation/Foundation.h>
typedef NSString *BXUserInfoKey;
FOUNDATION_EXPORT BXUserInfoKey const BXUserInfoRoleServerIdKey;
FOUNDATION_EXPORT BXUserInfoKey const BXUserInfoRoleServerNameKey;
FOUNDATION_EXPORT BXUserInfoKey const BXUserInfoRoleIdKey;
FOUNDATION_EXPORT BXUserInfoKey const BXUserInfoRoleNameKey;
FOUNDATION_EXPORT BXUserInfoKey const BXUserInfoRoleLevelKey;
FOUNDATION_EXPORT BXUserInfoKey const BXUserInfoRoleGameCoinKey;
typedef NSString *BXOrderInfoKey;
FOUNDATION_EXPORT BXOrderInfoKey const BXOrderInfoProductIdKey;
FOUNDATION_EXPORT BXOrderInfoKey const BXOrderInfoProductNameKey;
FOUNDATION_EXPORT BXOrderInfoKey const BXOrderInfoProductDescriptionKey;
FOUNDATION_EXPORT BXOrderInfoKey const BXOrderInfoProductPriceKey;
FOUNDATION_EXPORT BXOrderInfoKey const BXOrderInfoOrderIDKey;
FOUNDATION_EXPORT BXOrderInfoKey const BXOrderInfoExternKey;
FOUNDATION_EXPORT BXOrderInfoKey const BXOrderInfoNotifyUrlKey;
FOUNDATION_EXPORT BXOrderInfoKey const BXOrderInfoExternProductIdKey;
FOUNDATION_EXPORT BXOrderInfoKey const BXOrderInfoExternProductPriceKey;
FOUNDATION_EXPORT NSNotificationName const BXUserLoginSuccessNotification;
FOUNDATION_EXPORT NSNotificationName const BXRegisterAppSuccessNotification;
FOUNDATION_EXPORT NSNotificationName const BXLogoutAppSuccessNotification;
typedef NS_ENUM(NSInteger, BXUserInfoReportType){
    BXUserInfoReportType_EnterGame  = 1,
    BXUserInfoReportType_LevelUp    = 2,
    BXUserInfoReportType_LogoutGame = 3,
};
@interface BXMobileManager : NSObject
@property (nonatomic, assign) BOOL enableNetworkLogging;
@property (nonatomic, readonly) NSString *appID;
@property (nonatomic, readonly) NSString *appKey;
@property (nonatomic, readonly) NSString *seriesAppId;
@property (nonatomic, readonly) NSString *seriesAppKey;
@property (nonatomic, readonly) NSString *authToken;
@property (nonatomic, readonly) BOOL appServer;
+ (instancetype)shareManager;
+ (NSString *)currentSDKVersion;
+ (void)registerAppId:(NSString *)appId appKey:(NSString *)appKey;
+ (void)registerSeriesAppId:(NSString *)appId seriesAppId:(NSString *)seriesAppId appKey:(NSString *)appKey;
- (void)login;
- (void)logout;
- (void)updateUserRoleInfo:(NSDictionary<BXUserInfoKey, id> *)roleInfo
                reportType:(BXUserInfoReportType)reportType;
- (void)makeStore:(NSDictionary<BXOrderInfoKey, id> *)orderInfo;
+ (void)bx_showButtonWindow;
+ (void)qwer_hopefulcash;
@end
