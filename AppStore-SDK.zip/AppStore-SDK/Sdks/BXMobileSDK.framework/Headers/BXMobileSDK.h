#import <Foundation/Foundation.h>
FOUNDATION_EXPORT double BXMobileSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char BXMobileSDKVersionString[];
#import <BXMobileSDK/BXMobileManager.h>
