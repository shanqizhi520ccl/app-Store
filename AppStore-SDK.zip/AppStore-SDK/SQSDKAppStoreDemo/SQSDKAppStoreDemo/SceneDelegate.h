//
//  SceneDelegate.h
//  SQSDKAppStoreDemo
//
//  Created by 史钦臣 on 2021/9/13.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

