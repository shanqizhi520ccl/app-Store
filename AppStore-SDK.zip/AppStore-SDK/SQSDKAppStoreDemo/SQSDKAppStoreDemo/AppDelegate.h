//
//  AppDelegate.h
//  SQSDKAppStoreDemo
//
//  Created by 史钦臣 on 2021/9/13.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

