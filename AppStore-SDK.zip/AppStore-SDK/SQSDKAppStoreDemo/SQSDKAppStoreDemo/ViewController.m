//
//  ViewController.m
//  BXMobileSDKDemo1
//
//  Created by 史钦臣 on 2021/8/31.
//

#import "ViewController.h"
#import <BXMobileSDK/BXMobileSDK.h>

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *roleID;
@property (weak, nonatomic) IBOutlet UITextField *roleName;
@property (weak, nonatomic) IBOutlet UITextField *level;
@property (weak, nonatomic) IBOutlet UITextField *corn;
@property (weak, nonatomic) IBOutlet UITextField *zoneID;
@property (weak, nonatomic) IBOutlet UITextField *zoneName;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // 初始化
    [BXMobileManager registerAppId:@"X36" appKey:@"bac1da6c87ee026bea64f059680ac95a"];
//     系列初始化
//    [BXMobileManager registerSeriesAppId:@"X36" appKey:@"bac1da6c87ee026bea64f059680ac95a"];
    
    // 监听登录结果
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(loginSuccessNotification:)
                                                 name:BXUserLoginSuccessNotification
                                               object:nil];

    // 监听初始化结果
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(registerAppSuccessNotification:)
                                                 name:BXRegisterAppSuccessNotification
                                               object:nil];

    // 监听退出登录
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(logoutAppSuccessNotification:)
                                                 name:BXLogoutAppSuccessNotification
                                               object:nil];
}

-(void)loginSuccessNotification:(NSNotification *)notification{
    NSDictionary *result = (NSDictionary *)notification.object;
    NSLog(@"登录成功 可开启悬浮窗 result = %@", result);
    // your own code .....
    [BXMobileManager bx_showButtonWindow];
}


-(void)registerAppSuccessNotification:(NSNotification *)notification{
    NSLog(@"--初始化完成回调-- %@", notification.object);
    //注意: 必须在初始化成功后调用
    if ([BXMobileManager shareManager].appServer) {
        // 游戏正式服处理逻辑
    }else{
        // 游戏审核服处理逻辑
    }
}

-(void)logoutAppSuccessNotification:(NSNotification *)notification{
    NSLog(@"--登出完成回调-- %@", notification.object);
}


#pragma mark --- 登录 ---
- (IBAction)login:(UIButton *)sender {
    [[BXMobileManager shareManager] login];
}

- (IBAction)updateRoleInfo:(UIButton *)sender {
    NSDictionary * userInfo = @{
        BXUserInfoRoleServerIdKey: self.zoneID.text,
        BXUserInfoRoleServerNameKey: self.zoneName.text,
        BXUserInfoRoleIdKey: self.roleID.text,
        BXUserInfoRoleNameKey: self.roleName.text,
        BXUserInfoRoleLevelKey: self.level.text,
        BXUserInfoRoleGameCoinKey: @(self.corn.text.intValue),
    };

    switch (sender.tag) {
        //进入游戏
        case 100:
            [[BXMobileManager shareManager] updateUserRoleInfo:userInfo reportType:BXUserInfoReportType_EnterGame];
            break;
        //角色升级
        case 101:
            [[BXMobileManager shareManager] updateUserRoleInfo:userInfo reportType:BXUserInfoReportType_LevelUp];
            break;
        //退出游戏
        case 102:
            [[BXMobileManager shareManager] updateUserRoleInfo:userInfo reportType:BXUserInfoReportType_LogoutGame];
            break;
    }
}


#pragma mark --- 支付购买 ---
- (IBAction)pay:(id)sender {
    NSDictionary *orderInfo = @{
        BXOrderInfoProductNameKey:@"60灵玉",//产品描述
        BXOrderInfoProductDescriptionKey:@"购买后，获得60灵玉", //产品描述
        BXOrderInfoOrderIDKey:[self randomOrder], //CP订单号
        BXOrderInfoExternKey:@"extension|data|test",//游戏自定义数据，充值成功，回调游戏服的时候，会原封不动返回,
        BXOrderInfoNotifyUrlKey:@"http://www.game.com/pay/callback",//支付成功，Server异步通知该地址，告诉游戏服务器发货
        //内购ID和内购价格
        BXOrderInfoProductIdKey:@"com.hysj.xy.shenyinggd.1",//内购ID
        BXOrderInfoProductPriceKey:@600,//6元(单位分), 必须是内购商品对应的金额

        //第三方支付时，CP后台定义的产品id和产品价格，非必须，如果不传则默认取内购ID和内购价格
        BXOrderInfoExternProductIdKey:@"id_from_server",//CP后台定义的产品id
        BXOrderInfoExternProductPriceKey:@600,//6元(单位分)
    };

    [[BXMobileManager shareManager] makeStore:orderInfo];
}

-(NSString *)randomOrder{
    NSString *string = [[NSString alloc]init];
    for (int i = 0; i < 32; i++) {
        int number = arc4random() % 36;
        if (number < 10) {
            int figure = arc4random() % 10;
            NSString *tempString = [NSString stringWithFormat:@"%d", figure];
            string = [string stringByAppendingString:tempString];
        }else {
            int figure = (arc4random() % 26) + 97;
            char character = figure;
            NSString *tempString = [NSString stringWithFormat:@"%c", character];
            string = [string stringByAppendingString:tempString];
        }
    }
    return string;
}

#pragma mark --- 退出登录 ---
- (IBAction)loginOut:(UIButton *)sender {
    [[BXMobileManager shareManager] logout];
}


- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}


@end
