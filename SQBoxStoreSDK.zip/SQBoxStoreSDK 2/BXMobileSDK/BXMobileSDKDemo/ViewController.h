//
//  ViewController.h
//  BXMobileSDKDemo
//
//  Created by BD-Benjamin on 2020/7/13.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

