//
//  BXMobileSDK.h
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/2.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for BXMobileSDK.
FOUNDATION_EXPORT double BXMobileSDKVersionNumber;

//! Project version string for BXMobileSDK.
FOUNDATION_EXPORT const unsigned char BXMobileSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BXMobileSDK/PublicHeader.h>
#import <BXMobileSDK/BXMobileManager.h>
