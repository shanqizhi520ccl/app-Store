//
//  BXMobileManager.m
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/2.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXMobileManager.h"
#import "BXMobileManager+Private.h"
#import "BXEvent.h"
#import "BXKeychain.h"
#import "BXIpaManager.h"
#import "BXConfig.h"

#import "BXThreeSelectionController.h"
#import "BXPrivacyUtil.h"

#import "BXDrawWindowButton.h"
#import "BXMyInfoController.h"
#import "BXAddHeartbeatManager.h"
#import "BXPrivacyWebController.h"

#import "NSString+BXExtern.h"

//区服ID
BXUserInfoKey const BXUserInfoRoleServerIdKey = @"BXUserInfoRoleServerIdKey";
//区服名称
BXUserInfoKey const BXUserInfoRoleServerNameKey = @"BXUserInfoRoleServerNameKey";
//角色ID
BXUserInfoKey const BXUserInfoRoleIdKey = @"BXUserInfoRoleIdKey";
//角色名称
BXUserInfoKey const BXUserInfoRoleNameKey = @"BXUserInfoRoleNameKey";
//角色等级
BXUserInfoKey const BXUserInfoRoleLevelKey = @"BXUserInfoRoleLevelKey";
//角色游戏币
BXUserInfoKey const BXUserInfoRoleGameCoinKey = @"BXUserInfoRoleGameCoinKey";

//商品ID
BXOrderInfoKey const BXOrderInfoProductIdKey = @"BXOrderInfoProductIdKey";
//商品名称
BXOrderInfoKey const BXOrderInfoProductNameKey = @"BXOrderInfoProductNameKey";
//商品名称
BXOrderInfoKey const BXOrderInfoProductDescriptionKey = @"BXOrderInfoProductDescriptionKey";
//商品价格（单位分）
BXOrderInfoKey const BXOrderInfoProductPriceKey = @"BXOrderInfoProductPriceKey";
//CP订单号
BXOrderInfoKey const BXOrderInfoOrderIDKey = @"BXOrderInfoOrderIDKey";
//CP下单透传参数
BXOrderInfoKey const BXOrderInfoExternKey = @"BXOrderInfoExternKey";
//返回地址
BXOrderInfoKey const BXOrderInfoNotifyUrlKey = @"BXOrderInfoNotifyUrlKey";
//扩展商品ID (非必须，string类型)
BXOrderInfoKey const BXOrderInfoExternProductIdKey = @"BXOrderInfoExternProductIdKey";
//扩展商品价格（非必须，number类型, 单位分)
BXOrderInfoKey const BXOrderInfoExternProductPriceKey = @"BXOrderInfoExternProductPriceKey";

//注册成功通知
NSNotificationName const BXUserLoginSuccessNotification = @"BXUserLoginSuccessNotification";
NSNotificationName const BXRegisterAppSuccessNotification = @"BXRegisterAppSuccessNotification";
NSNotificationName const BXLogoutAppSuccessNotification = @"BXLogoutAppSuccessNotification";

#pragma mark - SDK Manager

@interface BXMobileManager ()

@property (nonatomic, strong, readwrite) BXUser *currentUser;
@property (nonatomic, strong, readwrite) NSString *appID;
@property (nonatomic, strong, readwrite) NSString *appKey;
@property (nonatomic, strong, readwrite) NSString *seriesAppId;
@property (nonatomic, strong, readwrite) NSString *seriesAppKey;
@property (nonatomic, weak, readwrite) BXLoginViewController *authViewController;

@end

@implementation BXMobileManager

static BXMobileManager *__manager = nil;

/// 获取BXMobileManager实例对象
+ (instancetype)shareManager {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        __manager = [[BXMobileManager alloc] init];
    });
    return __manager;
}

+ (void)load {
#ifdef DEBUG
    [BXLogger setLogLevel:BXLogLevelVerbose];
#else
    [BXLogger setLogLevel:BXLogLevelInfo];
#endif
}

- (void)setEnableNetworkLogging:(BOOL)enableNetworkLogging{
    _enableNetworkLogging = enableNetworkLogging;
    if (!enableNetworkLogging) {
        [BXLogger setLogLevel:BXLogLevelOff];
    }else{
        [BXLogger setLogLevel:BXLogLevelInfo];
    }
}

- (NSString *)authToken {
    return self.currentUser.token;
}

- (BOOL)appServer {
    return [BXConfig config].appServer;
}

+ (NSString *)currentSDKVersion {
    return [BXConfig config].sdkVersion;
}

+ (NSString *)base64HostString {
    return @"aHR0cDovL2FwaS42Mnd5LmNvbS8=";
}

+ (NSString *)basePlatformURL {
//    NSData *data1 = [[NSData alloc]initWithBase64EncodedString:@"aHR0cDovL2FwaS42Mnd5LmNvbS8=" options:0];
//    NSString *hostString = [[NSString alloc]initWithData:data1 encoding: NSUTF8StringEncoding];
    return @"http://test-api.917youxi.com/";
}

+ (void)registerAppId:(NSString *)appId appKey:(NSString *)appKey {
    NSAssert(appId != nil, @"初始化失败，appId不能为空");
    NSAssert(appKey != nil, @"初始化失败，appKey不能为空");
    BXLogInfo(@"调起初始化");
    
    [BXMobileManager shareManager].appID = appId;
    [BXMobileManager shareManager].appKey = appKey;
    
    [BXEvent bx_doConfig:^(id obj, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [BXMBProgressHUD bx_showMessage:@"初始化成功"];
            [BXMobileManager showBXPrivacyWebControllerWithAction];
            [BXMobileManager showDevicePrivacyViewWithAction];
        });
    }];
    
    NSDictionary *dict = [[NSBundle mainBundle] infoDictionary];
    BXLogInfo(@"调起初始化 dict = %@", dict);
}

+ (void)showBXPrivacyWebControllerWithAction{
    //判断是否弹出协议
    BOOL isNeedShowPrivacy = [[BXConfig config] isNeedShowProtocol];
    if (isNeedShowPrivacy) {
        BXPrivacyWebController *vc = [[BXPrivacyWebController alloc] init];
        vc.urlStr = [BXPrivacyUtil privacyWebUrl];
        vc.modalPresentationStyle = UIModalPresentationCustom;
        vc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        vc.WebBtnCallback = ^(BOOL agreed) {
            if (!agreed) {
                [BXPrivacyUtil bx_exitApplication];
                return;
            }
            [[BXConfig config] agreedSync];
            [BXMobileManager showDevicePrivacyViewWithAction];
        };
        [[BXPrivacyUtil bx_currentController] presentViewController:vc animated:NO completion:nil];
        return;
    }
}

+ (void)showDevicePrivacyViewWithAction{
    if ([BXPrivacyUtil bx_isNeedShowbx_devicePrivacy] == YES && [BXConfig config].grcAuthorityDerail == 1){
        BXThreeSelectionController *selectionVC = [[BXThreeSelectionController alloc] init];
        selectionVC.bx_Status = 0;
        [selectionVC bx_presentWithViewController:nil];
    }
}

+ (void)registerSeriesAppId:(NSString *)appId  seriesId:(NSString *)seriesId appKey:(NSString *)appKey {
    NSAssert(appId != nil, @"系列初始化失败，appId不能为空");
    NSAssert(appKey != nil, @"系列初始化失败，appKey不能为空");
    NSAssert(seriesId != nil, @"系列初始化失败，seriesId不能为空");
    BXLogInfo(@"调起系列初始化");
    
    [BXConfig config].isSeries = YES;
    
    [BXMobileManager shareManager].appID = appId;
    [BXMobileManager shareManager].appKey = appKey;
    [BXMobileManager shareManager].seriesAppId = seriesId;
    [BXMobileManager shareManager].seriesAppKey = appKey;
    
    [BXEvent bx_doConfig:^(id obj, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [BXMBProgressHUD bx_showMessage:@"初始化成功"];
            [BXMobileManager showBXPrivacyWebControllerWithAction];
            [BXMobileManager showDevicePrivacyViewWithAction];
        });
    }];
}

- (void)login {
    BXLogInfo(@"调起登录");
    
    BXLoginViewController *authViewConroller = [[BXLoginViewController alloc] init];
    [authViewConroller bx_presentWithViewController:nil];
    self.authViewController = authViewConroller;
}

- (void)logout {
    BXLogInfo(@"注销退出");
    if (self.authViewController) {
        [self.authViewController bx_dismissPresentedViewController:self.authViewController completionBlock:^{
        }];
    }
    
    [BXEvent bx_doLogout:^(id obj, NSError *error) {
        if (!error) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [BXMBProgressHUD bx_showMessage:@"账号注销成功"];
                [BXMobileManager bx_dissmissButtonWindow];
                [BXUser setAutoLogin:NO];
            });
        }
        [[BXAddHeartbeatManager sharedInstance] stop];
        [[NSNotificationCenter defaultCenter] postNotificationName:BXLogoutAppSuccessNotification object:@{}];
        
        self.currentUser = nil;
        self.authViewController = nil;
    }];
}

- (void)updateUserRoleInfo:(NSDictionary *)roleInfo reportType:(BXUserInfoReportType)type {
    NSAssert(roleInfo != nil, @"更新角色信息失败，[-updateUserInfo:type]参数#roleInfo不能为空");
    NSAssert(self.currentUser != nil, @"更新角色信息失败，还没有登录，请先登录再调用");
    
    NSString *zoneId = roleInfo[BXUserInfoRoleServerIdKey];
    NSString *zoneName = roleInfo[BXUserInfoRoleServerNameKey];
    NSString *roleId = roleInfo[BXUserInfoRoleIdKey];
    NSString *roleLevel = roleInfo[BXUserInfoRoleLevelKey];
    NSString *roleName = roleInfo[BXUserInfoRoleNameKey];
    NSNumber *gameCoin = roleInfo[BXUserInfoRoleGameCoinKey];
    
    // 检查参数是否传入
    NSAssert(roleId != nil, @"更新角色信息失败，[-updateUserInfo:type]参数#BXUserInfoRoleIdKey不能为空");
    NSAssert(roleLevel != nil, @"更新角色信息失败，[-updateUserInfo:type]参数#BXUserInfoRoleLevelKey不能为空");
    NSAssert(roleName != nil, @"更新角色信息失败，[-updateUserInfo:type]参数#BXUserInfoRoleNameKey不能为空");
    NSAssert(zoneId != nil, @"更新角色信息失败，[-updateUserInfo:type]参数#BXUserInfoRoleServerIdKey不能为空");
    NSAssert(zoneName != nil, @"更新角色信息失败，[-updateUserInfo:type]参数#BXUserInfoRoleServerNameKey不能为空");
    
    self.currentUser.zoneId = zoneId;
    self.currentUser.zoneName = zoneName;
    self.currentUser.roleId = roleId;
    self.currentUser.roleName = roleName;
    self.currentUser.roleLevel = roleLevel;
    if (gameCoin) {
        self.currentUser.gameCoin = gameCoin.integerValue;
    }
    
    [self.currentUser save];

    [BXEvent bx_doSyncData:type
                  gameCoin:gameCoin
                    roleId:roleId
                 roleLevel:roleLevel
                  roleName:roleName
                    zoneId:zoneId
                  zoneName:zoneName
                complement:^(id obj, NSError *error) {
        if (!error) {
            switch (type) {
                case BXUserInfoReportType_EnterGame:
                    BXLogInfo(@"进入游戏成功");
                    break;
                case BXUserInfoReportType_LevelUp:
                    BXLogInfo(@"角色升级成功");
                    break;
                case BXUserInfoReportType_LogoutGame:
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [BXMBProgressHUD bx_showMessage:@"退出游戏成功"];
                    });
                    break;
                    
                default:
                    break;
            }
        }
    }];
}

- (void)makeStore:(NSDictionary<BXOrderInfoKey,id> *)orderInfo {
    NSAssert(orderInfo != nil, @"[-makeStore:] 购买失败，参数#orderInfo不能为空");
    NSAssert(self.currentUser != nil, @"[-makeStore:] 购买失败，还没有登录，请先登录再调用");

    NSString *abbey = orderInfo[BXOrderInfoOrderIDKey];
    NSString *extension = orderInfo[BXOrderInfoExternKey];
    NSString *notifyUrl = orderInfo[BXOrderInfoNotifyUrlKey];
    NSString *productDesc = orderInfo[BXOrderInfoProductDescriptionKey];
    NSString *productId = orderInfo[BXOrderInfoProductIdKey];
    NSString *productName = orderInfo[BXOrderInfoProductNameKey];
    NSNumber *talks = orderInfo[BXOrderInfoProductPriceKey];
    
    // 检查参数是否传入
    NSAssert(abbey != nil, @"[-makeStore:] 购买失败，缺少参数:BXOrderInfoOrderIDKey");
    NSAssert(extension != nil, @"[-makeStore:] 购买失败，缺少参数:BXOrderInfoExternKey");
    NSAssert(notifyUrl != nil, @"[-makeStore:] 购买失败，缺少参数:BXOrderInfoNotifyUrlKey");
    NSAssert(productDesc != nil, @"[-makeStore:] 购买失败，缺少参数:BXOrderInfoProductDescriptionKey");
    NSAssert(productId != nil, @"[-makeStore:] 购买失败，缺少参数:BXOrderInfoProductIdKey");
    NSAssert(productName != nil, @"[-makeStore:] 购买失败，缺少参数:BXOrderInfoProductNameKey");
    NSAssert(talks != nil, @"[-makeStore:] 缺少参数:BXOrderInfoProductPriceKey");
    
    NSAssert(self.currentUser.zoneId != nil , @"[-makeStore:] 购买失败, 未查询到角色信息，请先调用-updateUserRoleInfo:reportType:更新角色信息");
    NSAssert(self.currentUser.zoneName != nil, @"[-makeStore:] 购买失败，未查询到区服名, 请先调用-updateUserRoleInfo:reportType:更新角色信息");
    NSAssert(self.currentUser.roleId != nil, @"[-makeStore:] 购买失败，未查询到角色ID, 请先调用-updateUserRoleInfo:reportType:更新角色信息");
    NSAssert(self.currentUser.roleName != nil, @"[-makeStore:] 购买失败，未查询到角色名, 请先调用-updateUserRoleInfo:reportType:更新角色信息");
    
    [[BXIpaManager sharedObject] makeStore:orderInfo];
}

+ (void)bx_dissmissButtonWindow{
    [[BXDrawWindowButton sharedInstance] bx_dissmissButtonWindow];
}

+ (void)bx_showButtonWindow{
    [[BXDrawWindowButton sharedInstance] bx_showButtonWindow];
    [BXDrawWindowButton sharedInstance].itemClickBlock = ^(NSInteger index) {
        [[BXMobileManager shareManager] infoCenter];
    };
}

- (void)infoCenter {
    BXLogInfo(@"调起用户中心");
    NSAssert(self.currentUser != nil, @"更新角色信息失败，还没有登录，请先登录再调用");
    
    BXMyInfoController *authViewConroller = [[BXMyInfoController alloc] init];
    [authViewConroller bx_presentWithViewController:nil];
}

@end

