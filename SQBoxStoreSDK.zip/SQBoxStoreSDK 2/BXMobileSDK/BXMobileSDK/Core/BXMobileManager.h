//
//  BXMobileManager.h
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/2.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import <Foundation/Foundation.h>

//NS_ASSUME_NONNULL_BEGIN

typedef NSString *BXUserInfoKey;

/// Role info key. 用于更新用户角色信息
//区服ID (必须，string类型)
FOUNDATION_EXPORT BXUserInfoKey const BXUserInfoRoleServerIdKey;
//区服名称 (必须，string类型)
FOUNDATION_EXPORT BXUserInfoKey const BXUserInfoRoleServerNameKey;
//角色ID (必须，string类型)
FOUNDATION_EXPORT BXUserInfoKey const BXUserInfoRoleIdKey;
//角色名称 (必须，string类型)
FOUNDATION_EXPORT BXUserInfoKey const BXUserInfoRoleNameKey;
//角色等级 (必须，string类型)
FOUNDATION_EXPORT BXUserInfoKey const BXUserInfoRoleLevelKey;
//角色游戏币 (非必须，numble类型)
FOUNDATION_EXPORT BXUserInfoKey const BXUserInfoRoleGameCoinKey;

/// Order info key. 用于在应用内发起一个内购请求.
typedef NSString *BXOrderInfoKey;

//商品ID (必须，string类型)
FOUNDATION_EXPORT BXOrderInfoKey const BXOrderInfoProductIdKey;
//商品名称 (必须，string类型)
FOUNDATION_EXPORT BXOrderInfoKey const BXOrderInfoProductNameKey;
//商品名称 (必须，string类型)
FOUNDATION_EXPORT BXOrderInfoKey const BXOrderInfoProductDescriptionKey;
//商品价格（必须，number类型, 单位分）
FOUNDATION_EXPORT BXOrderInfoKey const BXOrderInfoProductPriceKey;
//CP订单号 (必须，string类型)
FOUNDATION_EXPORT BXOrderInfoKey const BXOrderInfoOrderIDKey;
//CP下单透传参数 (必须，string类型)
FOUNDATION_EXPORT BXOrderInfoKey const BXOrderInfoExternKey;
//返回地址  (必须，string类型)
FOUNDATION_EXPORT BXOrderInfoKey const BXOrderInfoNotifyUrlKey;
//扩展商品ID (非必须，string类型)
FOUNDATION_EXPORT BXOrderInfoKey const BXOrderInfoExternProductIdKey;
//扩展商品价格（非必须，number类型, 单位分）
FOUNDATION_EXPORT BXOrderInfoKey const BXOrderInfoExternProductPriceKey;

/// Notification key for login success. 用于监听用户登陆，登陆成功后会发送通知
FOUNDATION_EXPORT NSNotificationName const BXUserLoginSuccessNotification;

/// Notification key for register app success. 用于监听初始化，初始化成功后会发送通知
FOUNDATION_EXPORT NSNotificationName const BXRegisterAppSuccessNotification;

/// Notification key for register app success. 用于监听登出通知
FOUNDATION_EXPORT NSNotificationName const BXLogoutAppSuccessNotification;

typedef NS_ENUM(NSInteger, BXUserInfoReportType){
    // 进入游戏时，上报角色信息
    BXUserInfoReportType_EnterGame  = 1,
    // 角色升级时，上报角色信息
    BXUserInfoReportType_LevelUp    = 2,
    // 退出游戏时，上报角色信息
    BXUserInfoReportType_LogoutGame = 3,
};// 上报角色信息类型

/**
*  SDK Manager.
*/
@interface BXMobileManager : NSObject

/**
 *  Flag to enable extra network logging. Setting this to YES will log debug info via BXMobileSDK.
 */
@property (nonatomic, assign) BOOL enableNetworkLogging;

/**
*  appID.
*/
@property (nonatomic, readonly) NSString *appID;

/**
*  appKey.
*/
@property (nonatomic, readonly) NSString *appKey;

/**
*  series appId.
*/
@property (nonatomic, readonly) NSString *seriesAppId;

/**
*  series appKey.
*/
@property (nonatomic, readonly) NSString *seriesAppKey;

/**
*  The authentication token when user login.
*/
@property (nonatomic, readonly) NSString *authToken;


@property (nonatomic, readonly) BOOL appServer;

/**
 *  SDK singleton.
 */
+ (instancetype)shareManager;

/**
 *  The current version of the SDK.
 */
+ (NSString *)currentSDKVersion;

/**
 * SDK initialize.
 * @param appId 渠道分配 appId
 * @param appKey 渠道分配 appKey
 */
+ (void)registerAppId:(NSString *)appId appKey:(NSString *)appKey;

/**
 * SDK series initialize.
 * @param appId 渠道分配 appId
 * @param seriesId 系列id seriesId
 * @param appKey 渠道分配 appKey
*/
+ (void)registerSeriesAppId:(NSString *)appId seriesId:(NSString *)seriesId appKey:(NSString *)appKey;

/**
 *  call it when user need login.
 */
- (void)login;

/**
 * call it when user need login.
 */
- (void)logout;

/**
 * Update user role info.
 * @param roleInfo  游戏角色信息，key参见 BXUserInfoKey
 *  BXUserInfoRoleIdKey: 角色ID  (必须，string类型)
 *  BXUserInfoRoleNameKey: 角色名称  ( 必须，string类型)
 *  BXUserInfoRoleLevelKey: 角色等级  (必须，string类型)
 *  BXUserInfoRoleServerIdKey: 区服ID ,  (必须，string类型)
 *  BXUserInfoRoleServerNameKey: 区服名称,  (必须，string类型)
 *  BXUserInfoRoleGameCoinKey: 游戏币,  (非必须，number类型)
 * @param reportType 上报类型
 */
- (void)updateUserRoleInfo:(NSDictionary<BXUserInfoKey, id> *)roleInfo
                reportType:(BXUserInfoReportType)reportType;

/**
 * in ap.
 * @param orderInfo 内购订单信息，key参见 BXOrderInfoKey.
 * BXOrderInfoProductIdKey  商品ID (必须，string类型)
 * BXOrderInfoProductNameKey 商品名称 (必须，string类型)
 * BXOrderInfoProductDescriptionKey 商品名称 (必须，string类型)
 * BXOrderInfoProductPriceKey 商品价格，单位分（必须，number类型, 单位分）
 * BXOrderInfoOrderIDKey CP订单号 (必须，string类型)
 * BXOrderInfoExternKey CP下单透传参数 (必须，string类型)
 * BXOrderInfoNotifyUrlKey  返回地址  (必须，string类型)
 * BXOrderInfoExternProductIdKey  扩展商品ID (非必须，string类型)
 * BXOrderInfoExternProductPriceKey 扩展商品价格，单位分 (非必须，number类型)
 */
- (void)makeStore:(NSDictionary<BXOrderInfoKey, id> *)orderInfo;

// 悬浮窗显示（可选）
+ (void)bx_showButtonWindow;

// 悬浮窗隐藏（可选）
+ (void)bx_dissmissButtonWindow;

@end

//NS_ASSUME_NONNULL_END
