//
//  BXKeychain.h
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/8/2.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import <Foundation/Foundation.h>

//NS_ASSUME_NONNULL_BEGIN

/// 用户登陆成功通知
FOUNDATION_EXPORT NSString * const kBXKeychainAccountKey;
FOUNDATION_EXPORT NSString * const kBXKeychainTokenServiceKey;
FOUNDATION_EXPORT NSString * const kBXKeychainPasswordServiceKey;
FOUNDATION_EXPORT NSString * const kBXKeychainUUIDServiceKey;

FOUNDATION_EXPORT NSString * const kBXDefaultsAccountsServiceKey;
FOUNDATION_EXPORT NSString * const kBXDefaultsRolesServiceKey;

@interface BXKeychain : NSObject

+ (NSString *)bx_keychainItemForService:(nonnull NSString *)serviceKey;
+ (void)bx_setKeychainItem:(nullable NSString *)item forServiceKey:(nonnull NSString *)serviceKey;

@end

//NS_ASSUME_NONNULL_END
