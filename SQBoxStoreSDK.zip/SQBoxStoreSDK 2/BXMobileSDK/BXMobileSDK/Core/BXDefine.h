//
//  BXDefine.h
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/13.
//  Copyright © 2020 Gavin. All rights reserved.
//

#ifndef BXDefine_h
#define BXDefine_h

#pragma mark - LOG DEFINE

#ifdef DEBUG
#define BXDebug
#endif

#ifdef BXDebug
//#define BXLog(format, ...) NSLog((@"[Function: %s]\n " format), __FUNCTION__, ## __VA_ARGS__)
#define BXLog(format, ...) NSLog((@"%s [Line %d] \n" format), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__)
#else
#define BXLog(format, ...)
#endif

#pragma mark - BUNDLE DEFINE

#define BXMobileSDKBundle_Name           @"BXMobileSDK.bundle"
#define BXMobileSDKBundle_Path           [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:BXMobileSDKBundle_Name]
#define BXMobileSDKBundle                [NSBundle bundleWithPath:BXMobileSDKBundle_Path]
#define BXMobileSDKBundle_File(name)     (NSString *)[BXMobileSDKBundle_Path stringByAppendingPathComponent:name]

#define BX_APP_VERSION      [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"]
#define BX_BUILD_VERSION    [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleVersion"]
#define BX_DISPLAY_NAME     [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleDisplayName"]
#define BX_BUNDLE_NAME      [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleName"]
#define BX_BUNDLE_ID        [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleIdentifier"]

#pragma mark - FONT DEFINE

#define BXSystemFont(size)                  [UIFont systemFontOfSize:size]
#define BXBoldSystemFont(size)              [UIFont boldSystemFontOfSize:size]

#pragma mark - COLOR DEFINE

//color with r g b alpha
#define BXRGBAColor(r, g, b, a)      [UIColor colorWithRed:((r) / 255.0) green:((g) / 255.0) blue:((b) / 255.0) alpha:(a)]
#define BXRGBColor(r, g, b)          BXRGBAColor(r, g, b, 1.0)

//color with hex and alpha
#define BXHexAColor(hex, a)          [UIColor colorWithRed:((float)((hex & 0xFF0000) >> 16))/255.0 green:((float)((hex & 0xFF00) >> 8))/255.0 blue:((float)(hex & 0xFF))/255.0 alpha:(a)]
#define BXHexColor(hex)              BXHexAColor(hex, 1.0)
#define BXWhiteAColor(w, a)          [UIColor colorWithWhite:w alpha:a]

#define BXNavgationBackgroundColor   BXHexColor(0x61D1AD)
#define BXBackgroundColor            BXHexColor(0xFFFFFF)
#define BXTextFieldBackgroundColor   BXHexColor(0xF2F3F7)
#define BXTextFieldTextColor         BXHexColor(0x767b82)
#define BXTextFieldPlaceHolderColor  BXHexColor(0x999999)
#define BXSectionBackgroundColor     BXHexColor(0xF9F9F9)
#define BXMainColor   BXHexColor(0x388EFF)

#define BXCornerRadius 8

#pragma mark - SERVER DEFINE

//竖屏幕宽高
#define ScreenWidth ([UIScreen mainScreen].bounds.size.width)
#define ScreenHeight ([UIScreen mainScreen].bounds.size.height)

#define isSmallScreen  (ScreenWidth <= 338 || ScreenHeight <=  338 )

//视图框Size
#define BXPreferredContentSize  CGSizeMake(338, 250)
#define BXPreferredContentSmallSize  CGSizeMake(290, 250)

#define BX_API_VERSION  @"1.0"  //api version
#define BX_API_VERSION_FOR_INIT  @"1.1"  //api version
#define BX_MC_ID        @"M0"  //api version
#define BX_SC_ID        @"M0_S0"  //api version
#define BX_DEVICE_TYPE  2  //device type
#define BX_CEDAR        1
#define BX_BRAND        @"Apple"
#define BX_PRODUCER     @"Apple"
#define BX_USER_FROM    @"mobile"

#endif /* BXDefine_h */
