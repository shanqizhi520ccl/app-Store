//
//  BXKeychain.m
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/8/2.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXKeychain.h"

NSString * const kBXKeychainAccountKey = @"com.gavin.BXMobileSDK";
NSString * const kBXKeychainTokenServiceKey = @"com.gavin.BXMobileSDK.api_token";
NSString * const kBXKeychainPasswordServiceKey = @"com.gavin.BXMobileSDK.api_pwd";
NSString * const kBXKeychainUUIDServiceKey = @"com.gavin.BXMobileSDK.api_uuid";

NSString * const kBXDefaultsAccountsServiceKey = @"com.gavin.BXMobileSDK.accounts";

@implementation BXKeychain

+ (NSString *)bx_keychainItemForService:(NSString *)serviceKey{
    return [self keychainItemForService:serviceKey returnNilIfEmpty:YES];
}

+ (NSString *)keychainItemForService:(NSString *)serviceKey returnNilIfEmpty:(BOOL)returnNilIfEmpty
{
    id account = kBXKeychainAccountKey;
    id service = serviceKey;
    
#if !BX_TARGET_OSX
    account = [account dataUsingEncoding:NSUTF8StringEncoding];
    service = [service dataUsingEncoding:NSUTF8StringEncoding];
#endif
    
    NSMutableDictionary *dictionary = [NSMutableDictionary dictionary];
    dictionary[(__bridge id)kSecClass] = (__bridge id)kSecClassGenericPassword;
    dictionary[(__bridge id)kSecAttrAccount] = account;
    dictionary[(__bridge id)kSecAttrService] = service;
    dictionary[(__bridge id)kSecMatchLimit] = (__bridge id)kSecMatchLimitOne;
    dictionary[(__bridge id)kSecReturnData] = (__bridge id)kCFBooleanTrue;
    
    CFTypeRef cfResult = NULL;
    OSStatus status = SecItemCopyMatching((__bridge CFDictionaryRef)dictionary, &cfResult);
    
    if (status == errSecSuccess && cfResult != NULL){
        NSData *result = (__bridge_transfer NSData *)cfResult;
        NSString *resultString = [[NSString alloc] initWithData:result encoding:NSUTF8StringEncoding];

        if (returnNilIfEmpty){
            return resultString.length > 0 ? resultString : nil;
        }
        return resultString;
    }
    return nil;
}

+ (void)bx_setKeychainItem:(NSString *)item forServiceKey:(NSString *)serviceKey
{
    id account = kBXKeychainAccountKey;
    id service = serviceKey;
    
#if !BX_TARGET_OSX
    account = [account dataUsingEncoding:NSUTF8StringEncoding];
    service = [service dataUsingEncoding:NSUTF8StringEncoding];
#endif
    
    NSMutableDictionary *existingItemDictionary = [NSMutableDictionary dictionary];
    
    existingItemDictionary[(__bridge id)kSecClass] = (__bridge id)kSecClassGenericPassword;
    existingItemDictionary[(__bridge id)kSecAttrAccount] = account;
    existingItemDictionary[(__bridge id)kSecAttrService] = service;
    
    NSString *oldItem = [self keychainItemForService:serviceKey returnNilIfEmpty:NO];
    if (item == nil){
        if (oldItem != nil){
            SecItemDelete((__bridge CFDictionaryRef)existingItemDictionary);
        }
    }else{
        NSData *itemData = [item dataUsingEncoding:NSUTF8StringEncoding];
        if (oldItem != nil) {
            NSMutableDictionary *updateDictionary = [NSMutableDictionary dictionary];
            updateDictionary[(__bridge id)kSecValueData] = itemData;
            (void)SecItemUpdate((__bridge CFDictionaryRef)existingItemDictionary, (__bridge CFDictionaryRef)updateDictionary);
        }else{
            existingItemDictionary[(__bridge id)kSecValueData] = itemData;
            (void)SecItemAdd((__bridge CFDictionaryRef)existingItemDictionary, NULL);
        }
    }
}


@end
