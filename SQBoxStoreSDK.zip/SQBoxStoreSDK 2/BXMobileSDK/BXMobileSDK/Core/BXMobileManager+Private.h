//
//  BXMobileManager+Private.h
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/8/1.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXMobileManager.h"
#import "BXLoginViewController.h"
#import "BXUser.h"

//NS_ASSUME_NONNULL_BEGIN

@interface BXMobileManager (Private)

/// app id
@property (nonatomic, strong, readwrite) NSString *appID;

/// app key
@property (nonatomic, strong, readwrite) NSString *appKey;

/// 系列包 app id
@property (nonatomic, strong, readwrite) NSString *seriesAppId;

/// 系列包 app key
@property (nonatomic, strong, readwrite) NSString *seriesAppKey;

/// The current session, if active. Will be nil if the user has not authenticated.
@property (nonatomic, strong, readwrite) BXUser *currentUser;

/// auth page.
@property (nonatomic, weak, readwrite) BXLoginViewController *authViewController;

/// Server URL
+ (NSString *)basePlatformURL;

@end

//NS_ASSUME_NONNULL_END
