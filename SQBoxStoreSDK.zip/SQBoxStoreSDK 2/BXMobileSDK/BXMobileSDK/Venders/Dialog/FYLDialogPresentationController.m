

static NSString *const FYLDialogPresentationControllerTapMaskNotification = @"FYLDialogPresentationControllerTapMaskNotification";

#import "FYLDialogPresentationController.h"

#pragma mark -
@interface FYLDialogTransitionCoordinator : NSObject <UIViewControllerTransitionCoordinator>
@property (nonatomic, strong, readonly) NSMutableArray * animationBlocks;
@property (nonatomic, strong, readonly) NSMutableArray * completionBlocks;
@property (nonatomic, weak, readonly) FYLDialogPresentationController * presentationController;
- (instancetype)initWithDialogPresentationController:(FYLDialogPresentationController *)pc;
- (instancetype)init __unavailable;
@end

@interface FYLDialogTransitionCoordinator ()
@property (nonatomic, strong) NSMutableArray * animationBlocks;
@property (nonatomic, strong) NSMutableArray * completionBlocks;
@property (nonatomic) BOOL completed;
@end

@implementation FYLDialogTransitionCoordinator

- (instancetype)initWithDialogPresentationController:(FYLDialogPresentationController *)pc {
    self = [super init];
    if (self) {
        _presentationController = pc;
        self.animationBlocks = [NSMutableArray array];
        self.completionBlocks = [NSMutableArray array];
    }
    return self;
}

- (BOOL)animateAlongsideTransition:(void (^)(id<UIViewControllerTransitionCoordinatorContext>))animation
                        completion:(void (^)(id<UIViewControllerTransitionCoordinatorContext>))completion {
    
    if (animation) [self.animationBlocks addObject:animation];
    if (completion) [self.completionBlocks addObject:completion];
    return YES;
}

- (BOOL)animateAlongsideTransitionInView:(UIView *)view
                               animation:(void (^)(id<UIViewControllerTransitionCoordinatorContext>))animation
                              completion:(void (^)(id<UIViewControllerTransitionCoordinatorContext>))completion {
    return NO;
}
- (void)notifyWhenInteractionEndsUsingBlock:(void (^)(id<UIViewControllerTransitionCoordinatorContext>))handler {}
- (BOOL)isInteractive { return NO; }
- (BOOL)initiallyInteractive { return NO; }
- (UIViewAnimationCurve)completionCurve {
    return UIViewAnimationCurveEaseInOut;
}
- (UIViewController *)viewControllerForKey:(NSString *)key {
    return [self.presentationController presentedViewController];
}
- (UIView *)viewForKey:(NSString *)key {
    return [self.presentationController presentedView];
}
- (CGFloat)percentComplete {
    return self.completed ? 1 : 0;
}
- (UIView *)containerView {
    return [self.presentationController containerView];
}
- (NSTimeInterval)transitionDuration {
    return .3;
}
- (BOOL)isCancelled { return NO; }
- (CGAffineTransform)targetTransform {
    return [self.presentationController presentedView].transform;
}
- (UIModalPresentationStyle)presentationStyle {
    return UIModalPresentationCustom;
}
- (BOOL)isAnimated { return YES; }
- (CGFloat)completionVelocity { return 1; }
@synthesize isInterruptible;

@end

#pragma mark -
@interface FYLDialogPresentationController ()
@property (nonatomic, strong) UIView        *maskView;
@property (nonatomic) CGSize                previousContentSize;
@end

@implementation FYLDialogPresentationController
- (instancetype)initWithPresentedViewController:(UIViewController *)presentedViewController
                       presentingViewController:(UIViewController *)presentingViewController {
    
    self = [super initWithPresentedViewController:presentedViewController
                         presentingViewController:presentingViewController];
    if (self) {
        [self loadDialogPresentationController];
    }
    return self;
}

- (void)dealloc {
}

- (void)loadDialogPresentationController {
    UIView * maskView = [UIView new];
    self.maskView = maskView;
    self.maskView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.0];
    
    UIVisualEffectView *visualEffectView;
    visualEffectView = [[UIVisualEffectView alloc] init];
    visualEffectView.effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleLight];
    [self.maskView insertSubview:visualEffectView atIndex:0];
    
    UITapGestureRecognizer * maskTapGR = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(maskViewTapped:)];
    [self.maskView addGestureRecognizer:maskTapGR];
}

- (void)presentationTransitionWillBegin {
    UIView * containerView = [self containerView];
    UIViewController * presentedViewController = [self presentedViewController];
    
    self.maskView.frame = containerView.bounds;
    self.maskView.alpha = 0;
    [containerView insertSubview:self.maskView atIndex:0];
    
    if ([presentedViewController transitionCoordinator]) {
        
        [[presentedViewController transitionCoordinator] animateAlongsideTransition:^(id<UIViewControllerTransitionCoordinatorContext> context) {
            
            self.maskView.alpha = 1.f;
        } completion:^(id<UIViewControllerTransitionCoordinatorContext> context) {}];
        
    } else {
        
        self.maskView.alpha = 1.f;
    }
}
- (void)presentationTransitionDidEnd:(BOOL)completed {
}

- (void)dismissalTransitionWillBegin {
    UIViewController * presentedViewController = [self presentedViewController];
    
    if ([presentedViewController transitionCoordinator]) {
        [[presentedViewController transitionCoordinator] animateAlongsideTransition:^(id<UIViewControllerTransitionCoordinatorContext> context) {
            self.maskView.alpha = 0;
        } completion:^(id<UIViewControllerTransitionCoordinatorContext> context) {}];
    } else {
        self.maskView.alpha = 0;
    }
}

- (CGRect)frameOfPresentedViewInContainerView {
    UIView * containerView = [self containerView];
    CGFloat kbBottomInset = 0;
    CGFloat containerUsableHeight = containerView.bounds.size.height - kbBottomInset;
    CGFloat maxDialogHeight = containerUsableHeight;
    
    UIViewController * presentedViewController = [self presentedViewController];
    CGSize preferredSize = [presentedViewController preferredContentSize];
    if (preferredSize.width == 0) preferredSize.width = 300.f;
    if (preferredSize.height == 0) preferredSize.height = 200.f;
    preferredSize.height = MIN(maxDialogHeight, preferredSize.height);
    
    CGSize containerSize = containerView.bounds.size;
    CGRect frame =
    CGRectMake((containerSize.width - preferredSize.width)/2.f,
               (containerUsableHeight - preferredSize.height)/2.f,
               preferredSize.width,
               preferredSize.height);
    
    return frame;
}
- (void)containerViewWillLayoutSubviews {
    self.maskView.frame = [self containerView].bounds;
    [self repositionOrResizePresentedView:NO];
}

- (void)preferredContentSizeDidChangeForChildContentContainer:(id<UIContentContainer>)container {
    if (![self containerView]) return;
    
    if (container == [self presentedViewController]) {
        [self repositionOrResizePresentedView:YES];
    }
}

- (BOOL)shouldPresentInFullscreen {
    return YES;
}

- (void)maskViewTapped:(UIGestureRecognizer *)gesture
{
    if([gesture state] == UIGestureRecognizerStateRecognized)
    {
        //发送点击背景视图的通知
        [[NSNotificationCenter defaultCenter] postNotificationName:FYLDialogPresentationControllerTapMaskNotification object:nil];
        [[UIApplication sharedApplication] sendAction:@selector(resignFirstResponder) to:nil from:nil forEvent:nil];
    }
}

#pragma mark Resize and repositioning
- (void)repositionOrResizePresentedView:(BOOL)animated {
    CGRect frame = [self frameOfPresentedViewInContainerView];
    if (!CGSizeEqualToSize(frame.size, self.previousContentSize)) {
        
        FYLDialogTransitionCoordinator * tc = [[FYLDialogTransitionCoordinator alloc] initWithDialogPresentationController:self];
        [[self presentedViewController] viewWillTransitionToSize:frame.size withTransitionCoordinator:tc];
        
        void (^performLayout)() = ^{
            self.presentedView.frame = frame;
            for (void(^animation)(id<UIViewControllerTransitionCoordinatorContext>) in tc.animationBlocks) animation(tc);
        };
        void (^performCompletions)() = ^{
            tc.completed = YES;
            for (void(^completion)(id<UIViewControllerTransitionCoordinatorContext>) in tc.completionBlocks) completion(tc);
        };
        
        if (animated) {
            [UIView animateWithDuration:[tc transitionDuration]
                                  delay:0
                 usingSpringWithDamping:0.8
                  initialSpringVelocity:1
                                options:UIViewAnimationOptionCurveEaseInOut
                             animations:^{
                performLayout();
            } completion:^(BOOL finished) {
                performCompletions();
            }];
        } else {
            performLayout();
            performCompletions();
        }
    } else {
        if (!CGRectEqualToRect(self.presentedView.frame, frame)) {
            if (animated) {
                [UIView animateWithDuration:.3
                                      delay:0
                     usingSpringWithDamping:0.8
                      initialSpringVelocity:1
                                    options:UIViewAnimationOptionCurveEaseInOut
                                 animations:^{
                    self.presentedView.frame = frame;
                } completion:nil];
            } else {
                self.presentedView.frame = frame;
            }
        }
    }
    
    self.previousContentSize = frame.size;
}

@end

