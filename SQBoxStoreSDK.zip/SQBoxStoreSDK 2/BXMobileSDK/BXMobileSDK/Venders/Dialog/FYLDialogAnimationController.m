

#import "FYLDialogAnimationController.h"
#import "FYLDialogTransitionDelegate.h"

@implementation FYLDialogAnimationController

- (NSTimeInterval)transitionDuration:(id<UIViewControllerContextTransitioning>)transitionContext {
    return self.dismissing ? .3f : .3f;
}

- (void)animateTransition:(id<UIViewControllerContextTransitioning>)transitionContext {
    UIView * containerView = [transitionContext containerView];
    
    UIViewController * toViewController = [transitionContext viewControllerForKey:UITransitionContextToViewControllerKey];
    UIViewController * fromViewController = [transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey];
    
    if (!self.dismissing) {
        CGRect finalFrame =
        [transitionContext finalFrameForViewController:toViewController];
        
        UIView * toView = [transitionContext viewForKey:UITransitionContextToViewKey];
        CGRect initialFrame = finalFrame;
        initialFrame.origin.y = containerView.bounds.size.height + 20;
        
        toView.frame = initialFrame;
        [containerView addSubview:toView];
        toView.frame = finalFrame;
        
        [UIView animateWithDuration:[self transitionDuration:transitionContext]
                              delay:0
             usingSpringWithDamping:0.8
              initialSpringVelocity:1
                            options:UIViewAnimationOptionCurveEaseInOut
                         animations:^{
            if ([fromViewController.transitioningDelegate isKindOfClass:[FYLDialogTransitionDelegate class]]) {
                fromViewController.view.hidden = YES;
            }
        } completion:^(BOOL finished) {
            [transitionContext completeTransition:finished];
        }];
    } else {
        CGRect initialFrame =
        [transitionContext initialFrameForViewController:fromViewController];
        
        CGRect finalFrame = initialFrame;
        finalFrame.origin.y += containerView.bounds.size.height;
        fromViewController.view.frame = finalFrame;
        
        [UIView animateWithDuration:[self transitionDuration:transitionContext]
                              delay:0
             usingSpringWithDamping:0.8
              initialSpringVelocity:1
                            options:UIViewAnimationOptionCurveEaseInOut
                         animations:^{
            if ([toViewController.transitioningDelegate isKindOfClass:[FYLDialogTransitionDelegate class]]) {
                toViewController.view.hidden = NO;
            }
        } completion:^(BOOL finished) {
            [transitionContext completeTransition:finished];
        }];
    }
}
@end
