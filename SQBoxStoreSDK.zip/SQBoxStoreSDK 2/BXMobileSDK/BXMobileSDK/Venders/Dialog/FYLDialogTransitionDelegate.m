

#import "FYLDialogTransitionDelegate.h"
#import "FYLDialogAnimationController.h"
#import "FYLDialogPresentationController.h"

@implementation FYLDialogTransitionDelegate

- (id<UIViewControllerAnimatedTransitioning>)animationControllerForPresentedController:(UIViewController *)presented presentingController:(UIViewController *)presenting sourceController:(UIViewController *)source {
    FYLDialogAnimationController * animationController = [[FYLDialogAnimationController alloc] init];
    return animationController;
}

- (id<UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed {
    FYLDialogAnimationController * animationController = [[FYLDialogAnimationController alloc] init];
    animationController.dismissing = YES;
    return animationController;
}

- (UIPresentationController *)presentationControllerForPresentedViewController:(UIViewController *)presented presentingViewController:(UIViewController *)presenting sourceViewController:(UIViewController *)source {
    FYLDialogPresentationController * presentationController =
    [[FYLDialogPresentationController alloc] initWithPresentedViewController:presented presentingViewController:presenting];
    return presentationController;
}

@end
