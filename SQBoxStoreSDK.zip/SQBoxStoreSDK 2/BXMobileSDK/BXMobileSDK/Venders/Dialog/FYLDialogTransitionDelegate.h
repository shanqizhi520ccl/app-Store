

@import UIKit;

@interface FYLDialogTransitionDelegate : NSObject <UIViewControllerTransitioningDelegate>
@end
