

#import <UIKit/UIKit.h>

extern NSString *const FYLDialogPresentationControllerTapMaskNotification;

@interface FYLDialogPresentationController : UIPresentationController

@end
