

@import UIKit;

@interface FYLDialogAnimationController : NSObject <UIViewControllerAnimatedTransitioning>

@property (nonatomic) BOOL dismissing;

@end
