//
//  BXIpaManager.m
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/31.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXIpaManager.h"
#import "BXEvent.h"
#import "NSString+BXExtern.h"
#import "BXPrivacyUtil.h"
#import "BXMobileManager+Private.h"
#import "BXConfig.h"

static NSString * const BXIapErrorDomain = @"com.BXAuthManager.iap.error.domain";

static NSUInteger const BXTransactionModelVerifyWarningCount = 20;

@implementation BXTransaction

- (NSString *)description {
    NSDateFormatter *formatter = [NSDateFormatter new];
    formatter.dateFormat = @"yyyy-MM-dd hh:mm:ss";
    NSString *dateString = [formatter stringFromDate:self.transactionDate];
    return [NSString stringWithFormat:@"{\n\tproductIdentifier : %@, \n\ttransactionIdentifier : %@, \n\ttransactionDate : %@, \n\torderNo :%@, \n\tmodelVerifyCount :%lu, \n\tpriceTagString : %@, \n\tmd5 : %@, \n\tisTransactionValidFromService : %@ \n}",
            self.productIdentifier,
            self.transactionIdentifier,
            dateString,
            self.orderNo,
            (unsigned long)self.modelVerifyCount,
            self.priceTagString,
            self.md5,
            self.isTransactionValidFromService ? @"YES" : @"NO"];
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    self = [super init];
    if (self) {
        _productIdentifier = [aDecoder decodeObjectForKey:@"productIdentifier"];
        _reciept = [aDecoder decodeObjectForKey:@"reciept"];
        _transactionIdentifier = [aDecoder decodeObjectForKey:@"transactionIdentifier"];
        _transactionDate = [aDecoder decodeObjectForKey:@"transactionDate"];
        _orderNo = [aDecoder decodeObjectForKey:@"orderNo"];
        _modelVerifyCount = [aDecoder decodeIntegerForKey:@"modelVerifyCount"];
        _priceTagString = [aDecoder decodeObjectForKey:@"priceTagString"];
        _md5 = [aDecoder decodeObjectForKey:@"md5"];
        _isTransactionValidFromService = [aDecoder decodeBoolForKey:@"isTransactionValidFromService"];
    }
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder {
    [aCoder encodeObject:self.productIdentifier forKey:@"productIdentifier"];
    [aCoder encodeObject:self.reciept forKey:@"reciept"];
    [aCoder encodeObject:self.transactionIdentifier forKey:@"transactionIdentifier"];
    [aCoder encodeObject:self.transactionDate forKey:@"transactionDate"];
    [aCoder encodeObject:self.orderNo forKey:@"orderNo"];
    [aCoder encodeInteger:self.modelVerifyCount forKey:@"modelVerifyCount"];
    [aCoder encodeObject:self.priceTagString forKey:@"priceTagString"];
    [aCoder encodeObject:self.md5 forKey:@"md5"];
    [aCoder encodeBool:self.isTransactionValidFromService forKey:@"isTransactionValidFromService"];
}

- (instancetype)initWithProductIdentifier:(NSString *)productIdentifier reciept:(NSString *)reciept transactionIdentifier:(NSString *)transactionIdentifier transactionDate:(NSDate *)transactionDate {
    NSParameterAssert(productIdentifier);
    NSParameterAssert(reciept);
    NSParameterAssert(transactionIdentifier);
    NSParameterAssert(transactionDate);
    
    NSString *errorString = nil;
    if (!productIdentifier.length || !transactionIdentifier.length || !transactionDate || !reciept) {
        errorString = [NSString stringWithFormat:@"致命错误: 初始化商品交易模型时, productIdentifier: %@, reciept: %@, transactionIdentifier: %@, transactionDate: %@ 中有数据为空", productIdentifier, reciept, transactionIdentifier, [NSString stringWithFormat:@"%f", transactionDate.timeIntervalSince1970]];
    }
    
    if (errorString) {
        // 报告错误.
        NSError *error = [NSError errorWithDomain:BXIapErrorDomain code:0 userInfo:@{NSLocalizedDescriptionKey : errorString}];
         // [BLAssert reportError:error];
        return nil;
    }
    
    self = [super init];
    if (self) {
        _productIdentifier = productIdentifier;
        _reciept = reciept;
        _transactionIdentifier = transactionIdentifier;
        _transactionDate = transactionDate;
        _modelVerifyCount = 0;
        _isTransactionValidFromService = NO;
        _md5 = [reciept bx_md5];
    }
    return self;
}

- (void)setModelVerifyCount:(NSUInteger)modelVerifyCount {
    _modelVerifyCount = modelVerifyCount;
    
    if (modelVerifyCount > BXTransactionModelVerifyWarningCount) {
        NSString *errorString = [NSString stringWithFormat:@"验证次数超过最大验证次数: %@", self];
        NSError *error = [NSError errorWithDomain:BXIapErrorDomain code:0 userInfo:@{NSLocalizedDescriptionKey : errorString}];
        // 报警.
        // [BLAssert reportError:error];
    }
}

- (void)save {
    NSArray *caches = [[NSUserDefaults standardUserDefaults] objectForKey:@"iap"];
    NSMutableArray *newcaches = [NSMutableArray arrayWithArray:caches];
    NSDictionary *obj = @{
            @"orderID": _orderNo,
            @"transactionIdentifier": _transactionIdentifier,
            @"productIdentifier": _productIdentifier,
            @"md5": _md5,
            @"reciept": _reciept,
            @"transactionDate": _transactionDate
    };
    [newcaches addObject:obj];
    [[NSUserDefaults standardUserDefaults] setObject:newcaches forKey:@"iap"];
}

#pragma mark - Private

- (BOOL)isEqual:(id)object {
    if (!object) {
        return NO;
    }
    
    if (self == object) {
        return YES;
    }
    
    if (![object isKindOfClass:[BXTransaction class]]) {
        return NO;
    }
    
    return [self isEqualToModel:((BXTransaction *)object)];
}

- (BOOL)isEqualToModel:(BXTransaction *)object {
    BOOL isTransactionIdentifierMatch = [self.transactionIdentifier isEqualToString:object.transactionIdentifier];
    BOOL isProductIdentifierMatch = [self.productIdentifier isEqualToString:object.productIdentifier];
    BOOL isMd5Match;
    if (!self.md5 && !object.md5) {
        isMd5Match = YES;
    }
    else {
       isMd5Match = [self.md5 isEqualToString:object.md5];
    }
    return isTransactionIdentifierMatch && isProductIdentifierMatch && isMd5Match;
}

@end


@interface BXIpaManager ()<SKProductsRequestDelegate, SKPaymentTransactionObserver>
@property (nonatomic, strong) NSSet<NSString *> *productIdSet;
@property (nonatomic, strong) NSString *selectedProductID;
@property (nonatomic, strong) NSString *currentOrderID;
@property (nonatomic, strong) NSMutableDictionary *transactionsDict;
@end

@implementation BXIpaManager

+ (instancetype)sharedObject {
    static BXIpaManager *_manager = nil;
    if (!_manager) {
        _manager = [[BXIpaManager alloc] init];
    }
    return _manager;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        _transactionsDict = [NSMutableDictionary dictionary];
        
        // 添加观察者
        [[SKPaymentQueue defaultQueue] addTransactionObserver:self];
    }
    return self;
}

- (void)setProductSet:(NSSet<NSString *> *)productIdSet {
    _productIdSet = [NSSet setWithSet:productIdSet];
}

- (void)dealloc {
    // 移除监听
    [[SKPaymentQueue defaultQueue] removeTransactionObserver:self];
}

- (void)checkUnfinishedTransaction {
    // 未完成的列表.
    NSArray<SKPaymentTransaction *> *transactionsWaitingForVerifing = [[SKPaymentQueue defaultQueue] transactions];
    for (SKPaymentTransaction *transaction in transactionsWaitingForVerifing) {
        BXLogDebug(@"transactionsWaitingForVerifing { transactionIdentifier: %@, transactionDate: %@, transactionState: %@, orderID: %@ } ", transaction.transactionIdentifier, transaction.transactionDate, @(transaction.transactionState), transaction.payment.applicationUsername );
        if (!(transaction.transactionState == SKPaymentTransactionStatePurchasing) && (!transaction.transactionIdentifier || !transaction.transactionDate)) {
            // 购买没有交易标识和购买日期的, 且状态不是正在购买，就是没有成功付款的, 直接finish掉.
            [self completeTransaction:transaction];
            continue;
        }
    }
}

- (void)clearAllUnfinishedTransiactionNotification {
    // 未完成的列表.
    NSArray<SKPaymentTransaction *> *transactionsWaitingForVerifing = [[SKPaymentQueue defaultQueue] transactions];
    for (SKPaymentTransaction *transaction in transactionsWaitingForVerifing) {
        [self completeTransaction:transaction];
    }
}

- (void)makeStore:(NSDictionary *)info {
    //    [BXEvent bx_doGetPaymentType:^(id obj, NSError *error) {
    //        if (!error) {
    //            if ([[obj objectForKey:@"AP"] isEqualToNumber:@1]) {
    //                [self createApOrder:info];
    //            }else{
    //                [self createOrder:info];
    //            }
    //        }else{
    //            NSError *err = [NSError errorWithDomain:BXIapErrorDomain code:0 userInfo:@{NSLocalizedDescriptionKey : error.localizedDescription }];
    //            [self reportTransactionError:err];
    //        }
    //    }];
    [BXEvent bx_doPaymentType:[info[BXOrderInfoProductPriceKey] integerValue] complement:^(id obj, NSError *error) {
        if (!error) {
            if ([[obj objectForKey:@"applePay"] isEqualToNumber:@1]) {
                [self createApOrder:info];
            }else{
                [self createOrder:info];
            }
        }else{
            NSError *err = [NSError errorWithDomain:BXIapErrorDomain code:0 userInfo:@{NSLocalizedDescriptionKey : error.localizedDescription }];
            [self reportTransactionError:err];
        }
    }];
}

-(void)createOrder:(NSDictionary *)info {
    [BXEvent bx_proxyStroreAddress:info complement:^(id obj, NSError *error) {
        if (!error) {
            [[UIApplication sharedApplication] openURL:obj];
        }else{
            [self reportTransactionError:error];
        }
    }];
}

- (void)createApOrder:(NSDictionary *)info {
    NSString *appName = BX_BUNDLE_NAME;
    NSString *appPackage = BX_BUNDLE_ID;

    NSString *abbey = info[BXOrderInfoOrderIDKey];
    NSString *extension = info[BXOrderInfoExternKey];
    NSString *iosIdCode = [BXConfig config].iosIdCode;
    NSString *notifyUrl = info[BXOrderInfoNotifyUrlKey];
    NSString *productDesc = info[BXOrderInfoProductDescriptionKey];
    NSString *productId = info[BXOrderInfoProductIdKey];
    NSString *productName = info[BXOrderInfoProductNameKey];
    NSInteger talks = [info[BXOrderInfoProductPriceKey] integerValue];
    
    BXUser *user = [BXMobileManager shareManager].currentUser;
    NSString *userId = user.userId;
    NSString *roleId = user.roleId;
    NSString *roleName = user.roleName;
    NSString *zoneId = user.zoneId;
    NSString *zoneName = user.zoneName;
    NSString *userName = user.userName;
    
    [BXEvent bx_doCreateOrder:4 PL:0 abbey:abbey appName:appName appPackage:appPackage extension:extension iosIdCode:iosIdCode notifyUrl:notifyUrl productDesc:productDesc productId:productId productName:productName roleId:roleId roleName:roleName talks:talks userId:userId userName:userName zoneId:zoneId zoneName:zoneName complement:^(NSDictionary *obj, NSError *error) {
        if (error) {
            [self reportTransactionError:error];
        }else{
            NSString *CID = [obj objectForKey:@"orderId"];
            [self makeStore:productId orderId:CID];
        }
    }];
}

- (void)makeStore:(NSString *)productID orderId:(NSString *)orderID {
    _selectedProductID = productID;
    _currentOrderID = orderID;
    
    if([SKPaymentQueue canMakePayments]){
        [self requestPorducts:productID];
    }else{
        NSError *error = [NSError errorWithDomain:BXIapErrorDomain code:0 userInfo:@{NSLocalizedDescriptionKey : @"不允许程序内付费" }];
        [self reportTransactionError:error];
        return;
    }
}

- (void)requestPorducts:(NSString *)productID {
    if (productID.length > 0) {
        // 1.拿到所有可卖商品的ID数组
        NSArray *productIDArray = [[NSArray alloc] initWithObjects:productID, nil];
        NSSet *sets = [[NSSet alloc] initWithArray:productIDArray];
        
        SKProductsRequest * request = [[SKProductsRequest alloc] initWithProductIdentifiers:sets];
        request.delegate = self;
        [request start];
    }else{
        NSError *error = [NSError errorWithDomain:BXIapErrorDomain code:0 userInfo:@{NSLocalizedDescriptionKey : @"商品ID为空"}];
        [self reportTransactionError:error];
    }
}

// 查询回调
- (void)productsRequest:(SKProductsRequest *)request didReceiveResponse:(SKProductsResponse *)response {
    BXLogDebug(@"获取到(%d)个可卖商品", response.products.count);
    BXLogDebug(@"不可卖(%d)个商品ID = %@", response.invalidProductIdentifiers.count, response.invalidProductIdentifiers);
    NSArray *products = response.products;
    if([products count] == 0){
        NSError *error = [NSError errorWithDomain:BXIapErrorDomain code:0 userInfo:@{NSLocalizedDescriptionKey : @"没有获取到可以购买的商品"}];
        [self reportTransactionError:error];
        return;
    }
    SKProduct *produck = nil;
    for (SKProduct *sKProduct in products) {
        if([sKProduct.productIdentifier isEqualToString:self.selectedProductID]){
            produck = sKProduct;
            BXLogInfo(@"当前购买商品: { \n\tproductIdentifier : %@, \n\tdescription : %@, \n\tlocalizedTitle : %@, \n\tlocalizedDescription : %@, \n\tprice: %@ \n}",
                       [produck productIdentifier],
                       [produck description],
                       [produck localizedTitle],
                       [produck localizedDescription],
                       [produck price]);
            break;
        }
    }
    
    if (produck) {
        [self buyProduct:produck];
    }else{
        NSError *error = [NSError errorWithDomain:BXIapErrorDomain code:0 userInfo:@{NSLocalizedDescriptionKey : @"没有获取到匹配的商品"}];
        [self reportTransactionError:error];
    }
}

-(void)buyProduct:(SKProduct *)product {
    NSParameterAssert(product);
    SKMutablePayment *payment = [SKMutablePayment paymentWithProduct:product];
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_7_0) {
        payment.applicationUsername = self.currentOrderID;
    }else{
        payment.requestData = [self.currentOrderID dataUsingEncoding:NSUTF8StringEncoding];
    }
    [[SKPaymentQueue defaultQueue] addPayment:payment];
}

#pragma mark - SKRequestDelegate

//请求失败
- (void)request:(SKRequest *)request didFailWithError:(NSError *)error {
    [self reportTransactionError:error];
}

//请求结束
- (void)requestDidFinish:(SKRequest *)request {
    BXLogInfo(@"商品信息请求成功");
}

// 状态改变回调
- (void)paymentQueue:(SKPaymentQueue *)queue updatedTransactions:(NSArray *)transactions
{
    BXLogDebug(@"{ transactions: %@ }", transactions);
    for (SKPaymentTransaction *transaction in transactions)
    {
        switch (transaction.transactionState)
        {
            case SKPaymentTransactionStatePurchasing:   //商品添加进列表
                BXLogDebug(@"正在购买");
                break;
                
            case SKPaymentTransactionStatePurchased:    //交易完成
                BXLogDebug(@"购买成功");
                [self buyAppleStoreProductSucceedWithPaymentTransaction:transaction];
                break;
                
            case SKPaymentTransactionStateFailed:       //交易失败
                BXLogDebug(@"购买失败");
                [self buyAppleStoreProductFailedWithPaymentTransaction:transaction];
                break;
                
            case SKPaymentTransactionStateRestored:     //已经购买过该商品
                BXLogDebug(@"恢复购买中");
                [self restoredAppleStoreProductWithPaymentTransaction:transaction];
                break;
                
            case SKPaymentTransactionStateDeferred:
                BXLogDebug(@"交易还在队列里面，但最终状态还没有决定");
                break;
                
            default:
                break;
        }
    }
}

// 完成
- (void)completeTransaction:(SKPaymentTransaction *)transaction {
    [[SKPaymentQueue defaultQueue] finishTransaction:transaction];
}

// 失败
- (void)failedTransaction:(SKPaymentTransaction *)transaction {
    [[SKPaymentQueue defaultQueue] finishTransaction:transaction];
}

- (void)finishTransaction:(NSString *)orderID {
    SKPaymentTransaction *transaction = [self.transactionsDict objectForKey:orderID];
    if (nil != transaction) {
        [[SKPaymentQueue defaultQueue] finishTransaction:transaction];
        [self.transactionsDict removeObjectForKey:orderID];
    }
}

#pragma mark - Handler

// 苹果内购支付成功
- (void)buyAppleStoreProductSucceedWithPaymentTransaction:(SKPaymentTransaction *)paymentTransaction {
    [self verifyTransactionResultByServer:paymentTransaction];
}

- (void)buyAppleStoreProductFailedWithPaymentTransaction:(SKPaymentTransaction *)paymentTransaction  {
    if (paymentTransaction.error.code != SKErrorPaymentCancelled) {
        [self reportTransactionError:paymentTransaction.error];
    }else{
        NSError *iapError = [NSError errorWithDomain:BXIapErrorDomain code:paymentTransaction.error.code userInfo:@{NSLocalizedDescriptionKey : @"用户取消购买"}];
        [self reportTransactionError:iapError];
    }
    [self failedTransaction:paymentTransaction];
}

- (void)restoredAppleStoreProductWithPaymentTransaction:(SKPaymentTransaction *)paymentTransaction{
    [[SKPaymentQueue defaultQueue] restoreCompletedTransactions];
    [self completeTransaction:paymentTransaction];
}

#pragma mark - Verify Recipt

- (void)verifyTransactionResultByServer:(SKPaymentTransaction *)paymentTransaction {
    NSParameterAssert(paymentTransaction);
    
    NSString * productIdentifier = paymentTransaction.payment.productIdentifier;
    NSString * transactionIdentifier = paymentTransaction.transactionIdentifier;
    NSDate * transactionData = paymentTransaction.transactionDate;
    BXLogDebug(@"productIdentifier ：%@", productIdentifier);
    BXLogDebug(@"transactionIdentifier ：%@", transactionIdentifier);
    
    NSData *receiptData = nil;
    NSString *orderID = nil;
    //系统IOS7.0以上获取支付验证凭证的方式应该改变，切验证返回的数据结构也不一样了。
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_7_0) {
        // 验证凭据，获取到苹果返回的交易凭据
        // appStoreReceiptURL iOS7.0增加的，购买交易完成后，会将凭据存放在该地址
        NSURL *receiptUrl = [[NSBundle mainBundle] appStoreReceiptURL];
        receiptData = [NSData dataWithContentsOfURL:receiptUrl];
        orderID = paymentTransaction.payment.applicationUsername;
        if (orderID == NULL || [orderID isEqualToString:@""]) {
            orderID = [[NSString alloc] initWithData:paymentTransaction.payment.requestData encoding:NSUTF8StringEncoding];
        }
        BXLogDebug(@"receiptUrl ：%@", receiptUrl);
    }else{
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
        receiptData = paymentTransaction.transactionReceipt;
        orderID = [[NSString alloc] initWithData:paymentTransaction.payment.requestData encoding:NSUTF8StringEncoding];
#pragma clang diagnostic pop
    }
    
    if (!receiptData) {
        // 交易凭证为空验证失败
        BXLogError(@"Receipt data con not be NULL", receiptData);
        NSError *error = [NSError errorWithDomain:BXIapErrorDomain code:paymentTransaction.error.code userInfo:@{NSLocalizedDescriptionKey : @"交易凭证为空验证失败"}];
        [self finishTransaction:orderID];
        [self reportTransactionError:error];
        return;
    }

    [self.transactionsDict setObject:paymentTransaction forKey:orderID];
    
    NSString *base64Receipt = [receiptData base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
    
    BXTransaction *transactionMode = [[BXTransaction alloc] initWithProductIdentifier:productIdentifier reciept:base64Receipt transactionIdentifier:transactionIdentifier transactionDate:transactionData];
    transactionMode.orderNo = orderID;
    
#if (defined(DEBUG))
    BXLogDebug(@"transactionMode: %@", transactionMode);
    [transactionMode save];
#endif
    
    NSParameterAssert(orderID);
    NSParameterAssert(base64Receipt);
    
    @weakify(self)
    [BXEvent doVerifyIapResult:transactionMode.orderNo receipt:transactionMode.reciept complement:^(id obj, NSError *error) {
        @strongify(self)
        if (!error) {
            BXLogInfo(@"验证充值凭证成功 { orderID: %@ }", orderID);
            [BXMBProgressHUD bx_showMessage:@"充值成功"];
            [self finishTransaction:orderID];
        }else{
            BXLogInfo(@"验证充值凭证失败 { orderID: %@ }", orderID);
            [self reportTransactionError:error];
            [self finishTransaction:orderID];
//#if (defined(DEBUG))
//            [self verifyTransactionResultByClient:paymentTransaction];
//#endif
        }
    }];
}

- (void)verifyTransactionResultByClient:(SKPaymentTransaction *)transaction
{
    NSString * productIdentifier = transaction.payment.productIdentifier;
    BXLogDebug(@"productIdentifier ：%@", productIdentifier);
    //获取transaction_id
    NSString * transactionIdentifier = transaction.transactionIdentifier;
    BXLogDebug(@"transactionIdentifier ：%@", transactionIdentifier);
    
    NSData *receiptData = nil;
    NSString *orderID = nil;
    
    //系统IOS7.0以上获取支付验证凭证的方式应该改变，切验证返回的数据结构也不一样了。
    if (NSFoundationVersionNumber >= NSFoundationVersionNumber_iOS_7_0) {
        // 验证凭据，获取到苹果返回的交易凭据
        // appStoreReceiptURL iOS7.0增加的，购买交易完成后，会将凭据存放在该地址
        NSURL *receiptUrl = [[NSBundle mainBundle] appStoreReceiptURL];
        receiptData = [NSData dataWithContentsOfURL:receiptUrl];
        orderID = transaction.payment.applicationUsername;
        if (orderID == NULL || [orderID isEqualToString:@""]) {
            orderID = [[NSString alloc] initWithData:transaction.payment.requestData encoding:NSUTF8StringEncoding];
        }
    }else{
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
        receiptData = transaction.transactionReceipt;
        orderID = [[NSString alloc] initWithData:transaction.payment.requestData encoding:NSUTF8StringEncoding];
#pragma clang diagnostic pop
    }
    
    // 去验证是否真正的支付成功了
    /* 生成订单参数，注意沙盒测试账号与线上正式苹果账号的验证途径不一样，要给后台标明 */
    /*
     注意：
     自己测试的时候使用的是沙盒购买(测试环境)
     App Store审核的时候也使用的是沙盒购买(测试环境)
     上线以后就不是用的沙盒购买了(正式环境)
     所以此时应该先验证正式环境，在验证测试环境
     
     正式环境验证成功，说明是线上用户在使用
     正式环境验证不成功返回21007，说明是自己测试或者审核人员在测试
     */
    /*
     苹果AppStore线上的购买凭证地址是： https://buy.itunes.apple.com/verifyReceipt
     测试地址是：https://sandbox.itunes.apple.com/verifyReceipt
     */
    
    /**
     BASE64 常用的编码方案，通常用于数据传输，以及加密算法的基础算法，传输过程中能够保证数据传输的稳定性
     BASE64是可以编码和解码的
     */
    // 传输的是BASE64编码的字符串
    NSString *receiptString = [receiptData base64EncodedStringWithOptions:0];
    
    NSDictionary *requestContents = @{
          @"receipt-data": receiptString
    };
    
    NSError *error;
    // 转换为 JSON 格式
    NSData *requestData = [NSJSONSerialization dataWithJSONObject:requestContents options:0 error:&error];
    
    // 不存在
    if (!requestData) {
        /* ... Handle error ... */
        BXLogDebug(@"verify transaction failed");
        return;
    }
    
    // 发送网络POST请求，对购买凭据进行验证
    NSString *verifyUrlString;
#if (defined(APPSTORE_ASK_TO_BUY_IN_SANDBOX) && defined(DEBUG))
    verifyUrlString = @"https://sandbox.itunes.apple.com/verifyReceipt";
#else
    verifyUrlString = @"https://buy.itunes.apple.com/verifyReceipt";
#endif
    
    BXLogDebug(@"Verify recipt {orderID: %@, recipt: %@}", orderID, receiptString);
    
    // 国内访问苹果服务器比较慢，timeoutInterval 需要长一点
    NSMutableURLRequest *storeRequest = [NSMutableURLRequest requestWithURL:[[NSURL alloc] initWithString:verifyUrlString] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:10.0f];
    
    [storeRequest setHTTPMethod:@"POST"];
    [storeRequest setHTTPBody:requestData];
    
    // 在后台对列中提交验证请求，并获得官方的验证JSON结果
    NSOperationQueue *queue = [[NSOperationQueue alloc] init];
    [NSURLConnection sendAsynchronousRequest:storeRequest queue:queue completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
        if (connectionError) {
            BXLogDebug(@"验证失败 %@", connectionError);
            [[SKPaymentQueue defaultQueue] finishTransaction:transaction];
        } else {
            NSError *error;
            NSDictionary *jsonResponse = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
            if (!jsonResponse) {
                BXLogDebug(@"验证失败");
                //[[SKPaymentQueue defaultQueue] finishTransaction:transaction];
            }else{
                // 比对 jsonResponse 中以下信息基本上可以保证数据安全
                /*
                 bundle_id
                 application_version
                 product_id
                 transaction_id
                 */
                BXLogDebug(@"验证成功 %@", jsonResponse);
            }
        }
    }];
}

- (void)reportTransactionError:(NSError *)error {
    BXLogError(@"Transaction failed: { code : %d, msg: %@ }", error.code, error.localizedDescription);
    dispatch_async(dispatch_get_main_queue(), ^{
        [self showAlert:nil message:error.localizedDescription];
    });
}

- (void)showAlert:(NSString *)title message:(NSString *)message {
    UIViewController *vc = [BXPrivacyUtil bx_currentController];
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:NULL];
    [alert addAction:action];
    
    [vc presentViewController:alert animated:YES completion:NULL];
}

@end
