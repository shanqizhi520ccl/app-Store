//
//  BXResponse.h
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/10.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import <Foundation/Foundation.h>

//NS_ASSUME_NONNULL_BEGIN

#define HTTP_STATUS_SUCCESS_CODE 200
#define HTTP_ERROR_NONE_RET_CODE 999


@interface BXResponse : NSObject

- (id)initWithResponse:(NSURLResponse *)response data:(NSDictionary *)data state:(NSInteger)state desc:(NSString *)desc;

/**
* HTTP response.
*/
@property (nonatomic, readonly) NSURLResponse *urlResponse;

/**
 * HTTP error code.
 * state 1: success, other: faied
 */
@property (nonatomic, readonly) NSInteger state;

/**
 * HTTP result message.
 */
@property (nonatomic, readonly) NSString *desc;

/**
 *  A dictionary with the contents of the response.
 */
@property (nonatomic, readonly) NSDictionary *data;

@end

//NS_ASSUME_NONNULL_END
