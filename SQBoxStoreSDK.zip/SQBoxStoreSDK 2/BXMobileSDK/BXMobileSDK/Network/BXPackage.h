//
//  BXPackage.h
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/13.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import <Foundation/Foundation.h>

//NS_ASSUME_NONNULL_BEGIN

@interface BXPackage : NSObject

/// 配置项
/// @param isSeries 是否系列包
+ (NSDictionary *)pacForConfig:(BOOL)isSeries;

/// 登录
/// @param phoneNumber 账号或手机号
/// @param password 密码
/// @param isSeries 是否系列包
+ (NSDictionary *)pacForLogin:(NSString *)phoneNumber
                     password:(NSString *)password
                     isSeries:(BOOL)isSeries;

/// 一键注册
/// @param password 账号密码
+ (NSDictionary *)pacForOneStepRegister:(NSString *)password;

/// 手机注册
/// @param phoneNumber 手机号
/// @param msgCode 验证码
+ (NSDictionary *)pacForRegisterByMobile:(NSString *)phoneNumber
                                 msgCode:(NSString *)msgCode
                                password:(NSString *)password;

/// 获取验证码
/// @param phoneNumber 手机号
/// @param smsType 验证码类型 1注册 2密码重置 5绑定手机 13解绑手机号
+ (NSDictionary *)pacForSmsCode:(NSString *)phoneNumber
                        smsType:(NSInteger)smsType;

/// 实名认证
/// @param idCard 身份证号
/// @param realname 真实姓名
/// @param userId 用户ID
+ (NSDictionary *)pacForRealnameAuth:(NSString *)idCard
                            realname:(NSString *)realname
                               phone:(NSString *)phone
                              userId:(NSString *)userId;

+ (NSDictionary *)pacTokenAuth;

/// 公告
+ (NSDictionary *)pacForNofice;

/// 同步角色数据
/// @param actionType 运作类型 1为进入游戏 2为等级提升 3为退出游戏
/// @param gameCoin 游戏币数量
/// @param roleId 角色ID
/// @param roleLevel 角色等级
/// @param roleName 角色名称
/// @param userId 用户ID
/// @param zoneId 区服ID
/// @param zoneName 区服名称
+ (NSDictionary *)pacForSyncData:(NSInteger)actionType
                        gameCoin:(NSNumber *)gameCoin
                          roleId:(NSString *)roleId
                       roleLevel:(NSString *)roleLevel
                        roleName:(NSString *)roleName
                          userId:(NSString *)userId
                          zoneId:(NSString *)zoneId
                        zoneName:(NSString *)zoneName;

/// 获取支付方式
+ (NSDictionary *)pacForPaymentType;
+ (NSDictionary *)pacPaymentType:(NSString *)userId rechargeAmount:(double )rechargeAmount;
/// 下单
/// @param PC 支付渠道 固定4，代表苹果支付
/// @param PL 支付类型 0为消费，1为充值平台币
/// @param abbey cp订单号
/// @param appName 应用名称 发起支付的应用名称
/// @param appPackage 应用包名 发起支付的应用包名
/// @param extension 扩展参数
/// @param iosIdCode IOS包识别码
/// @param notifyUrl 返回地址
/// @param productDesc 产品技术
/// @param productId 产品编号
/// @param productName 产品名称
/// @param roleId 角色编号
/// @param roleName 角色名称
/// @param talks 金额 以分为单位
/// @param userId 用户ID
/// @param userName 账号名称
/// @param zoneId 区服编号
/// @param zoneName 区服名称
+ (NSDictionary *)pacForOrder:(NSInteger)PC
                           PL:(NSInteger)PL
                        abbey:(NSString *)abbey
                      appName:(NSString *)appName
                   appPackage:(NSString *)appPackage
                    extension:(NSString *)extension
                    iosIdCode:(NSString *)iosIdCode
                    notifyUrl:(NSString *)notifyUrl
                  productDesc:(NSString *)productDesc
                    productId:(NSString *)productId
                    productName:(NSString *)productName
                       roleId:(NSString *)roleId
                     roleName:(NSString *)roleName
                        talks:(NSInteger)talks
                       userId:(NSString *)userId
                     userName:(NSString *)userName
                       zoneId:(NSString *)zoneId
                     zoneName:(NSString *)zoneName;

/// 账户退出
/// @param userId 用户ID
+ (NSDictionary *)pacForLogout:(NSString *)userId;

/// 忘记密码
/// @param phoneNumber 手机号
/// @param newPassword 新密码
/// @param msgCode 验证码
+ (NSDictionary *)pacForForgotPassword:(NSString *)phoneNumber
                           newPassword:(NSString *)newPassword
                               msgCode:(NSString *)msgCode;
/// 修改密码
+ (NSDictionary *)pacForOldPassword:(NSString *)oldPassword
                        newPassword:(NSString *)newPassword
                             userId:(NSString *)userId ;
/// 绑定手机
/// @param phoneNumber 手机号
/// @param msgCode 验证码
/// @param userId 用户ID
+ (NSDictionary *)pacForBindMobile:(NSString *)phoneNumber
                           msgCode:(NSString *)msgCode
                            userId:(NSString *)userId;

/// 效验内购结果
/// @param orderId 订单号
/// @param receipt 凭证
+ (NSDictionary *)pacForVerifyIapResult:(NSString *)orderId
                                receipt:(NSString *)receipt;

+ (NSDictionary *)pacForServiceSupportWithZoneId:(NSString *)zoneId
                                    zoneName:(NSString *)zoneName
                                      roleId:(NSString *)roleId
                                    roleName:(NSString *)roleName
                                   roleLevel:(NSString *)roleLevel
                                    gameCoin:(NSNumber *)gameCoin;

+ (NSDictionary *)pacForAPOrder:(NSInteger)PC
                             PL:(NSInteger)PL
                          abbey:(NSString *)abbey
                        appName:(NSString *)appName
                     appPackage:(NSString *)appPackage
                      extension:(NSString *)extension
                      iosIdCode:(NSString *)iosIdCode
                      notifyUrl:(NSString *)notifyUrl
                    productDesc:(NSString *)productDesc
                      productId:(NSString *)productId
                    productName:(NSString *)productName
                         roleId:(NSString *)roleId
                       roleName:(NSString *)roleName
                          talks:(NSInteger)talks
                         userId:(NSString *)userId
                       userName:(NSString *)userName
                         zoneId:(NSString *)zoneId
                       zoneName:(NSString *)zoneName;

+ (NSDictionary *)proxyInfoDictionary;
/// 公共参数
+ (NSDictionary *)publicParameters;
@end

//NS_ASSUME_NONNULL_END
