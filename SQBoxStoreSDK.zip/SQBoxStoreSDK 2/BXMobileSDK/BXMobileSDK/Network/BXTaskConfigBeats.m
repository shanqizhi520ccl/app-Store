//
//  BXTaskConfigBeats.m
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/10.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXTaskConfigBeats.h"
#import "BXDefine.h"

@interface BXTaskConfigBeats ()

/** 自动重连使用的计时器 */
@property (nonatomic, strong) NSTimer *taskTimer;

/** 尝试重连次数 */
@property (nonatomic, assign) NSInteger repeatCount;

@end

@implementation BXTaskConfigBeats

#ifdef DEBUG
- (void)dealloc
{
    BXLogDebug(@"%@ dealloc", self.class);
}
#endif

- (instancetype)init
{
    self = [super init];
    if (self) {
        _interval = 5;
        _maxRepeatCount = 100000;
    }
    return self;
}

- (void)start
{
    _isConfigOver = NO;
    [self startTaskTimer:_interval];
}

- (void)stop
{
    [self stopTaskTimer];
    [self configTaskStop];
}

- (void)configTaskStop {
    if (!_isConfigOver) {
        _isConfigOver = YES;
    }
}

#pragma mark -

- (void)stopTaskTimer
{
    if (_taskTimer) {
        [_taskTimer invalidate];
        _taskTimer = nil;
        _repeatCount = 0;
    }
}

- (void)startTaskTimer:(NSTimeInterval)interval
{
    [self stopTaskTimer];
    _taskTimer = [NSTimer scheduledTimerWithTimeInterval:interval
                                                   target:self
                                                 selector:@selector(doTaskTimerFunction)
                                                 userInfo:nil
                                                  repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:_taskTimer
                                 forMode:NSRunLoopCommonModes];
    [_taskTimer fire];
}

- (void)doTaskTimerFunction
{
    if ( _isConfigOver || _repeatCount > _maxRepeatCount) {
        [self stopTaskTimer];
        return;
    }

    BXLogDebug(@"doTaskTimerFunction");
    if (!_isConfigOver) {
        if (_configBlock && _taskConfigBlock) {
            BXMobileSDKBlockRun(_configBlock, self);
        }else{
            [self configTaskStop];
        }
    }else{
        [self configTaskStop];
    }
    
    _repeatCount++;
}

@end
