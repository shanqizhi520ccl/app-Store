//
//  BXEvent.h
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/13.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import <Foundation/Foundation.h>

//NS_ASSUME_NONNULL_BEGIN

typedef void(^BXEventComplement)(id obj, NSError *error);

/// 网络请求事件
@interface BXEvent : NSObject

/// 初始化
+ (void)bx_doConfig;
+ (void)bx_doConfig:(BXEventComplement)complement;

/// 获取验证码
/// @param phoneNumber 手机号
/// @param smsType 验证码类型 1注册 2密码重置 5绑定手机 13解绑手机号
/// @param complement 回调
+ (void)bx_doGetSmsCode:(NSString *)phoneNumber
                smsType:(NSInteger)smsType
             complement:(BXEventComplement)complement;

/// 手机注册
/// @param phoneNumber 手机号码
/// @param smsCode 验证码
/// @param password 密码
/// @param complement 回调
+ (void)bx_doRegisterByMobile:(NSString *)phoneNumber
                      smsCode:(NSString *)smsCode
                     password:(NSString *)password
                   complement:(BXEventComplement)complement;

/// 一键注册
/// @param password 密码
/// @param complement 回调
+ (void)bx_doFastRegister:(NSString *)password
               complement:(BXEventComplement)complement;

/// 登录
/// @param account 账号/手机号
/// @param password 密码
+ (void)bx_doLogin:(NSString *)account
          password:(NSString *)password
        complement:(BXEventComplement)complement;

/// 普通登录
/// @param account 账号/手机号
/// @param password 密码
+ (void)bx_doNormalLogin:(NSString *)account
                password:(NSString *)password
              complement:(BXEventComplement)complement;

/// 系列化登录
/// @param account 账号
/// @param password 密码
+ (void)bx_doSeriesLogin:(NSString *)account
                password:(NSString *)password
              complement:(BXEventComplement)complement;

/// 修改密码
/// @param phoneNumber 手机号
/// @param password 密码
/// @param msgCode 验证码
/// @param complement 回调
+ (void)doUpdateUserPassword:(NSString *)phoneNumber
                    password:(NSString *)password
                     msgCode:(NSString *)msgCode
                  complement:(BXEventComplement)complement;

/// 修改密码
+ (void)doUpdateUserOldPassword:(NSString *)password
                    newPassword:(NSString *)newPassword
                     complement:(BXEventComplement)complement;

+ (void)doBindMobile:(NSString *)phoneNumber
             msgCode:(NSString *)msgCode
          complement:(BXEventComplement)complement;

+ (void)doUnBindPhoneMobile:(NSString *)phoneNumber
                    msgCode:(NSString *)msgCode
                 complement:(BXEventComplement)complement;

+ (void)bx_doRealnameAuth:(NSString *)idCard
                 realName:(NSString *)realName
                    phone:(NSString *)phone
               complement:(BXEventComplement)complement;
+ (void)bx_doUserInfoComplement:(BXEventComplement)complement;

+ (void)bx_doUpdateNotice:(BXEventComplement)complement;

+ (void)bx_doSyncData:(NSInteger)actionType
             gameCoin:(NSNumber *)gameCoin
               roleId:(NSString *)roleId
            roleLevel:(NSString *)roleLevel
             roleName:(NSString *)roleName
               zoneId:(NSString *)zoneId
             zoneName:(NSString *)zoneName
           complement:(BXEventComplement)complement;

+ (void)bx_doGetPaymentType:(BXEventComplement)complement;
+ (void)bx_doPaymentType:(NSInteger)rechargeAmount complement:(BXEventComplement)complement;

+ (void)bx_doCreateOrder:(NSInteger)PC
                      PL:(NSInteger)PL
                   abbey:(NSString *)abbey
                 appName:(NSString *)appName
              appPackage:(NSString *)appPackage
               extension:(NSString *)extension
               iosIdCode:(NSString *)iosIdCode
               notifyUrl:(NSString *)notifyUrl
             productDesc:(NSString *)productDesc
             productId:(NSString *)productId
             productName:(NSString *)productName
                  roleId:(NSString *)roleId
                roleName:(NSString *)roleName
                   talks:(NSInteger)talks
                  userId:(NSString *)userId
                userName:(NSString *)userName
                  zoneId:(NSString *)zoneId
                zoneName:(NSString *)zoneName
              complement:(BXEventComplement)complement;

+ (void)doVerifyIapResult:(NSString *)orderId
                  receipt:(NSString *)receipt
               complement:(BXEventComplement)complement;

+ (void)doHeartBeatResultComplement:(BXEventComplement)complement;

+ (void)bx_doLogout:(BXEventComplement)complement;

+ (void)bx_proxyCustomerSupportUrl:(BXEventComplement)complement;
+ (void)bx_proxyPrivacyPolicyAddress:(BXEventComplement)complement;
+ (void)bx_proxyServiceAgreementAddress:(BXEventComplement)complement;

+ (void)bx_proxyStroreAddress:(NSDictionary *)orderInfo complement:(BXEventComplement)complement;

@end

//NS_ASSUME_NONNULL_END
