//
//  BXConfig.m
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/14.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXConfig.h"
#import "BXHelper.h"
#import "BXMobileManager+Private.h"
#import "BXPrivacyUtil.h"

@interface BXConfig ()
@end

@implementation BXConfig

#ifdef DEBUG
- (void)dealloc
{
    BXLogDebug(@"%@ dealloc", self.class);
}
#endif

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.configState = BXConfigStateNONE;
        
        self.AP = 1;
        self.antiAddictionSwitch = 0;
        self.apiServer = nil;
        self.apilogUrl = nil;
        self.appH5Server = nil;
        self.appH5WebUrl = nil;
        self.appServer = 0;
        self.cdnImgServer = nil;
        self.customerServiceUrl = nil;
        self.dos = nil;
        self.downloadUrl = nil;
        self.facebookLoginSwitch = 0;
        self.fastRegister = 1;
        self.phoneRegister = 1;
        self.forceUpdate = 0;
        self.googleLoginSwitch = 0;
        self.h5SdkUrl = nil;
        self.h5csServer = nil;
        self.heartBeatInterval = 1;
        self.informationUrl = nil;
        self.iosIdCode = nil;
        self.isSanBox = 1;
        self.mcId = BX_MC_ID;
        self.scId = BX_SC_ID;
        self.menu = nil;
        self.payWindow = nil;
        self.platformCoinMediaUrl = nil;
        self.platformCoinName = nil;
        self.realNameAuthTip = 0;
        self.sdkmarkwords = nil;
        self.tuowoWxReturnUrl = nil;
        self.userPrivateProtocolUpdate = 0;
        self.userPrivateVersion = nil;
        self.userProtocolRefuseBtn = 0;
        self.userProtocolUpdate = 0;
        self.userProtocolVersion = nil;
        self.vCurrencySwitch = 0;
        self.versionCode = nil;
        self.desSecretKey = nil;
    }
    return self;
}

+ (instancetype)config {
    static dispatch_once_t onceToken;
    static BXConfig *__defaultConfig = nil;
    dispatch_once(&onceToken, ^{
        __defaultConfig =  [[BXConfig alloc] init];
    });
    return __defaultConfig;
}

- (void)decodeFromDictionary:(NSDictionary *)dict {
    self.AP = [[dict objectForKey:@"AP"] integerValue] ;
    self.antiAddictionSwitch = [dict objectForKey:@"antiAddictionSwitch"];
    self.apiServer = [dict objectForKey:@"apiServer"];
    self.apilogUrl = [dict objectForKey:@"apilogUrl"];
    self.appH5Server = [dict objectForKey:@"appH5Server"];
    self.appH5WebUrl = [dict objectForKey:@"appH5WebUrl"];
    self.appServer = [[dict objectForKey:@"appServer"] integerValue];
    self.cdnImgServer = [dict objectForKey:@"cdnImgServer"];
    self.customerServiceUrl = [dict objectForKey:@"customerServiceUrl"];
    self.dos = [dict objectForKey:@"dos"];
    self.downloadUrl = [dict objectForKey:@"downloadUrl"];
    self.facebookLoginSwitch = [[dict objectForKey:@"facebookLoginSwitch"] integerValue];
    self.forceUpdate = [[dict objectForKey:@"forceUpdate"] integerValue];
    self.googleLoginSwitch = [[dict objectForKey:@"googleLoginSwitch"] integerValue];
    self.h5SdkUrl = [dict objectForKey:@"h5SdkUrl"];
    self.h5csServer = [dict objectForKey:@"h5csServer"];
    self.heartBeatInterval = [[dict objectForKey:@"heartBeatInterval"] integerValue] * 60;
    self.informationUrl = [dict objectForKey:@"informationUrl"];
    self.iosIdCode = [dict objectForKey:@"iosIdCode"];
    self.isSanBox = [[dict objectForKey:@"isSanBox"] integerValue];
    self.mcId = [dict objectForKey:@"mcId"];
    self.menu = [dict objectForKey:@"menu"];
    self.payWindow = [dict objectForKey:@"payWindow"];
    self.platformCoinMediaUrl = [dict objectForKey:@"platformCoinMediaUrl"];
    self.platformCoinName = [dict objectForKey:@"platformCoinName"];
    self.realNameAuthTip = [[dict objectForKey:@"realNameAuthTip"] integerValue];
    self.scId = [dict objectForKey:@"scId"];
    self.sdkmarkwords = [dict objectForKey:@"sdkmarkwords"];
    self.tuowoWxReturnUrl = [dict objectForKey:@"tuowoWxReturnUrl"];
    self.userPrivateProtocolUpdate = [[dict objectForKey:@"userPrivateProtocolUpdate"] integerValue];
    self.userPrivateVersion = [[dict objectForKey:@"userPrivateVersion"] stringValue];
    self.userProtocolRefuseBtn = [[dict objectForKey:@"userProtocolRefuseBtn"] integerValue];
    self.userProtocolUpdate = [[dict objectForKey:@"userProtocolUpdate"] integerValue];
    self.userProtocolVersion = [[dict objectForKey:@"userProtocolVersion"] stringValue];
    self.vCurrencySwitch = [[dict objectForKey:@"vCurrencySwitch"] integerValue];
    self.versionCode = [dict objectForKey:@"versionCode"];
    self.fastRegister = [[dict objectForKey:@"fastRegister"] integerValue];
    self.phoneRegister = [[dict objectForKey:@"phoneRegister"] integerValue];
    
    if (dict[@"grcDeviceInfo"]) { self.grcDeviceInfo = [dict objectForKey:@"grcDeviceInfo"]; }
    if (dict[@"grcDevicePermissions"]) { self.grcDevicePermissions = [dict objectForKey:@"grcDevicePermissions"]; }
    if (dict[@"grcAuthorityDerail"]) { self.grcAuthorityDerail = [[dict objectForKey:@"grcAuthorityDerail"] boolValue]; }
    
    if (dict[@"desSecretKey"]) { self.desSecretKey = [dict objectForKey:@"desSecretKey"]; }
}

- (void)decodeFromSeriesInitDictionary:(NSDictionary *)dict {
    if (dict[@"appId"]) {  [BXMobileManager shareManager].appID = [dict objectForKey:@"appId"]; }
    if (dict[@"appkey"]) {  [BXMobileManager shareManager].appKey = [dict objectForKey:@"appkey"]; }
    if (dict[@"platformId"]) {  self.platformId = [dict objectForKey:@"platformId"]; }
    
    if (dict[@"appServer"]) {  self.appServer = [[dict objectForKey:@"appServer"] integerValue]; }
    if (dict[@"fastRegister"]) {  self.fastRegister = [[dict objectForKey:@"fastRegister"] integerValue]; }
    if (dict[@"phoneRegister"]) {  self.phoneRegister = [[dict objectForKey:@"phoneRegister"] integerValue]; }
    
    self.cdnImgServer = [dict objectForKey:@"cdnImgServer"];
}

- (void)decodeFromSeriesGameDictionary:(NSDictionary *)dict {
    if (dict  && [dict isKindOfClass:[NSDictionary class]]) {
        [BXMobileManager shareManager].appID = [dict objectForKey:@"gameId"];
        [BXMobileManager shareManager].appKey = [dict objectForKey:@"appkey"];
        
        self.gameId = dict[@"gameId"];
        self.gameName = dict[@"gameName"];
        self.gameSerieId = dict[@"gameSerieId"];
        self.specialSign = dict[@"specialSign"];
        self.scId = dict[@"scId"];
        self.mcId = dict[@"mcId"];
        self.platformId = dict[@"platformId"];
        self.userId =  dict[@"userId"];
    }
}

- (BOOL)isNeedShowProtocol {
    
    self.localUserProtocolVersion = [[NSUserDefaults standardUserDefaults] objectForKey:@"localUserProtocolVersion"];
    self.localUserPrivateVersion = [[NSUserDefaults standardUserDefaults] objectForKey:@"localUserPrivateVersion"];
    
    // 服务端必须有版本，如果其一没有，则不弹出
    if (![BXPrivacyUtil stringIsdigit:self.userProtocolVersion] ||
        ![BXPrivacyUtil stringIsdigit:self.userPrivateVersion]) {
        return NO;
    }
    
    // 第一次进入应用时显示
    if (![BXPrivacyUtil isStringAndAvail:self.localUserProtocolVersion] &&
        ![BXPrivacyUtil isStringAndAvail:self.localUserPrivateVersion]) {
        return YES;
    }
    
    // 判断版本号是否为数字，不是则不弹出
    if (![NSString isdigit:self.userProtocolVersion] ||
        ![NSString isdigit:self.userPrivateVersion]) {
        return NO;
    }
    
    // 版本号不一致，且提示为1时，弹出
    if (![self.userProtocolVersion isEqualToString:self.localUserProtocolVersion] && self.userProtocolUpdate == 1) {
        return YES;
    }
    if (![self.userPrivateVersion isEqualToString:self.localUserPrivateVersion] && self.userPrivateProtocolUpdate == 1) {
        return YES;
    }
    
    return NO;
}

- (void)agreedSync {
    [[NSUserDefaults standardUserDefaults] setObject:self.userProtocolVersion forKey:@"localUserProtocolVersion"];
    [[NSUserDefaults standardUserDefaults] setObject:self.userPrivateVersion forKey:@"localUserPrivateVersion"];
    self.localUserProtocolVersion = self.userProtocolVersion;
    self.localUserPrivateVersion = self.userPrivateVersion;
}

- (NSString *)platformId {
    if (!_platformId) {
        NSDictionary *dict =  [BXHelper paltformInfoDictionary];
        NSAssert(dict != nil, @"PlatformConfig配置表读取失败");
        NSString *configTypeString = [dict objectForKey:@"platformId"];
        NSAssert(configTypeString != nil, @"paltformId 字段读取失败");
        self.configType = [configTypeString integerValue];
        _platformId = [self proxyPlatformIdBy:self.configType];
    }
    return _platformId;
}

- (BOOL)isTestFlight {
    NSDictionary *dict =  [BXHelper paltformInfoDictionary];
    NSAssert(dict != nil, @"PlatformConfig配置表读取失败");
    id isTestFlight = [dict objectForKey:@"isTestFlight"];
    NSAssert(isTestFlight != nil, @"isTestFlight 字段读取失败");
    _isTestFlight = [isTestFlight boolValue];
    return _isTestFlight;
}

//- (BOOL)isSeries {
//    NSDictionary *dict =  [BXHelper paltformInfoDictionary];
//    NSAssert(dict != nil, @"PlatformConfig配置表读取失败");
//    id isSeries = [dict objectForKey:@"isSeries"];
//    NSAssert(isSeries != nil, @"isSeries 字段读取失败");
//    _isSeries = [isSeries boolValue];
//    return _isSeries;
//}

- (NSString *)sdkVersion {
    if (!_sdkVersion) {
        NSDictionary *dict =  [BXHelper versionInfoDictionary];
        NSAssert(dict != nil, @"Version配置表读取失败");
        _sdkVersion =  dict[@"sdk"][@"version"];
    }
    return _sdkVersion;
}

- (NSString *)proxyPlatformIdBy:(PlatformType)type {
    switch (_configType) {
        case Platform_VV:
            return @"VVSdk";
        case Platform_5uwan:
            return @"5uwanNew";
        case Platform_9csy:
            return @"9csyNew";
        case Platform_25vs:
            return @"25vsNew";
        case Platform_76sy:
            return @"76syNew";
        case Platform_83yxw:
            return @"83yxwNew";
        case Platform_87yxw:
            return @"87yxwNew";
        case Platform_93sy:
            return @"93syNew";
        case Platform_137game:
            return @"137gameNew";
        case Platform_168:
            return @"168New";
        case Platform_200sy:
            return @"200syNew";
        case Platform_251game:
            return @"251gameNew";
        case Platform_718yx:
            return @"718yxNew";
        case Platform_917youxi:
            return @"917youxiNew";
        case Platform_1766you:
            return @"1766youNew";
        case Platform_1799k:
            return @"1799kNew";
        case Platform_5266:
            return @"5266New";
        case Platform_8000yx:
            return @"8000yxNew";
        case Platform_aiyule://爱娱乐
            return @"2ylNew";
        case Platform_bqwan:
            return @"bqwanNew";
        case Platform_c2wx:
            return @"c2wxNew";
        case Platform_juyou8:
            return @"juyou8New";
        case Platform_pywan:
            return @"pywanNew";
        case Platform_339sy:
            return @"339syNew";
        case Platform_153wan:
            return @"153wanNew";
        case Platform_780yx:
            return @"780yxNew";
        case Platform_631yx:
            return @"631yxNew";
        case Platform_439sy:
            return @"vv439sy";
        case Platform_755sy:
            return @"vv755sy";
        case Platform_811sy:
            return @"vv811sy";
        case Platform_975sy:
            return @"vv975sy";
        case Platform_455sy:
            return @"vv455sy";
        case Platform_288sy:
            return @"288sy";
        case Platform_998sy:
            return @"998sy";
        case Platform_3dsyw:
            return @"3dsyw";
        case Platform_toyou:
            return @"toyou";
        case Platform_y8:
            return @"y8";
        case Platform_76box:
            return @"76box";
        default:
            NSAssert(0, @"获取到未知platformID");
            return @"";
    }
}

@end
