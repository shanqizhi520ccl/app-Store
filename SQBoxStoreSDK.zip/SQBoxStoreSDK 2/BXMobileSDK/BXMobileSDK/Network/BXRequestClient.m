//
//  BXRequestClient.m
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/2.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXRequestClient.h"
#import "BXRequest.h"
#import "BXResponse.h"
#import "NSDictionary+BXMobileSDK.h"
#import "BXError.h"
#import "BXMBProgressHUD+BXExtern.h"

@interface BXRequestClient ()
@property (nonatomic) dispatch_queue_t reqQueue;
@end

@implementation BXRequestClient

static BXRequestClient *__client = nil;

+ (instancetype)shareClient {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        __client = [[BXRequestClient alloc] init];
    });
    return __client;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.reqQueue = dispatch_queue_create( "com.gavin.BXMobileSDK.requset.queue", DISPATCH_QUEUE_SERIAL);
        
        @weakify(self)
        self.taskBeats = [[BXTaskConfigBeats alloc] init];
        self.taskBeats.configBlock = ^(BXTaskConfigBeats *taskBeats) {
            @strongify(self)
            BXLogDebug(@"task config beats");
            BXRequest *reqConfig = BXMobileSDKBlockRun(taskBeats.taskConfigBlock);
            if (reqConfig) {
                [self sendRequest:reqConfig];
            }
        };
    }
    return self;
}

- (NSURLSessionDataTask *)sendRequest:(BXRequest *)requset {
    if (!requset) {
        BXLogError(@"Request should not be nil");
        return nil;
    }

    __block BXMBProgressHUD *hud = nil;
    
    dispatch_async(dispatch_get_main_queue(), ^{
        if (requset.enabelLoadingIndicator) {
            hud = [self showHudIndicator:nil];
        }
    });
    
    BXLogDebug(@"send request: [url :%@]", requset.URL.absoluteString);
    NSURLSession *session = [NSURLSession sharedSession];
    __block NSURLSessionDataTask *sessionDataTask = nil;
    
    dispatch_async(self.reqQueue, ^{
        sessionDataTask = [session dataTaskWithRequest:requset completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
            BXResponse *result = nil;
            dispatch_async(dispatch_get_main_queue(), ^{
                if (hud) { [hud bx_hide]; }
            });
            
            if (!error) {
                NSDictionary *metadata = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
                if (error) {
                    result = [[BXResponse alloc] initWithResponse:response data:nil state:error.code desc:error.localizedDescription];
                    
                    NSString *jsonStr = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                    if ([[NSData data] isEqual:data] ) {
                        //返回数据为空
                        BXLogWarn(@"Recieved empty data: %@", data);
                    }else{
                        //数据格式错误
                        BXLogError(@"Recieved dump data: %@", jsonStr);
                    }
                }else{
                    BXLogVerbose(@"Recieved data: [%@], response:\n%@", response.URL.absoluteString, metadata);
                    NSNumber *ret = nil;
                    NSString *msg = nil;
                    
                    if (metadata) {
                        ret = [metadata safetyNumberForKey:@"state"];
                        msg = [metadata safetyStringForKey:@"desc"];
                    }
                
                    if (ret && ret.integerValue == 1) {
                        //网络请求成功 ret=1
                        result = [[BXResponse alloc] initWithResponse:response data:metadata state:ret.integerValue desc:msg];
                    }else{
                        if (!ret) {
                            //网络请求失败，未返回状态码 ret==nil
                            error = [BXError errorWithCode:HTTP_ERROR_NONE_RET_CODE message:msg];
                            result = [[BXResponse alloc] initWithResponse:response data:metadata state:error.code desc:error.localizedDescription];
                        }else{
                            //网络请求失败 ret!=1
                            error = [BXError errorWithCode:ret.intValue message:msg];
                            result = [[BXResponse alloc] initWithResponse:response data:metadata state:error.code desc:error.localizedDescription];
                        }
                    }
                }
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (requset.complement) {
                        requset.complement(result, error);
                    }
                });
            }else{
                if (requset.complement) {
                    BXResponse *result = [[BXResponse alloc] initWithResponse:response data:nil state:error.code desc:error.localizedDescription];
                    dispatch_async(dispatch_get_main_queue(), ^{
                        if (requset.complement) {
                            requset.complement(result, error);
                        }
                    });
                }
            }
        }];
        [sessionDataTask resume];
    });
    
    return sessionDataTask;
}

#pragma mark - SHOW MESSAGE

- (BXMBProgressHUD *)showHudIndicator:(NSString *)message {
    return [BXMBProgressHUD bx_showIndicator:message];
}

@end
