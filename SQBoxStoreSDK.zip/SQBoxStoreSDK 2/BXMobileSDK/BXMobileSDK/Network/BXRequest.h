//
//  BXRequest.h
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/10.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import <Foundation/Foundation.h>

//NS_ASSUME_NONNULL_BEGIN

@class BXRequest, BXResponse;

typedef void(^BXRequestComplement)(BXResponse *response, NSError *error);

@interface BXRequest : NSMutableURLRequest

@property (nonatomic, readwrite) BOOL enabelLoadingIndicator;

@property (nonatomic, readonly) NSDictionary *paramers;

@property (nonatomic, copy) BXRequestComplement complement;

/**
 *  Creates a new GET request.
 *  @param endpoint The endpoint to send the request, relative to the base platform URL (i.e. nudge/api/users/@me/meals)
 *  @param params   A dictionary of paramters to send with the request.
 */
+ (BXRequest *)getRequestWithHost:(NSString *)host endpoint:(NSString *)endpoint params:(NSDictionary *)params;
/**
 *  Creates a new POST request.
 *  @param endpoint The endpoint to send the request, relative to the base platform URL (i.e. nudge/api/users/@me/meals)
 *  @param params   A dictionary of paramters to send with the request.
 */
+ (BXRequest *)postRequestWithHost:(NSString *)host endpoint:(NSString *)endpoint  params:(NSDictionary *)params;

@end

//NS_ASSUME_NONNULL_END
