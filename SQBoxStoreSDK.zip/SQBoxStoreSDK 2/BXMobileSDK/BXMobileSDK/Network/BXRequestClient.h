//
//  BXRequestClient.h
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/2.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BXTaskConfigBeats.h"
#import "BXRequest.h"
#import "BXResponse.h"

@class BXRequest, BXResponse;

@interface BXRequestClient : NSObject

//自动任务
@property (nonatomic, strong) BXTaskConfigBeats *taskBeats;

//单例对象
+ (instancetype)shareClient;

//发送网络请求
- (NSURLSessionDataTask *)sendRequest:(BXRequest *)requset;

@end

