//
//  BXConfig.h
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/14.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import <Foundation/Foundation.h>

//NS_ASSUME_NONNULL_BEGIN

typedef enum : NSInteger {
    BXConfigStateNONE = 0,
    BXConfigStateING = 1,
    BXConfigStateSUC = 2,
}BXConfigState;

typedef enum : NSUInteger {
    Platform_VV = 1000,
    Platform_5uwan = 1001,
    Platform_9csy = 1002,
    Platform_25vs = 1003,
    Platform_76sy = 1004,
    Platform_83yxw = 1005,
    Platform_87yxw = 1006,
    Platform_93sy = 1007,
    Platform_137game = 1008,
    Platform_168 = 1009,
    Platform_200sy = 1010,
    Platform_251game = 1011,
    Platform_718yx = 1012,
    Platform_917youxi = 1013,
    Platform_1766you = 1014,
    Platform_1799k = 1015,
    Platform_5266 = 1016,
    Platform_8000yx = 1017,
    Platform_aiyule = 1018,
    Platform_bqwan = 1019,
    Platform_c2wx = 1020,
    Platform_juyou8 = 1021,
    Platform_pywan = 1022,
    Platform_339sy = 1023,
    Platform_153wan = 1024,
    Platform_780yx = 1025,
    Platform_631yx = 1026,
    Platform_439sy = 1027,
    Platform_755sy = 1028,
    Platform_811sy = 1029,
    Platform_975sy = 1030,
    Platform_455sy = 1031,
    Platform_288sy = 1033,
    Platform_998sy = 1034,
    Platform_3dsyw = 1035,
    Platform_toyou = 1036,
    Platform_y8 = 1037,
    Platform_76box = 1038,
} PlatformType;

@interface BXConfig : NSObject

@property (nonatomic) BXConfigState configState;

@property (nonatomic, assign) NSInteger AP;
@property (nonatomic, copy) NSString *antiAddictionSwitch;
@property (nonatomic, copy) NSString *apiServer;
@property (nonatomic, copy) NSString *apilogUrl;
@property (nonatomic, copy) NSString *appH5Server;
@property (nonatomic, copy) NSString *appH5WebUrl;
@property (nonatomic, assign) NSInteger appServer;
@property (nonatomic, copy) NSString *cdnImgServer;
@property (nonatomic, copy) NSString *customerServiceUrl;
@property (nonatomic, strong) NSArray *dos;
@property (nonatomic, copy) NSString *downloadUrl;
@property (nonatomic, assign) NSInteger facebookLoginSwitch;
@property (nonatomic, assign) NSInteger fastRegister;
@property (nonatomic, assign) NSInteger forceUpdate;
@property (nonatomic, assign) NSInteger googleLoginSwitch;
@property (nonatomic, copy) NSString *h5SdkUrl;
@property (nonatomic, copy) NSString *h5csServer;
@property (nonatomic, assign) NSInteger heartBeatInterval;
@property (nonatomic, copy) NSString *informationUrl;
@property (nonatomic, copy) NSString *iosIdCode;
@property (nonatomic, assign) NSInteger isSanBox;
@property (nonatomic, copy) NSString *mcId;
@property (nonatomic, strong) NSArray *menu;
@property (nonatomic, strong) NSArray *payWindow;
@property (nonatomic, assign) NSInteger phoneRegister;
@property (nonatomic, copy) NSString *platformCoinMediaUrl;
@property (nonatomic, copy) NSString *platformCoinName;
@property (nonatomic, assign) NSInteger realNameAuthTip;
@property (nonatomic, copy) NSString *scId;
@property (nonatomic, copy) NSString *sdkmarkwords;
@property (nonatomic, copy) NSString *tuowoWxReturnUrl;
@property (nonatomic, assign) NSInteger userPrivateProtocolUpdate;
@property (nonatomic, copy) NSString *userPrivateVersion;
@property (nonatomic, assign) NSInteger userProtocolRefuseBtn;
@property (nonatomic, assign) NSInteger userProtocolUpdate;
@property (nonatomic, copy) NSString *userProtocolVersion;
@property (nonatomic, assign) NSInteger vCurrencySwitch;
@property (nonatomic, copy) NSString *versionCode;

@property (nonatomic) PlatformType configType;
@property (nonatomic) NSString *platformId;
@property (nonatomic) BOOL isTestFlight;
@property (nonatomic) BOOL isSeries;
@property (nonatomic) NSString *sdkVersion;

@property (nonatomic) NSString *userId;
@property (nonatomic) NSString *gameId;
@property (nonatomic) NSString *gameName;
@property (nonatomic) NSString *gameSerieId;
@property (nonatomic) NSString *specialSign;

/// 2021年08月
@property(assign, nonatomic) BOOL grcAuthorityDerail;
@property(strong, nonatomic) NSString *grcDeviceInfo;
@property(strong, nonatomic) NSString *grcDevicePermissions;
/// 2021年09月
@property(strong, nonatomic) NSString *localUserProtocolVersion;
@property(strong, nonatomic) NSString *localUserPrivateVersion;

/// 2021年10月
@property(strong, nonatomic) NSString *desSecretKey;

/// 是否需要展示协议
- (BOOL)isNeedShowProtocol;
/// 同步协议版本
- (void)agreedSync;

//默认配置项
+ (instancetype)config;

- (void)decodeFromDictionary:(NSDictionary *)dict;
- (void)decodeFromSeriesInitDictionary:(NSDictionary *)dict;
- (void)decodeFromSeriesGameDictionary:(NSDictionary *)dict;

@end

//NS_ASSUME_NONNULL_END
