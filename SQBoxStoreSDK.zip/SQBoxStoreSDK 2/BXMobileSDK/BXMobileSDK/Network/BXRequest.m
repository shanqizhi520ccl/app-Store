//
//  BXRequest.m
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/10.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXRequest.h"
#import "BXMobileManager+Private.h"
#import "BXDevice.h"
#import "BXDefine.h"
#import "BXConfig.h"
#import "NSString+BXExtern.h"
#import "BXPackage.h"

static  NSString * const errorDomain = @"com.BXAuthManager.network.error.domain";

/// 获取sign参数
static NSString *BXGenerateSign(NSDictionary *parems, NSString *key) {
    //将所有请求参数的key按照字典序升序排序后拼接为key1=value1&key2=value2...的形式,在最末 尾拼接上&signkey得到源串串, 源串串md5后转⼩写即为签名
    NSArray *sortedKeys = [parems.allKeys sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2) {
        return [obj1 compare:obj2 options:NSNumericSearch];
    }];
        
    NSMutableArray *paramStrings = [NSMutableArray array];
    for (NSString *key in sortedKeys) {
        [paramStrings addObject:[NSString stringWithFormat:@"%@=%@", key, parems[key]]];
    }
    
    NSMutableString *ret = [[paramStrings componentsJoinedByString:@"&"] mutableCopy] ;
    [ret appendFormat:@"%@", key];
    
    return [[ret bx_md5] lowercaseString];
}

NSString * BXPercentEscapedStringFromString(NSString *string) {
    static NSString * const kAFCharactersGeneralDelimitersToEncode = @":#[]@"; // does not include "?" or "/" due to RFC 3986 - Section 3.4
    static NSString * const kAFCharactersSubDelimitersToEncode = @"!$&'()*+,;=";

    NSMutableCharacterSet * allowedCharacterSet = [[NSCharacterSet URLQueryAllowedCharacterSet] mutableCopy];
    [allowedCharacterSet removeCharactersInString:[kAFCharactersGeneralDelimitersToEncode stringByAppendingString:kAFCharactersSubDelimitersToEncode]];

// FIXME: https://github.com/AFNetworking/AFNetworking/pull/3028
// return [string stringByAddingPercentEncodingWithAllowedCharacters:allowedCharacterSet];

    static NSUInteger const batchSize = 50;

    NSUInteger index = 0;
    NSMutableString *escaped = @"".mutableCopy;

    while (index < string.length) {
        NSUInteger length = MIN(string.length - index, batchSize);
        NSRange range = NSMakeRange(index, length);

        // To avoid breaking up character sequences such as 👴🏻👮🏽
        range = [string rangeOfComposedCharacterSequencesForRange:range];

        NSString *substring = [string substringWithRange:range];
        NSString *encoded = [substring stringByAddingPercentEncodingWithAllowedCharacters:allowedCharacterSet];
        [escaped appendString:encoded];

        index += range.length;
    }

    return escaped;
}

@interface BXQueryStringPair : NSObject
@property (readwrite, nonatomic, strong) id field;
@property (readwrite, nonatomic, strong) id value;

- (instancetype)initWithField:(id)field value:(id)value;
- (NSString *)URLEncodedStringValue;
@end

@implementation BXQueryStringPair

- (instancetype)initWithField:(id)field value:(id)value {
    self = [super init];
    if (!self) {
        return nil;
    }

    self.field = field;
    self.value = value;

    return self;
}

- (NSString *)URLEncodedStringValue {
    if (!self.value || [self.value isEqual:[NSNull null]]) {
        return BXPercentEscapedStringFromString([self.field description]);
    } else {
        return [NSString stringWithFormat:@"%@=%@", BXPercentEscapedStringFromString([self.field description]), BXPercentEscapedStringFromString([self.value description])];
    }
}

@end

FOUNDATION_EXPORT NSArray * BXQueryStringPairsFromDictionary(NSDictionary *dictionary);
FOUNDATION_EXPORT NSArray * BXQueryStringPairsFromKeyAndValue(NSString *key, id value);

NSString * BXQueryStringFromParameters(NSDictionary *parameters) {
    NSMutableArray *mutablePairs = [NSMutableArray array];
    NSArray *array = BXQueryStringPairsFromDictionary(parameters);
    for (BXQueryStringPair *pair in array) {
        [mutablePairs addObject:[pair URLEncodedStringValue]];
    }

    return [mutablePairs componentsJoinedByString:@"&"];
}

NSArray * BXQueryStringPairsFromDictionary(NSDictionary *dictionary) {
    return BXQueryStringPairsFromKeyAndValue(nil, dictionary);
}

NSArray * BXQueryStringPairsFromKeyAndValue(NSString *key, id value) {
    NSMutableArray *mutableQueryStringComponents = [NSMutableArray array];

    NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"description" ascending:YES selector:@selector(compare:)];

    if ([value isKindOfClass:[NSDictionary class]]) {
        NSDictionary *dictionary = value;
        // Sort dictionary keys to ensure consistent ordering in query string, which is important when deserializing potentially ambiguous sequences, such as an array of dictionaries
        for (id nestedKey in [dictionary.allKeys sortedArrayUsingDescriptors:@[ sortDescriptor ]]) {
            id nestedValue = dictionary[nestedKey];
            if (nestedValue) {
                [mutableQueryStringComponents addObjectsFromArray:BXQueryStringPairsFromKeyAndValue((key ? [NSString stringWithFormat:@"%@[%@]", key, nestedKey] : nestedKey), nestedValue)];
            }
        }
    } else if ([value isKindOfClass:[NSArray class]]) {
        NSArray *array = value;
        for (id nestedValue in array) {
            [mutableQueryStringComponents addObjectsFromArray:BXQueryStringPairsFromKeyAndValue([NSString stringWithFormat:@"%@[]", key], nestedValue)];
        }
    } else if ([value isKindOfClass:[NSSet class]]) {
        NSSet *set = value;
        for (id obj in [set sortedArrayUsingDescriptors:@[ sortDescriptor ]]) {
            [mutableQueryStringComponents addObjectsFromArray:BXQueryStringPairsFromKeyAndValue(key, obj)];
        }
    } else {
        [mutableQueryStringComponents addObject:[[BXQueryStringPair alloc] initWithField:key value:value]];
    }

    return mutableQueryStringComponents;
}





@interface BXRequest ()

@property (nonatomic, strong, readwrite) NSDictionary *paramers;

@end

@implementation BXRequest

NSTimeInterval const kDefaultRequestTimeout = 30.0;

- (NSString *)description
{
    return [NSString stringWithFormat:@"%@ { Method: %@, HTTPBody: %@ }", [super description], self.HTTPMethod, [[NSString alloc] initWithData:self.HTTPBody encoding:NSUTF8StringEncoding]];
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.timeoutInterval = kDefaultRequestTimeout;
        self.enabelLoadingIndicator = YES;
    }
    return self;
}

- (instancetype)initWithURL:(NSURL *)URL cachePolicy:(NSURLRequestCachePolicy)cachePolicy timeoutInterval:(NSTimeInterval)timeoutInterval {
    self = [super initWithURL:URL cachePolicy:cachePolicy timeoutInterval:timeoutInterval];
    if (self) {
        self.timeoutInterval = kDefaultRequestTimeout;
        self.enabelLoadingIndicator = YES;
    }
    return self;
}

#pragma mark Initialization

+ (BXRequest *)getRequestWithHost:(NSString *)host endpoint:(NSString *)endpoint params:(NSDictionary *)params
{
    return [[BXRequest alloc] initWithHost:host endpoint:endpoint params:params method:@"GET"];
}

+ (BXRequest *)postRequestWithHost:(NSString *)host endpoint:(NSString *)endpoint  params:(NSDictionary *)params
{
    return [[BXRequest alloc] initWithHost:host endpoint:endpoint params:params method:@"POST"];
}

- (instancetype)initWithHost:(NSString *)host endpoint:(NSString *)endpoint params:(NSDictionary *)aParams method:(NSString *)method
{
    NSString *baseURL = host;

    NSString *url = [NSString stringWithFormat:@"%@%@", baseURL, endpoint];
    self = [self initWithURL:[NSURL URLWithString:url] cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:kDefaultRequestTimeout];
    if (self)
    {
        BOOL isPost = [method isEqualToString:@"POST"];
        self.HTTPMethod = method;
        self.paramers = aParams;
        
        NSMutableDictionary *fullParams = [[BXPackage publicParameters] mutableCopy];
        [fullParams addEntriesFromDictionary:aParams];
#warning 2021年10月22日10:49:25 sdk信息加密
        [fullParams setValue:@"9.9.9" forKey:@"sdkVersion"];
        
        if ([endpoint containsString:@"SDKSeriesLogin"]||
            [endpoint containsString:@"seriesSdkinit"]) {
            [fullParams setValue:BXGenerateSign(fullParams, [BXMobileManager shareManager].seriesAppKey) forKey:@"sign"];
        } else{
            [fullParams setValue:BXGenerateSign(fullParams, [BXMobileManager shareManager].appKey) forKey:@"sign"];
        }
        
        BXLogVerbose(@"Create Request: [url: %@], parameters: \n%@", url, fullParams);
        if (isPost) {
            NSString *query = BXQueryStringFromParameters(fullParams);
            self.HTTPBody = [query dataUsingEncoding:NSUTF8StringEncoding];
            
        } else if (fullParams != nil)
        {
            NSString *query = BXQueryStringFromParameters(fullParams);
            self.URL = [NSURL URLWithString:[NSString stringWithFormat:@"%@?%@", self.URL.absoluteString, query]];
        }
        
        NSDictionary *headers = [self createRequestHeadersForPost:isPost isMultipart:NO];
        for (NSString *key in headers.allKeys){
            [self setValue:headers[key] forHTTPHeaderField:key];
        }
    }
    
    return self;
}

#pragma mark Request Setup

NSString const *APIMultipartBoundary = @"t5abJf886c95bfexhOzryaoq2xuedO34ru8osiqbSrg9pqbeTf";

- (NSDictionary *)createRequestHeadersForPost:(BOOL)isPost isMultipart:(BOOL)isMultipart {
    NSMutableDictionary *headers = [@{} mutableCopy];
    if (isMultipart){
        NSDictionary *additionalHeaders = @{
            @"Content-Type" : [NSString stringWithFormat:@"multipart/form-data; boundary=%@", APIMultipartBoundary]
        };
        [headers addEntriesFromDictionary:additionalHeaders];
    }else if (isPost){
        NSDictionary *additionalHeaders = @{
            @"Content-Type" : @"application/x-www-form-urlencoded",
            @"enctype" : @"application/x-www-form-urlencoded"
        };
        [headers addEntriesFromDictionary:additionalHeaders];
    }
    return headers;
}

@end
 
