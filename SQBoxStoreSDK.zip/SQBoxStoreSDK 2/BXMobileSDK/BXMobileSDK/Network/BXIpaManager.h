//
//  BXIpaManager.h
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/31.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <StoreKit/StoreKit.h>

//NS_ASSUME_NONNULL_BEGIN

@interface BXTransaction : NSObject<NSCoding>
@property(nonatomic, copy, readonly) NSString *transactionIdentifier;
@property(nonatomic, copy, readonly) NSString *productIdentifier;
@property(nonatomic, strong, readonly) NSString *reciept;
@property(nonatomic, strong, readonly) NSDate *transactionDate;
@property(nonatomic, copy) NSString *orderNo;
@property(nonatomic, copy) NSString *priceTagString;
@property(nonatomic, copy, readonly) NSString *md5;
@property(nonatomic, assign) NSUInteger modelVerifyCount;
@property(nonatomic, assign) BOOL isTransactionValidFromService;

- (instancetype)initWithProductIdentifier:(NSString *)productIdentifier
                                  reciept:(NSString *)reciept
                    transactionIdentifier:(NSString *)transactionIdentifier
                          transactionDate:(NSDate *)transactionDate;

@end

@interface BXIpaManager : NSObject

+ (instancetype)sharedObject;
- (void)setProductSet:(NSSet<NSString *> *)productIdSet;
- (void)makeStore:(NSDictionary *)info;
- (void)checkUnfinishedTransaction;

@end

//NS_ASSUME_NONNULL_END
