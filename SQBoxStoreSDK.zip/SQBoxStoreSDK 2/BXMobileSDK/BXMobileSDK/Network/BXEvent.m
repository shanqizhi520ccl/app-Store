//
//  BXEvent.m
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/13.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXEvent.h"
#import "BXRequestClient.h"
#import "BXPackage.h"
#import "BXConfig.h"
#import "BXUser.h"
#import "BXMobileManager+Private.h"
#import "BXRSAEncryptor.h"
#import "BXPrivacyUtil.h"

@implementation BXEvent

+ (void)bx_doConfig {
    [BXRequestClient shareClient].taskBeats.taskConfigBlock = nil;
    BXLogInfo(@"Platform ID = %@", [BXConfig config].platformId);
    
    [BXRequestClient shareClient].taskBeats.taskConfigBlock = ^BXRequest *{
        if ([BXConfig config].configState == BXConfigStateING) {
            return nil;
        }
        
        [BXConfig config].configState = BXConfigStateING;

        NSDictionary *params = [BXPackage pacForConfig:[BXConfig config].isSeries];
        BXRequest *requset = nil;
        if ([BXConfig config].isSeries) {
            requset = [BXRequest postRequestWithHost:[BXMobileManager basePlatformURL] endpoint:@"Api/seriesSdkinit.do" params:params];
        }else{
            requset = [BXRequest postRequestWithHost:[BXMobileManager basePlatformURL] endpoint:@"Api/SDKInit.do" params:params];
        }
        
        requset.enabelLoadingIndicator = NO;
        requset.complement = ^(BXResponse *response, NSError *error) {
            if (!error) {
                [BXConfig config].configState = BXConfigStateSUC;
                if (!response.data) {
                    BXLogError(@"Get config error: empty data!");
                    [BXConfig config].configState = BXConfigStateNONE;
                    return;
                }else if (response.state != 1){
                    BXLogError(@"Get config error: {code:%d, msg:%@}", response.state, response.desc);
                    [BXConfig config].configState = BXConfigStateNONE;
                    return;
                }else{
                    BXLogInfo(@"初始化成功!");
                    [BXRequestClient shareClient].taskBeats.isConfigOver = YES;
                    
                    BXConfig *config = [BXConfig config];
                    if (config.isSeries) {
                        [config decodeFromSeriesInitDictionary:response.data];
                    }else{
                        [config decodeFromDictionary:response.data];
                    }
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:BXRegisterAppSuccessNotification object:@{@"appServer":@(config.appServer)}];
                }
            }else{
                BXLogDebug(@"Config complet: {error:%@}", error);
                [BXConfig config].configState = BXConfigStateNONE;
            }
        };
        
        return requset;
    };
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [[BXRequestClient shareClient].taskBeats start];
    });
}

+ (void)bx_doConfig:(BXEventComplement)complement {
    [BXRequestClient shareClient].taskBeats.taskConfigBlock = nil;
    BXLogInfo(@"Platform ID = %@", [BXConfig config].platformId);
    
    [BXRequestClient shareClient].taskBeats.taskConfigBlock = ^BXRequest *{
        if ([BXConfig config].configState == BXConfigStateING) {
            return nil;
        }
        
        [BXConfig config].configState = BXConfigStateING;

        NSDictionary *params = [BXPackage pacForConfig:[BXConfig config].isSeries];
        BXRequest *requset = nil;
        if ([BXConfig config].isSeries) {
            requset = [BXRequest postRequestWithHost:[BXMobileManager basePlatformURL] endpoint:@"Api/seriesSdkinit.do" params:params];
        }else{
            requset = [BXRequest postRequestWithHost:[BXMobileManager basePlatformURL] endpoint:@"Api/SDKInit.do" params:params];
        }
        
        requset.enabelLoadingIndicator = NO;
        requset.complement = ^(BXResponse *response, NSError *error) {
            if (!error) {
                [BXConfig config].configState = BXConfigStateSUC;
                if (!response.data) {
                    BXLogError(@"Get config error: empty data!");
                    [BXConfig config].configState = BXConfigStateNONE;
                    return;
                }else if (response.state != 1){
                    BXLogError(@"Get config error: {code:%d, msg:%@}", response.state, response.desc);
                    [BXConfig config].configState = BXConfigStateNONE;
                    return;
                }else{
                    BXLogInfo(@"初始化成功!");
                    [BXRequestClient shareClient].taskBeats.isConfigOver = YES;
                    
                    BXConfig *config = [BXConfig config];
                    if (config.isSeries) {
                        [config decodeFromSeriesInitDictionary:response.data];
                    }else{
                        [config decodeFromDictionary:response.data];
                    }
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:BXRegisterAppSuccessNotification object:@{@"appServer":@(config.appServer)}];
                }
                if (complement) {
                    complement(response, error);
                }
            }else{
                BXLogDebug(@"Config complet: {error:%@}", error);
                [BXConfig config].configState = BXConfigStateNONE;
            }
        };
        
        return requset;
    };
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [[BXRequestClient shareClient].taskBeats start];
    });
}

+ (void)bx_doSeriesInitlized:(BXEventComplement)complement {
    NSDictionary *params = [BXPackage pacForConfig:[BXConfig config].isSeries];
    BXRequest *requset = requset = [BXRequest postRequestWithHost:[BXMobileManager basePlatformURL] endpoint:@"Api/seriesSdkinit.do" params:params];
    requset.enabelLoadingIndicator = NO;
    requset.complement = ^(BXResponse *response, NSError *error) {
        if (!error) {
            BXConfig *config = [BXConfig config];
            [config decodeFromSeriesInitDictionary:response.data];
        }
        
        if (complement) {
            complement(response, error);
        }
    };
    [[BXRequestClient shareClient] sendRequest:requset];
}

+ (void)bx_doInitlized:(BXEventComplement)complement {
    NSDictionary *params = [BXPackage pacForConfig:NO];
    BXRequest *requset = requset = [BXRequest postRequestWithHost:[BXMobileManager basePlatformURL] endpoint:@"Api/SDKInit.do" params:params];
    requset.enabelLoadingIndicator = NO;
    requset.complement = ^(BXResponse *response, NSError *error) {
        if (!error) {
            BXConfig *config = [BXConfig config];
            [config decodeFromDictionary:response.data];
        }
        
        if (complement) {
            complement(response, error);
        }
    };
    [[BXRequestClient shareClient] sendRequest:requset];
}

+ (void)bx_doGetSmsCode:(NSString *)phoneNumber smsType:(NSInteger)smsType complement:(BXEventComplement)complement{
    if ([BXConfig config].configState != BXConfigStateSUC) {
        if (complement) {
            NSError *error = [NSError errorWithDomain:@"" code:-1 userInfo:@{NSLocalizedDescriptionKey:@"初始化未完成，请稍后操作"}];
            complement(nil, error);
        }
        return;
    }
    
    NSDictionary *params = [BXPackage pacForSmsCode:phoneNumber smsType:smsType];
    BXRequest *requset = [BXRequest postRequestWithHost:[BXMobileManager basePlatformURL] endpoint:@"Api/SendMsg.do" params:params];
    requset.complement = ^(BXResponse *response, NSError *error) {
        if (complement) {
            complement(response.data, error);
        }
    };
    [[BXRequestClient shareClient] sendRequest:requset];
}

+ (void)bx_doRegisterByMobile:(NSString *)phoneNumber smsCode:(NSString *)smsCode password:(NSString *)password complement:(BXEventComplement)complement{
    if ([BXConfig config].configState != BXConfigStateSUC) {
        if (complement) {
            NSError *error = [NSError errorWithDomain:@"" code:-1 userInfo:@{NSLocalizedDescriptionKey:@"初始化未完成，请稍后操作"}];
            complement(nil, error);
        }
        return;
    }
    NSDictionary *params = [BXPackage pacForRegisterByMobile:phoneNumber msgCode:smsCode password:password];
    BXRequest *requset = [BXRequest postRequestWithHost:[BXMobileManager basePlatformURL] endpoint:@"Api/Register.do" params:params];
    requset.complement = ^(BXResponse *response, NSError *error) {
        if (complement) {
            complement(response.data, error);
        }
    };
    [[BXRequestClient shareClient] sendRequest:requset];
}

+ (void)bx_doFastRegister:(NSString *)password complement:(BXEventComplement)complement {
    if ([BXConfig config].configState != BXConfigStateSUC) {
        if (complement) {
            NSError *error = [NSError errorWithDomain:@"" code:-1 userInfo:@{NSLocalizedDescriptionKey:@"初始化未完成，请稍后操作"}];
            complement(nil, error);
        }
        return;
    }
    NSDictionary *params = [BXPackage pacForOneStepRegister:password];
    BXRequest *requset = [BXRequest postRequestWithHost:[BXMobileManager basePlatformURL] endpoint:@"Api/FastRegister.do" params:params];
    requset.enabelLoadingIndicator = YES;
    requset.complement = ^(BXResponse *response, NSError *error) {
        if (!error) {
            BXUser *user = [[BXUser alloc] initWithUserID:[response.data objectForKey:@"userId"]];
            [user decodeFromDictionary:response.data];
            
            if (complement) {
                complement(user, error);
            }
        }else{
            if (complement) {
                complement(nil, error);
            }
        }
    };
    [[BXRequestClient shareClient] sendRequest:requset];
}

+ (void)bx_doLogin:(NSString *)account password:(NSString *)password complement:(BXEventComplement)complement {
    if ([BXConfig config].isSeries) {
        @weakify(self)
        [self bx_doSeriesLogin:account password:password complement:^(id obj, NSError *error) {
            @strongify(self)
            if (error) {
                if (complement) {
                    complement(nil, error);
                }
                return;
            }
            [self bx_doInitlized:^(id obj, NSError *error) {
                @strongify(self)
                if (error) {
                    if (complement) {
                        complement(nil, error);
                    }
                    return;
                }
                [self bx_doNormalLogin:account password:password complement:complement];
            }];
        }];
    }else{
        [self bx_doNormalLogin:account password:password complement:complement];
    }
}

+ (void)bx_doNormalLogin:(NSString *)account password:(NSString *)password complement:(BXEventComplement)complement {
    if ([BXConfig config].configState != BXConfigStateSUC) {
        if (complement) {
            NSError *error = [NSError errorWithDomain:@"" code:-1 userInfo:@{NSLocalizedDescriptionKey:@"初始化未完成，请稍后操作"}];
            complement(nil, error);
        }
        return;
    }
    
    NSDictionary *params = [BXPackage pacForLogin:account password:password isSeries:NO];
    BXRequest *requset = requset = [BXRequest postRequestWithHost:[BXMobileManager basePlatformURL] endpoint:@"Api/SDKLogin.do" params:params];
    
    requset.enabelLoadingIndicator = NO;
    requset.complement = ^(BXResponse *response, NSError *error) {
        if (!error) {
            NSString *userID = response.data[@"userId"];
            BXUser *user = [BXUser loadUserFromArchiveWithUserID:userID];
            if (nil == user) {
                user = [[BXUser alloc] initWithUserID:userID];
            }
            [user decodeFromDictionary:response.data];
            user.userName = account;
            user.localLoginTime = [NSDate date];
    
            [BXMobileManager shareManager].currentUser = user;
            [user save];
            [user recordAccount:account password:password];
            
            BXConfig *config = [BXConfig config];
            [config decodeFromSeriesGameDictionary:response.data[@"seriesGame"]];
    
            if (complement) {
                complement(user, error);
            }
        }else{
            if (complement) {
                complement(nil, error);
            }
        }
    };
    [[BXRequestClient shareClient] sendRequest:requset];
}

+ (void)bx_doSeriesLogin:(NSString *)account password:(NSString *)password complement:(BXEventComplement)complement  {
    if ([BXConfig config].configState != BXConfigStateSUC) {
        if (complement) {
            NSError *error = [NSError errorWithDomain:@"" code:-1 userInfo:@{NSLocalizedDescriptionKey:@"初始化未完成，请稍后操作"}];
            complement(nil, error);
        }
        return;
    }
    
    NSDictionary *params = [BXPackage pacForLogin:account password:password isSeries:[BXConfig config].isSeries];
    BXRequest *requset = [BXRequest postRequestWithHost:[BXMobileManager basePlatformURL] endpoint:@"Api/SDKSeriesLogin.do" params:params];
    requset.enabelLoadingIndicator = NO;
    requset.complement = ^(BXResponse *response, NSError *error) {
        if (!error) {
            BXConfig *config = [BXConfig config];
            [config decodeFromSeriesGameDictionary:response.data[@"seriesGame"]];
        }
        if (complement) {
            complement(response, error);
        }
    };
    [[BXRequestClient shareClient] sendRequest:requset];
}

+ (void)bx_doRealnameAuth:(NSString *)idCard realName:(NSString *)realName phone:(NSString *)phone complement:(BXEventComplement)complement {
    NSDictionary *params = [BXPackage pacForRealnameAuth:idCard realname:realName phone:phone userId:[BXMobileManager shareManager].currentUser.userId];
    BXRequest *requset = [BXRequest postRequestWithHost:[BXMobileManager basePlatformURL] endpoint:@"Api/RealNameAuth.do" params:params];
    requset.complement = ^(BXResponse *response, NSError *error) {
        if (complement) {
            complement(response.data, error);
        }
    };
    [[BXRequestClient shareClient] sendRequest:requset];
}

+ (void)bx_doUserInfoComplement:(BXEventComplement)complement {
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    [dic addEntriesFromDictionary:@{@"nickName":@"nickName",@"idCard":@"idCard", @"realName":@"realName",@"platVipTime":@"platVipTime"}];
    [dic addEntriesFromDictionary:[BXPackage pacTokenAuth]];
    BXRequest *requset = [BXRequest postRequestWithHost:[BXMobileManager basePlatformURL] endpoint:@"Api/GetUserInfo.do" params:dic];
    requset.enabelLoadingIndicator = NO;
    requset.complement = ^(BXResponse *response, NSError *error) {
        if (!error) {
            BXUser *user = [BXMobileManager shareManager].currentUser;
            [user decodeInfo:response.data];
            
            if (complement) {
                complement(user, error);
            }
        }else{
            if (complement) {
                complement(nil, error);
            }
        }
    };
    [[BXRequestClient shareClient] sendRequest:requset];
}

+ (void)bx_doUpdateNotice:(BXEventComplement)complement {
    NSDictionary *params = [BXPackage pacForNofice];
    BXRequest *requset = [BXRequest postRequestWithHost:[BXMobileManager basePlatformURL] endpoint:@"Api/SDKNotice.do" params:params];
    requset.enabelLoadingIndicator = NO;
    requset.complement = ^(BXResponse *response, NSError *error) {
        if (!error) {
            NSArray *notifies = [response.data objectForKey:@"NoticeList"];
            if (complement) {
                complement(notifies, error);
            }
        }
        else {
            if (complement) {
                complement(nil, error);
            }
        }
    };
    [[BXRequestClient shareClient] sendRequest:requset];
}

+ (void)bx_doSyncData:(NSInteger)actionType gameCoin:(NSNumber *)gameCoin roleId:(NSString *)roleId roleLevel:(NSString *)roleLevel roleName:(NSString *)roleName zoneId:(NSString *)zoneId zoneName:(NSString *)zoneName complement:(BXEventComplement)complement {
    if ([BXConfig config].configState != BXConfigStateSUC) {
        if (complement) {
            NSError *error = [NSError errorWithDomain:@"" code:-1 userInfo:@{NSLocalizedDescriptionKey:@"初始化未完成，请稍后操作"}];
            complement(nil, error);
        }
        return;
    }
    
    BXUser *currentUser = [BXMobileManager shareManager].currentUser;
    NSAssert(currentUser != nil, @"更新失败，您必须先登录哦！");

    NSDictionary *params = [BXPackage pacForSyncData:actionType gameCoin:gameCoin roleId:roleId roleLevel:roleLevel roleName:roleName userId:currentUser.userId zoneId:zoneId zoneName:zoneName];
    BXRequest *requset = [BXRequest postRequestWithHost:[BXMobileManager basePlatformURL] endpoint:@"Api/SyncData.do" params:params];
    requset.complement = ^(BXResponse *response, NSError *error) {
        if (!error) {
            if (complement) {
                complement(response.data, error);
            }
        }
    };
    [[BXRequestClient shareClient] sendRequest:requset];
}

+ (void)bx_doGetPaymentType:(BXEventComplement)complement{
    NSDictionary *params = [BXPackage pacForPaymentType];
    BXRequest *requset = [BXRequest postRequestWithHost:[BXMobileManager basePlatformURL] endpoint:@"Api/Ch.do" params:params];
    requset.complement = ^(BXResponse *response, NSError *error) {
        if (complement) {
            complement(response.data, error);
        }
    };
    [[BXRequestClient shareClient] sendRequest:requset];
}
+ (void)bx_doPaymentType:(NSInteger)rechargeAmount complement:(BXEventComplement)complement{
    NSDictionary *params = [BXPackage pacPaymentType:[BXMobileManager shareManager].currentUser.userId rechargeAmount:rechargeAmount];
    BXRequest *requset = [BXRequest postRequestWithHost:[BXMobileManager basePlatformURL] endpoint:@"Api/ApplePayBeforeVerify.do" params:params];
    requset.complement = ^(BXResponse *response, NSError *error) {
        if (complement) {
            complement(response.data, error);
        }
    };
    [[BXRequestClient shareClient] sendRequest:requset];
}

+ (void)bx_doCreateOrder:(NSInteger)PC PL:(NSInteger)PL abbey:(NSString *)abbey appName:(NSString *)appName appPackage:(NSString *)appPackage extension:(NSString *)extension iosIdCode:(NSString *)iosIdCode notifyUrl:(NSString *)notifyUrl productDesc:(NSString *)productDesc productId:(NSString *)productId productName:(NSString *)productName roleId:(NSString *)roleId roleName:(NSString *)roleName talks:(NSInteger)talks userId:(NSString *)userId userName:(NSString *)userName zoneId:(NSString *)zoneId zoneName:(NSString *)zoneName complement:(BXEventComplement)complement{
    NSDictionary *params = [BXPackage pacForAPOrder:PC PL:PL abbey:abbey appName:appName appPackage:appPackage extension:extension iosIdCode:iosIdCode notifyUrl:notifyUrl productDesc:productDesc productId:productId productName:productName roleId:roleId roleName:roleName talks:talks userId:userId userName:userName zoneId:zoneId zoneName:zoneName];
    BXRequest *requset = [BXRequest postRequestWithHost:[BXMobileManager basePlatformURL] endpoint:@"Api/PO.do" params:params];
    requset.complement = ^(BXResponse *response, NSError *error) {
        if (complement) {
            complement(response.data, error);
        }
    };
    [[BXRequestClient shareClient] sendRequest:requset];
}

+ (void)bx_doLogout:(BXEventComplement)complement {
    NSDictionary *params = [BXPackage pacForLogout:[BXMobileManager shareManager].currentUser.userId];
    BXRequest *requset = [BXRequest postRequestWithHost:[BXMobileManager basePlatformURL] endpoint:@"Api/SDKLogout.do" params:params];
    requset.complement = ^(BXResponse *response, NSError *error) {
        if (complement) {
            complement(response.data, error);
        }
    };
    [[BXRequestClient shareClient] sendRequest:requset];
}

+ (void)doUpdateUserPassword:(NSString *)phoneNumber password:(NSString *)password msgCode:(NSString *)msgCode complement:(BXEventComplement)complement {
    NSDictionary *params = [BXPackage pacForForgotPassword:phoneNumber newPassword:password msgCode:msgCode];
    BXRequest *requset = [BXRequest postRequestWithHost:[BXMobileManager basePlatformURL] endpoint:@"Api/UpdatePwd.do" params:params];
    requset.complement = ^(BXResponse *response, NSError *error) {
        if (complement) {
            complement(response.data, error);
        }
    };
    [[BXRequestClient shareClient] sendRequest:requset];
}

+ (void)doUpdateUserOldPassword:(NSString *)password newPassword:(NSString *)newPassword complement:(BXEventComplement)complement {
    NSDictionary *params = [BXPackage pacForOldPassword:password newPassword:newPassword userId:[BXMobileManager shareManager].currentUser.userId];
    BXRequest *requset = [BXRequest postRequestWithHost:[BXMobileManager basePlatformURL] endpoint:@"Api/UpdatePwd.do" params:params];
    requset.complement = ^(BXResponse *response, NSError *error) {
        if (complement) {
            complement(response.data, error);
        }
    };
    [[BXRequestClient shareClient] sendRequest:requset];
}

+ (void)doBindMobile:(NSString *)phoneNumber msgCode:(NSString *)msgCode complement:(BXEventComplement)complement {
    NSDictionary *params = [BXPackage pacForBindMobile:phoneNumber msgCode:msgCode userId:[BXMobileManager shareManager].currentUser.userId];
    BXRequest *requset = [BXRequest postRequestWithHost:[BXMobileManager basePlatformURL] endpoint:@"Api/BindMobile.do" params:params];
    requset.complement = ^(BXResponse *response, NSError *error) {
        if (complement) {
            complement(response.data, error);
        }
    };
    [[BXRequestClient shareClient] sendRequest:requset];
}

+ (void)doUnBindPhoneMobile:(NSString *)phoneNumber msgCode:(NSString *)msgCode complement:(BXEventComplement)complement {
    NSDictionary *params = [BXPackage pacForBindMobile:phoneNumber msgCode:msgCode userId:[BXMobileManager shareManager].currentUser.userId];
    BXRequest *requset = [BXRequest postRequestWithHost:[BXMobileManager basePlatformURL] endpoint:@"Api/UntieThePhone.do" params:params];
    requset.complement = ^(BXResponse *response, NSError *error) {
        if (complement) {
            complement(response.data, error);
        }
    };
    [[BXRequestClient shareClient] sendRequest:requset];
}

+ (void)doVerifyIapResult:(NSString *)orderId receipt:(NSString *)receipt complement:(BXEventComplement)complement {
    NSDictionary *params = [BXPackage pacForVerifyIapResult:orderId receipt:receipt];
    BXRequest *requset = [BXRequest postRequestWithHost:[BXMobileManager basePlatformURL] endpoint:@"Api/appleVerifyReceipt.do" params:params];
    requset.complement = ^(BXResponse *response, NSError *error) {
        if (complement) {
            complement(response.data, error);
        }
    };
    [[BXRequestClient shareClient] sendRequest:requset];
}

+ (void)doHeartBeatResultComplement:(BXEventComplement)complement {
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params addEntriesFromDictionary:[BXPackage pacTokenAuth]];
    
    BXRequest *requset = [BXRequest postRequestWithHost:[BXMobileManager basePlatformURL] endpoint:@"Api/HeartBeat.do" params:params];
    requset.complement = ^(BXResponse *response, NSError *error) {
        if (complement) {
            complement(response.data, error);
        }
    };
    [[BXRequestClient shareClient] sendRequest:requset];
}

+ (void)bx_proxyCustomerSupportUrl:(BXEventComplement)complement {
    if ([BXConfig config].configState != BXConfigStateSUC) {
        if (complement) {
            NSError *error = [NSError errorWithDomain:@"" code:-1 userInfo:@{NSLocalizedDescriptionKey:@"初始化未完成，请稍后操作"}];
            complement(nil, error);
        }
        return;
    }
    
    NSDictionary *params = [BXPackage pacForServiceSupportWithZoneId:nil zoneName:nil roleId:nil roleName:nil roleLevel:nil gameCoin:nil];
    BXUser *currentUser = [BXMobileManager shareManager].currentUser;
    if (currentUser) {
        params = [BXPackage pacForServiceSupportWithZoneId:currentUser.zoneId
                                                  zoneName:currentUser.zoneName
                                                    roleId:currentUser.roleId
                                                  roleName:currentUser.roleName
                                                 roleLevel:currentUser.roleLevel
                                                  gameCoin:@(currentUser.gameCoin)];
    }

    BXRequest *req = [BXRequest getRequestWithHost:[BXConfig config].h5SdkUrl endpoint:@"service" params:params];
    if (complement) {
        complement(req.URL.absoluteString, nil);
    }
}

+ (void)bx_proxyPrivacyPolicyAddress:(BXEventComplement)complement {
    if ([BXConfig config].configState != BXConfigStateSUC) {
        if (complement) {
            NSError *error = [NSError errorWithDomain:@"" code:-1 userInfo:@{NSLocalizedDescriptionKey:@"初始化未完成，请稍后操作"}];
            complement(nil, error);
        }
        return;
    }
    BXRequest *req = [BXRequest getRequestWithHost:[BXConfig config].cdnImgServer endpoint:[NSString stringWithFormat:@"agree/%@_appstore/privacy_policy_transparent_black_text.html", [BXConfig config].platformId] params:nil];
    if (complement) {
        complement(req.URL.absoluteString, nil);
    }
}

+ (void)bx_proxyServiceAgreementAddress:(BXEventComplement)complement {
    if ([BXConfig config].configState != BXConfigStateSUC) {
        if (complement) {
            NSError *error = [NSError errorWithDomain:@"" code:-1 userInfo:@{NSLocalizedDescriptionKey:@"初始化未完成，请稍后操作"}];
            complement(nil, error);
        }
        return;
    }
    
    BXRequest *req = [BXRequest getRequestWithHost:[BXConfig config].cdnImgServer endpoint:[NSString stringWithFormat:@"agree/%@_appstore/user_protocol.html", [BXConfig config].platformId] params:nil];
    if (complement) {
        complement(req.URL.absoluteString, nil);
    }
}

+ (void)bx_proxyStroreAddress:(NSDictionary *)info complement:(BXEventComplement)complement {
    if ([BXConfig config].configState != BXConfigStateSUC) {
        if (complement) {
            NSError *error = [NSError errorWithDomain:@"" code:-1 userInfo:@{NSLocalizedDescriptionKey:@"初始化未完成，请稍后操作"}];
            complement(nil, error);
        }
        return;
    }

    NSString *abbey = info[BXOrderInfoOrderIDKey];
    NSString *extension = info[BXOrderInfoExternKey];
    NSString *notifyUrl = info[BXOrderInfoNotifyUrlKey];
    NSString *productDesc = info[BXOrderInfoProductDescriptionKey];
    NSString *productId = info[BXOrderInfoProductIdKey];
    NSString *productName = info[BXOrderInfoProductNameKey];
    NSInteger talks = [info[BXOrderInfoProductPriceKey] integerValue];
    
    NSString *eProductId = info[BXOrderInfoExternProductIdKey];
    if (eProductId) {
        productId = eProductId;
    }
    
    NSNumber *eTalks = info[BXOrderInfoExternProductPriceKey];
    if (eTalks) {
        talks = eTalks.integerValue;
    }
    
    BXUser *currentUser = [BXMobileManager shareManager].currentUser;

    NSDictionary *params = [BXPackage pacForOrder:4
                                               PL:0
                                            abbey:abbey
                                          appName:BX_BUNDLE_NAME
                                       appPackage:BX_BUNDLE_ID
                                        extension:extension
                                        iosIdCode:[BXConfig config].iosIdCode
                                        notifyUrl:notifyUrl
                                      productDesc:productDesc
                                        productId:productId
                                      productName:productName
                                           roleId:currentUser.roleId
                                         roleName:currentUser.roleName
                                            talks:talks
                                           userId:currentUser.userId
                                         userName:currentUser.userName
                                           zoneId:currentUser.zoneId
                                         zoneName:currentUser.zoneName];
             
    BXRequest *req = [BXRequest getRequestWithHost:[BXConfig config].h5SdkUrl endpoint:@"megane" params:params];
    if (complement) {
        complement(req.URL, nil);
    }
}

@end
