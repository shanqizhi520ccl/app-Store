//
//  BXPackage.m
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/13.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXPackage.h"
#import "BXMobileManager.h"
#import "BXDevice.h"
#import "BXDefine.h"
#import "BXHelper.h"
#import "NSString+BXExtern.h"
#import "BXConfig.h"
#import "BXPrivacyUtil.h"
#import "BXMobileManager+Private.h"
#import "BXRSAEncryptor.h"

@implementation BXPackage

+ (NSDictionary *)pacForConfig:(BOOL)isSeries {
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    //初始化apiVersion单独设置
    [params setValue:BX_API_VERSION_FOR_INIT forKey:@"apiVersion"];
    NSString *gameVersion = [NSString stringWithFormat:@"%@.%@", [BXHelper getBundleShortVersionString],[BXHelper getBundleVersion]];
    [params setValue:gameVersion forKey:@"gameVersion"];

//    NSNumber *isChannelChangeNumber = [[NSUserDefaults standardUserDefaults] objectForKey:@"isChannelChange"];
//    if (!isChannelChangeNumber) {
//        isChannelChangeNumber = @0;
//        NSString *base64String = [[UIPasteboard generalPasteboard] string];
//
//        if (base64String && ![base64String isEqualToString:@""]) {
//            NSData *data = [[NSData alloc] initWithBase64EncodedString:base64String options:NSDataBase64DecodingIgnoreUnknownCharacters];
//            NSDictionary *jsonDict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
//            if (jsonDict && [jsonDict objectForKey:@"gameId"]) {
//                if (![[BXMobileManager shareManager].appID isEqualToString:[jsonDict objectForKey:@"gameId"]]) {
//                    isChannelChangeNumber = @1;
//                }
//            }
//        }
//        [[NSUserDefaults standardUserDefaults] setObject:isChannelChangeNumber forKey:@"isChannelChange"];
//        [[NSUserDefaults standardUserDefaults] synchronize];
//    }
//    [params setValue:isChannelChangeNumber forKey:@"isChannelChange"];
    [params setValue:@0 forKey:@"isChannelChange"];
    
    if (isSeries) {
       [params setValue:[BXMobileManager shareManager].seriesAppId forKey:@"seriesId"];
    }
    
    return params;
}

+ (NSDictionary *)pacForLogin:(NSString *)phoneNumber password:(NSString *)password isSeries:(BOOL)isSeries {
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setValue:[BXRSAEncryptor BX_DesEncryptString:phoneNumber keyString:[BXConfig config].desSecretKey iv:nil] forKey:@"phoneNumber"];
    [params setValue:[[password bx_md5] uppercaseString] forKey:@"password"];
    [params setValue:BX_USER_FROM forKey:@"user_from"];
    [params setValue:BX_BRAND forKey:@"brand"];
    [params setValue:BX_PRODUCER forKey:@"producer"];
    
    NSString * carrierName = [BXDevice telephonyCarrierName];
    if (carrierName) {
        [params setValue:[BXDevice telephonyCarrierName] forKey:@"operator"];
    }
    
    if (isSeries) {
        [params setValue:[BXMobileManager shareManager].seriesAppId forKey:@"seriesId"];
        [params setValue:[BXConfig config].userId forKey:@"userId"];
    }
    
    return params;
}

+ (NSDictionary *)pacForRegisterByMobile:(NSString *)phoneNumber msgCode:(NSString *)msgCode password:(NSString *)password {
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setValue:[BXRSAEncryptor BX_DesEncryptString:phoneNumber keyString:[BXConfig config].desSecretKey iv:nil] forKey:@"phoneNumber"];
    [params setValue:msgCode forKey:@"msgCode"];
    [params setValue:password forKey:@"password"];
    [params setValue:BX_USER_FROM forKey:@"user_from"];
    [params setValue:BX_BRAND forKey:@"brand"];
    [params setValue:BX_PRODUCER forKey:@"producer"];
    NSString * carrierName = [BXDevice telephonyCarrierName];
    if (carrierName) {
        [params setValue:carrierName forKey:@"operator"];
    }
    return params;
}

+ (NSDictionary *)pacForOneStepRegister:(NSString *)password {
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setValue:password forKey:@"password"];
    [params setValue:BX_BRAND forKey:@"brand"];
    [params setValue:BX_PRODUCER forKey:@"producer"];
    NSString * carrierName = [BXDevice telephonyCarrierName];
    if (carrierName) {
        [params setValue:carrierName forKey:@"operator"];
    }
    return params;
}

+ (NSDictionary *)pacForSmsCode:(NSString *)phoneNumber smsType:(NSInteger)smsType {
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setValue:[BXRSAEncryptor BX_DesEncryptString:phoneNumber keyString:[BXConfig config].desSecretKey iv:nil] forKey:@"phoneNumber"];
    [params setValue:@(smsType) forKey:@"smsType"];
    return params;
}

+ (NSDictionary *)pacForRealnameAuth:(NSString *)idCard realname:(NSString *)realname phone:(NSString *)phone userId:(NSString *)userId {
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setValue:[BXRSAEncryptor BX_DesEncryptString:idCard keyString:[BXConfig config].desSecretKey iv:nil] forKey:@"idCard"];
    [params setValue:[BXRSAEncryptor BX_DesEncryptString:realname keyString:[BXConfig config].desSecretKey iv:nil] forKey:@"realName"];
    [params setValue:userId forKey:@"userId"];
    [params setValue:[BXRSAEncryptor BX_DesEncryptString:phone keyString:[BXConfig config].desSecretKey iv:nil] forKey:@"phoneNumber"];
    return params;
}

+ (NSDictionary *)pacTokenAuth {
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params addEntriesFromDictionary:[self publicParameters]];
    [params addEntriesFromDictionary:[self proxyInfoDictionary]];
    return params;
}

+ (NSDictionary *)pacForNofice {
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    return params;
}

+ (NSDictionary *)pacForSyncData:(NSInteger)actionType gameCoin:(NSNumber *)gameCoin roleId:(NSString *)roleId roleLevel:(NSString *)roleLevel roleName:(NSString *)roleName userId:(NSString *)userId zoneId:(NSString *)zoneId zoneName:(NSString *)zoneName {
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setValue:@(actionType) forKey:@"actionType"];
    [params setValue:roleId forKey:@"roleId"];
    [params setValue:roleLevel forKey:@"roleLevel"];
    [params setValue:roleName forKey:@"roleName"];
    [params setValue:userId forKey:@"userId"];
    [params setValue:zoneId forKey:@"zoneId"];
    [params setValue:zoneName forKey:@"zoneName"];
    if (gameCoin) {
        [params setValue:gameCoin forKey:@"gameCoin"];
    }
    return params;
}

+ (NSDictionary *)pacForPaymentType {
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    return params;
}
+ (NSDictionary *)pacPaymentType:(NSString *)userId rechargeAmount:(double )rechargeAmount {
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setValue:[BXConfig config].platformId forKey:@"platformId"];
    [params setValue:userId forKey:@"userId"];
    [params setValue:[NSString stringWithFormat:@"%.0f",rechargeAmount] forKey:@"rechargeAmount"];
    [params setValue:[BXMobileManager shareManager].appID forKey:@"gameId"];
    return params;
}

+ (NSDictionary *)pacForLogout:(NSString *)userId {
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setValue:userId forKey:@"userId"];
    return params;
}

+ (NSDictionary *)pacForForgotPassword:(NSString *)phoneNumber newPassword:(NSString *)newPassword msgCode:(NSString *)msgCode {
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setValue:[BXRSAEncryptor BX_DesEncryptString:phoneNumber keyString:[BXConfig config].desSecretKey iv:nil] forKey:@"phoneNumber"];
    [params setValue:[newPassword bx_md5].uppercaseString forKey:@"password"];
    [params setValue:msgCode forKey:@"msgCode"];
    return params;
}

+ (NSDictionary *)pacForOldPassword:(NSString *)oldPassword newPassword:(NSString *)newPassword userId:(NSString *)userId {
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setValue:[oldPassword bx_md5].uppercaseString forKey:@"oldPwd"];
    [params setValue:[newPassword bx_md5].uppercaseString forKey:@"password"];
    [params setValue:userId forKey:@"userId"];
    return params;
}

+ (NSDictionary *)pacForBindMobile:(NSString *)phoneNumber msgCode:(NSString *)msgCode userId:(NSString *)userId {
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setValue:[BXRSAEncryptor BX_DesEncryptString:phoneNumber keyString:[BXConfig config].desSecretKey iv:nil] forKey:@"phoneNumber"];
    [params setValue:msgCode forKey:@"msgCode"];
    [params setValue:userId forKey:@"userId"];
    return params;
}

+ (NSDictionary *)pacForVerifyIapResult:(NSString *)orderId receipt:(NSString *)receipt {
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setValue:orderId forKey:@"orderId"];
    [params setValue:receipt forKey:@"receipt"];
    return params;
}

+ (NSDictionary *)pacForServiceSupportWithZoneId:(NSString *)zoneId zoneName:(NSString *)zoneName roleId:(NSString *)roleId roleName:(NSString *)roleName roleLevel:(NSString *)roleLevel gameCoin:(NSNumber *)gameCoin {
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setValue:[BXConfig config].platformId forKey:@"platformId"];
    [params setValue:[BXMobileManager shareManager].appID forKey:@"gameId"];
    [params setValue:@(BX_DEVICE_TYPE) forKey:@"deviceType"];
    
    NSString *gameVersion = [NSString stringWithFormat:@"%@.%@", [BXHelper getBundleShortVersionString],[BXHelper getBundleVersion]];
    [params setValue:gameVersion forKey:@"gameVersion"];
    
    //进入游戏后需要以下参数
    if (roleId) {
        [params setValue:roleId forKey:@"roleId"];
    }
    
    if (roleName) {
        [params setValue:roleName forKey:@"roleName"];
    }
    
    if (roleLevel) {
        [params setValue:roleLevel forKey:@"roleLevel"];
    }
    
    if (gameCoin) {
        [params setValue:gameCoin forKey:@"gameCoin"];
    }
    
    if (zoneId) {
        [params setValue:zoneId forKey:@"zoneId"];
    }
    
    if (zoneName) {
        [params setValue:zoneName forKey:@"zoneName"];
    }
    return params;
}

+ (NSDictionary *)pacForOrder:(NSInteger)PC PL:(NSInteger)PL abbey:(NSString *)abbey appName:(NSString *)appName appPackage:(NSString *)appPackage extension:(NSString *)extension iosIdCode:(NSString *)iosIdCode notifyUrl:(NSString *)notifyUrl productDesc:(NSString *)productDesc productId:(NSString *)productId productName:(NSString *)productName roleId:(NSString *)roleId roleName:(NSString *)roleName talks:(NSInteger)talks userId:(NSString *)userId userName:(NSString *)userName zoneId:(NSString *)zoneId zoneName:(NSString *)zoneName {
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    //[params setValue:@(PC) forKey:@"PC"];
    [params setValue:@(PL) forKey:@"PL"];
    [params setValue:abbey forKey:@"abbey"];
    [params setValue:appName forKey:@"appName"];
    [params setValue:appPackage forKey:@"appPackage"];
    [params setValue:extension forKey:@"extension"];
    [params setValue:iosIdCode forKey:@"iosIdCode"];
    [params setValue:notifyUrl forKey:@"notifyUrl"];
    [params setValue:productDesc forKey:@"productDesc"];
    [params setValue:productId forKey:@"productId"];
    [params setValue:productName forKey:@"productName"];
    [params setValue:roleId forKey:@"roleId"];
    [params setValue:roleName forKey:@"roleName"];
    [params setValue:@(talks) forKey:@"talks"];
    [params setValue:userId forKey:@"userId"];
    [params setValue:userName forKey:@"userName"];
    [params setValue:zoneId forKey:@"zoneId"];
    [params setValue:zoneName forKey:@"zoneName"];
    return params;
}

+ (NSDictionary *)pacForAPOrder:(NSInteger)PC PL:(NSInteger)PL abbey:(NSString *)abbey appName:(NSString *)appName appPackage:(NSString *)appPackage extension:(NSString *)extension iosIdCode:(NSString *)iosIdCode notifyUrl:(NSString *)notifyUrl productDesc:(NSString *)productDesc productId:(NSString *)productId productName:(NSString *)productName roleId:(NSString *)roleId roleName:(NSString *)roleName talks:(NSInteger)talks userId:(NSString *)userId userName:(NSString *)userName zoneId:(NSString *)zoneId zoneName:(NSString *)zoneName {
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setValue:@(PC) forKey:@"PC"];
    [params setValue:@(PL) forKey:@"PL"];
    [params setValue:abbey forKey:@"abbey"];
    [params setValue:appName forKey:@"appName"];
    [params setValue:appPackage forKey:@"appPackage"];
    [params setValue:extension forKey:@"extension"];
    [params setValue:iosIdCode forKey:@"iosIdCode"];
    [params setValue:notifyUrl forKey:@"notifyUrl"];
    [params setValue:productDesc forKey:@"productDesc"];
    [params setValue:productId forKey:@"productId"];
    [params setValue:productName forKey:@"productName"];
    [params setValue:roleId forKey:@"roleId"];
    [params setValue:roleName forKey:@"roleName"];
    [params setValue:@(talks) forKey:@"talks"];
    [params setValue:userId forKey:@"userId"];
    [params setValue:userName forKey:@"userName"];
    [params setValue:zoneId forKey:@"zoneId"];
    [params setValue:zoneName forKey:@"zoneName"];
    return params;
}

#pragma mark -info
+ (NSDictionary *)proxyInfoDictionary {
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    [dict setObject:[BXMobileManager shareManager].currentUser.token forKey:@"userToken"];
    [dict setObject:[BXMobileManager shareManager].currentUser.userId forKey:@"userId"];
    if ([BXConfig config].isSeries) {
        [dict setObject:[BXMobileManager shareManager].appID forKey:@"appId"];
        [dict setObject:[BXConfig config].platformId forKey:@"platformId"];
        [dict setObject:[BXConfig config].specialSign forKey:@"specialSign"];
    }
    return dict;
}

+ (NSDictionary *)publicParameters {
    static NSMutableDictionary *publicParams = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        publicParams = [NSMutableDictionary dictionary];
        [publicParams setValue:[BXMobileManager currentSDKVersion] forKey:@"SDKVersion"];
        [publicParams setValue:BX_API_VERSION forKey:@"apiVersion"];
        [publicParams setValue:([BXConfig config].isTestFlight ? @(2):@(BX_CEDAR)) forKey:@"cedar"];
        [publicParams setValue:[BXDevice deviceUniqueId] forKey:@"deviceId"];
        [publicParams setValue:@(BX_DEVICE_TYPE) forKey:@"deviceType"];
        [publicParams setValue:[BXDevice systemInfo] forKey:@"model"];
        [publicParams setValue:[BXDevice systemVerson] forKey:@"release"];
    });
    // 以下公共参数可能会被改变
    [publicParams setValue:[BXConfig config].platformId forKey:@"platformId"];
    [publicParams setValue:[BXMobileManager shareManager].appID forKey:@"appId"];
    [publicParams setValue:[BXMobileManager shareManager].appID forKey:@"gameId"];
    [publicParams setValue:[BXConfig config].mcId forKey:@"mcId"];
    [publicParams setValue:[BXConfig config].scId forKey:@"scId"];
    return publicParams;
}

@end
