//
//  BXTaskConfigBeats.h
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/10.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BXRequest.h"

//NS_ASSUME_NONNULL_BEGIN

@class BXTaskConfigBeats;

//配置项 Task
typedef void(^BXTaskConfigBeatBlock)(BXTaskConfigBeats *taskBeats);
typedef BXRequest*(^BXTaskConfigBeat)(void);

@interface BXTaskConfigBeats : NSObject

@property (nonatomic, copy) BXTaskConfigBeatBlock configBlock;

@property (nonatomic, copy) BXTaskConfigBeat taskConfigBlock;

/* 配置项是否获取 */
@property (nonatomic, assign) BOOL isConfigOver;

/* 任务计时器间隔 默认为5秒 */
@property (nonatomic, assign) double interval;

/* 计时器最大计数次数 默认10000次 */
@property (nonatomic, assign) NSInteger maxRepeatCount;

- (void)start;

- (void)stop;

@end

//NS_ASSUME_NONNULL_END
