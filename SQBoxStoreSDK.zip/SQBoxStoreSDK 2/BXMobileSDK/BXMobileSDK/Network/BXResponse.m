//
//  BXResponse.m
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/10.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXResponse.h"

@interface BXResponse ()

/**
* HTTP response.
*/
@property (nonatomic, strong, readwrite) NSURLResponse *urlResponse;

/**
 * HTTP error code.
 * state 1: success, other: faied
 */
@property (nonatomic, readwrite) NSInteger state;

/**
 * HTTP result message.
 */
@property (nonatomic, strong, readwrite) NSString *desc;

/**
 *  A dictionary with the contents of the response.
 */
@property (nonatomic, strong, readwrite) NSDictionary *data;

@end

@implementation BXResponse

- (id)initWithResponse:(NSURLResponse *)response data:(NSDictionary *)data state:(NSInteger)state desc:(NSString *)desc {
    self = [super init];
    if (self) {
        self.urlResponse = response;
        self.data = data;
        self.state = state;
        self.desc = desc;
    }
    return self;
}

@end
