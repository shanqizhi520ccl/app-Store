//
//  BXRSAEncryptor.h
//  VVSDK
//
//  Created by shanqizhi on 2021/10/19.
//  Copyright © 2020 Weep Yan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonCrypto.h>
NS_ASSUME_NONNULL_BEGIN

@interface BXRSAEncryptor : NSObject
/**
 *  DES加密
 *
 *  @param string    要加密的字符串
 *  @param keyString 加密密钥
 *  @param iv        初始化向量(8个字节)
 *
 *  @return 返回加密后的base64编码字符串
 */
+ (NSString *)BX_DesEncryptString:(NSString *)string keyString:(NSString *)keyString iv:(NSData * _Nullable)iv;

/**
 *  DES解密
 *
 *  @param string    加密并base64编码后的字符串
 *  @param keyString 解密密钥
 *  @param iv        初始化向量(8个字节)
 *
 *  @return 返回解密后的字符串
 */
+ (NSString *)BX_DesDecryptString:(NSString *)string keyString:(NSString *)keyString iv:(NSData * _Nullable)iv;

@end

NS_ASSUME_NONNULL_END
