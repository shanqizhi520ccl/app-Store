//
//  BXUser.h
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/18.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import <Foundation/Foundation.h>

//NS_ASSUME_NONNULL_BEGIN

@interface BXUser : NSObject

@property (nonatomic, assign) NSInteger adultState; //实名认证状态 1:未实名认证 0:已实名并且是成年人(默认) 2:已实名是未成年人
@property (nonatomic, copy) NSString *cuteNumber;  //靓号 不需要
@property (nonatomic, copy) NSString *cuteNumberIcon; //靓号图标 不需要
@property (nonatomic, copy) NSString *cuteNumberType; //靓号类型 不需要
@property (nonatomic, assign) NSInteger loginLimit; //登录限制
@property (nonatomic, copy) NSString *password;
@property (nonatomic, copy) NSString *phoneNumber;
@property (nonatomic, copy) NSString *platVipTime; //VIP过期时间 时间截 不需要
@property (nonatomic, copy) NSString *platformId; //平台编号 回调给CP"登录成功"事件时传递给CP,CP用该platformId+初始化结果appId动态加载专服
@property (nonatomic, copy) NSString *token; //校验token
@property (nonatomic, copy) NSString *userId; //用户ID
@property (nonatomic, copy) NSString *userLogoUrl; //用户头像地址
@property (nonatomic, assign) NSInteger userProtocolUpdate;  //用户协议更新提示 0为无更新，1为有更新
@property (nonatomic, strong) NSArray *zoneData; //分区信息 "zoneData":[{"appId":"","zoneName":"","roleName":"","level":0},{}...]

@property (nonatomic, copy) NSString *userName; 

// 角色信息
@property(nonatomic, copy) NSString *zoneId;
@property(nonatomic, copy) NSString *zoneName;
@property(nonatomic, copy) NSString *roleId;
@property(nonatomic, copy) NSString *roleName;
@property(nonatomic, copy) NSString *roleLevel;
@property(nonatomic, assign) NSInteger gameCoin;

@property(strong, nonatomic) NSString *realName;    //真实姓名
@property(strong, nonatomic) NSString *idcard;    //身份证

/// 绑定手机弹框提示时间
@property (nonatomic, strong) NSDate *bindMobileReminderTime;

/// 绑定手机弹框提示时间
@property (nonatomic, strong) NSDate *realnameReminderTime;

/// 最后的登录时间
@property (nonatomic, strong) NSDate *localLoginTime;

- (instancetype)initWithUserID:(NSString *)userID;

- (void)decodeFromDictionary:(NSDictionary *)dictionary;
- (void)decodeInfo:(NSDictionary *)dictionary;
- (NSDictionary *)proxyLoginResultDictionary;
@end

/// 数据归档相关
@interface BXUser (Archaive)

+ (instancetype)loadUserFromArchiveWithUserID:(NSString *)userID;
+ (NSArray<BXUser *> *)allUsers;
- (void)save;
- (void)remove;

/// 缓存账号和密码
/// @param account 账号/手机号
/// @param password 密码
- (void)recordAccount:(NSString *)account password:(NSString *)password;
/// 缓存账号
/// @param account 账号/手机号
- (void)recordAccount:(NSString *)account;
/// 缓存对应账号的密码
/// @param password 密码
/// @param account 账号/手机号
- (void)recordPassword:(NSString *)password forAccount:(NSString *)account;

/// 清除缓存的账号和密码
/// @param account 账号/手机号
+ (void)removeRecordedAccountAndPassword:(NSString *)account;
/// 清除缓存的密码
/// @param account 账号/手机号
+ (void)removeRecordedPasswordForAccount:(NSString *)account;
/// 清除缓存的账号
/// @param account 账号/手机号
+ (void)removeRecordedAccount:(NSString *)account;

/// 获取缓存的所有
+ (NSArray<NSString *> *)recordedAccounts;
/// 获取缓存的密码
/// @param account 账号/手机号
+ (NSString *)recordedPassword:(NSString *)account;

+ (BOOL)getAutoLogin;

+(void)setAutoLogin:(BOOL)isAutoLogin;

@end

//NS_ASSUME_NONNULL_END
