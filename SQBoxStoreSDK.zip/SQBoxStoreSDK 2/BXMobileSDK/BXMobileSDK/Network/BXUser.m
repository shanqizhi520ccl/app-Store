//
//  BXUser.m
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/18.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXUser.h"
#import "NSDictionary+BXMobileSDK.h"
#import "BXKeychain.h"
#import "BXConfig.h"
#import "BXMobileSDK.h"
#import "BXRSAEncryptor.h"

@implementation BXUser

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.userId = nil;
        self.adultState = 0;
        self.cuteNumber = nil;
        self.cuteNumberIcon = nil;
        self.cuteNumberType = nil;
        self.loginLimit = 0;
        self.password = nil;
        self.phoneNumber = nil;
        self.platVipTime = nil;
        self.platformId = nil;
        self.token = nil;
        self.userId = nil;
        self.userLogoUrl = nil;
        self.userProtocolUpdate = 0;
        self.zoneData = nil;
        self.bindMobileReminderTime = [NSDate distantPast];
        self.realnameReminderTime = [NSDate distantPast];
        
        self.realName = nil;
        self.idcard = nil;
    }
    return self;
}

- (instancetype)initWithUserID:(NSString *)userID {
    if (userID == nil ||
        [userID isEqualToString:@""] ||
        [userID isKindOfClass:[NSNull class]]) {
        return nil;
    }
    
    self = [super init];
    if (self) {
        self.userId = userID;
        self.adultState = 0;
        self.cuteNumber = nil;
        self.cuteNumberIcon = nil;
        self.cuteNumberType = nil;
        self.loginLimit = 0;
        self.password = nil;
        self.phoneNumber = nil;
        self.platVipTime = nil;
        self.platformId = nil;
        self.token = nil;
        self.userId = nil;
        self.userLogoUrl = nil;
        self.userProtocolUpdate = 0;
        self.zoneData = nil;
        self.bindMobileReminderTime = [NSDate distantPast];
        self.realnameReminderTime = [NSDate distantPast];
        
        self.realName = nil;
        self.idcard = nil;
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)coder
{
    self = [super init];
    if (self) {
        self.adultState = [coder decodeIntegerForKey:@"adultState"];
        self.cuteNumber = [coder decodeObjectForKey:@"cuteNumber"];
        self.cuteNumberIcon = [coder decodeObjectForKey:@"cuteNumberIcon"];
        self.cuteNumberType = [coder decodeObjectForKey:@"cuteNumberType"];
        self.loginLimit = [coder decodeIntegerForKey:@"loginLimit"];
        //self.password = [coder decodeObjectForKey:@"password"];
        self.phoneNumber = [coder decodeObjectForKey:@"phoneNumber"];
        self.platVipTime = [coder decodeObjectForKey:@"platVipTime"];
        self.platformId = [coder decodeObjectForKey:@"platformId"];
        self.token = [coder decodeObjectForKey:@"token"];
        self.userId = [coder decodeObjectForKey:@"userId"];
        self.userLogoUrl = [coder decodeObjectForKey:@"userLogoUrl"];
        self.userProtocolUpdate = [coder decodeIntegerForKey:@"userProtocolUpdate"];
        self.zoneData = [coder decodeObjectForKey:@"zoneData"];
        
        self.userName = [coder decodeObjectForKey:@"userName"];
        
        self.bindMobileReminderTime = [coder decodeObjectForKey:@"bindMobileReminderTime"];
        self.realnameReminderTime = [coder decodeObjectForKey:@"realnameReminderTime"];
        self.localLoginTime = [coder decodeObjectForKey:@"localLoginTime"];
        
        self.zoneId = [coder decodeObjectForKey:@"zoneId"];
        self.zoneName = [coder decodeObjectForKey:@"zoneName"];
        self.roleId = [coder decodeObjectForKey:@"roleId"];
        self.roleName = [coder decodeObjectForKey:@"roleName"];
        self.roleLevel = [coder decodeObjectForKey:@"roleLevel"];
        self.gameCoin = [coder decodeIntegerForKey:@"gameCoin"];
        
        self.realName = [coder decodeObjectForKey:@"realName"];
        self.idcard = [coder decodeObjectForKey:@"idcard"];
    }
    return self;
}

- (void)encodeWithCoder:(NSCoder *)coder
{
    [coder encodeInteger:self.adultState forKey:@"adultState"];
    [coder encodeObject:self.cuteNumber forKey:@"cuteNumber"];
    [coder encodeObject:self.cuteNumberIcon forKey:@"cuteNumberIcon"];
    [coder encodeObject:self.cuteNumberType forKey:@"cuteNumberType"];
    [coder encodeInteger:self.loginLimit forKey:@"loginLimit"];
    //[coder encodeObject:self.password forKey:@"password"];
    [coder encodeObject:self.phoneNumber forKey:@"phoneNumber"];
    [coder encodeObject:self.platVipTime forKey:@"platVipTime"];
    [coder encodeObject:self.platformId forKey:@"platformId"];
    [coder encodeObject:self.token forKey:@"token"];
    [coder encodeObject:self.userId forKey:@"userId"];
    [coder encodeObject:self.userLogoUrl forKey:@"userLogoUrl"];
    [coder encodeInteger:self.userProtocolUpdate forKey:@"userProtocolUpdate"];
    [coder encodeObject:self.userName forKey:@"userName"];
    
    [coder encodeObject:self.bindMobileReminderTime forKey:@"bindMobileReminderTime"];
    [coder encodeObject:self.realnameReminderTime forKey:@"realnameReminderTime"];
    [coder encodeObject:self.localLoginTime forKey:@"localLoginTime"];
    
    [coder encodeObject:self.zoneId forKey:@"zoneId"];
    [coder encodeObject:self.zoneName forKey:@"zoneName"];
    [coder encodeObject:self.roleId forKey:@"roleId"];
    [coder encodeObject:self.roleName forKey:@"roleName"];
    [coder encodeObject:self.roleLevel forKey:@"roleLevel"];
    [coder encodeInteger:self.gameCoin forKey:@"gameCoin"];
    
    [coder encodeObject:self.realName forKey:@"realName"];
    [coder encodeObject:self.idcard forKey:@"idcard"];
}

- (void)decodeFromDictionary:(NSDictionary *)dictionary
{
    self.adultState = [[dictionary objectForKey:@"adultState"] integerValue];
    self.cuteNumber = [dictionary objectForKey:@"cuteNumber"];
    self.cuteNumberIcon = [dictionary objectForKey:@"cuteNumberIcon"];
    self.cuteNumberType = [dictionary objectForKey:@"cuteNumberType"];
    self.loginLimit = [[dictionary objectForKey:@"loginLimit"] integerValue];;
    self.password = [dictionary objectForKey:@"password"];
    self.phoneNumber = [BXRSAEncryptor BX_DesDecryptString:[dictionary objectForKey:@"phoneNumber"] keyString:[BXConfig config].desSecretKey iv:nil];
    self.platVipTime = [dictionary objectForKey:@"platVipTime"];
    self.platformId = [dictionary objectForKey:@"platformId"];
    self.token = [dictionary objectForKey:@"token"];
    self.userId = [dictionary objectForKey:@"userId"];
    self.userLogoUrl = [dictionary objectForKey:@"userLogoUrl"];
    self.userProtocolUpdate = [[dictionary objectForKey:@"userProtocolUpdate"] integerValue];
    self.zoneData = [dictionary objectForKey:@"zoneData"];
    
    self.realName = [BXRSAEncryptor BX_DesDecryptString:[dictionary objectForKey:@"realName"] keyString:[BXConfig config].desSecretKey iv:nil];
    self.idcard = [BXRSAEncryptor BX_DesDecryptString:[dictionary objectForKey:@"idCard"] keyString:[BXConfig config].desSecretKey iv:nil];
}

- (void)decodeInfo:(NSDictionary *)dictionary
{
    self.realName = [BXRSAEncryptor BX_DesDecryptString:[dictionary objectForKey:@"realName"] keyString:[BXConfig config].desSecretKey iv:nil];
    self.idcard = [BXRSAEncryptor BX_DesDecryptString:[dictionary objectForKey:@"idCard"] keyString:[BXConfig config].desSecretKey iv:nil];
}

- (NSDictionary *)proxyLoginResultDictionary {
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    [dict setObject:self.token forKey:@"userToken"];
    if ([BXConfig config].isSeries) {
        [dict setObject:[BXMobileManager shareManager].appID forKey:@"appId"];
        [dict setObject:[BXConfig config].platformId forKey:@"platformId"];
        [dict setObject:[BXConfig config].specialSign forKey:@"specialSign"];
    }
    return dict;
}

@end


@implementation BXUser (Archaive)

+ (NSString *)dirPathForStore {
    NSFileManager *filemanager = [NSFileManager defaultManager];
    NSString * cachesDir = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) firstObject];
    cachesDir = [cachesDir stringByAppendingPathComponent:@"Users"];

    BOOL isDir;
    BOOL isExit = [filemanager fileExistsAtPath:cachesDir isDirectory:&isDir];

    if (!isExit || !isDir) {
        [filemanager createDirectoryAtPath:cachesDir withIntermediateDirectories:YES attributes:nil error:nil];
    }
    return cachesDir;
}

+ (NSString *)pathForStore:(NSString *)loginName {
    NSString *filePath = [self dirPathForStore];
    filePath = [filePath stringByAppendingPathComponent:loginName];
    return filePath;
}

+ (NSArray<BXUser *> *)allUsers{
    NSString* cachePath = [self dirPathForStore];
    NSFileManager*fileManager = [NSFileManager defaultManager];
    if (![fileManager fileExistsAtPath:cachePath]) {
        return nil;
    }

    NSMutableArray *results = [NSMutableArray array];
    NSEnumerator* chileFilesEnumerator = [[fileManager subpathsAtPath:cachePath] objectEnumerator];
    NSString* fileName;
    while ((fileName = [chileFilesEnumerator nextObject]) !=nil) {
        NSString* fileAbsolutePath = [cachePath stringByAppendingPathComponent:fileName];
        BXUser *user = [self loadUserFromArchive:fileAbsolutePath];
        [results addObject:user];
    }
    NSArray *sortedResults = [results sortedArrayUsingComparator:^NSComparisonResult(BXUser *obj1, BXUser *obj2) {
        return ([obj1.localLoginTime compare:obj2.localLoginTime] == NSOrderedAscending);
    }];
    return sortedResults;
}

+ (instancetype)loadUserFromArchiveWithUserID:(NSString *)userID {
    BXUser *user = [self loadUserFromArchive:[self pathForStore:userID]];
    if (nil == user) {
        user = [[BXUser alloc] initWithUserID:userID];
    }
    return user;
}

+ (instancetype)loadUserFromArchive:(NSString *)filePath {
    BXUser* user = nil;
    @try {
        id obj= [NSKeyedUnarchiver unarchiveObjectWithFile:filePath];
        if ([obj isKindOfClass:[self class]]) {
            user = obj;
        }
    }
    @catch (NSException *exception) {
        BXLogError(@"exception: %@", exception);
    }
    @finally {
    }
    return user;
}

- (void)save {
    @synchronized(self) {
        NSFileManager *fileManager = [NSFileManager defaultManager];
        NSString *filePath = [BXUser pathForStore:self.userId];
        [NSKeyedArchiver archiveRootObject:self toFile:filePath];
        NSError *error;
        NSDictionary *protection = @{
            NSFileProtectionKey:NSFileProtectionComplete
        };
        [fileManager setAttributes:protection ofItemAtPath:filePath error:&error];
        if (error) {
            BXLogError(@"Protect user data failed because of %@", error);
        }
    }
}

- (void)remove {
    @synchronized(self) {
        NSFileManager *fileManager = [NSFileManager defaultManager];
        NSString *filePath = [BXUser pathForStore:self.userId];
        if ([fileManager fileExistsAtPath:filePath]) {
            NSError *error;
            [fileManager removeItemAtPath:filePath error:&error];
            if (error) {
                BXLogError(@"Remove file failed: %@", error);
            }
        }
    }
}

#pragma mark - 缓存账号和密码

- (void)recordAccount:(NSString *)account password:(NSString *)password {
    //record account
    [self recordAccount:account];
    //record password
    [self recordPassword:password forAccount:account];
}

- (void)recordAccount:(NSString *)account {
    NSMutableArray *accounts = [NSMutableArray arrayWithArray:[[NSUserDefaults standardUserDefaults] objectForKey:kBXDefaultsAccountsServiceKey]];
    if ([accounts containsObject:account]) {
        [accounts removeObject:account];
    }
        
    if ([account isEqualToString:self.userId]) {
        //当前登录为用户编号，判断下历史账号里面是否有手机号
        if ([accounts containsObject:self.phoneNumber]) {
            [accounts removeObject:self.phoneNumber];
            [BXUser removeRecordedPasswordForAccount:self.phoneNumber];
        }
    }else{
        //当前为手机号登录，判断下历史账号里面是否有用户编码
        if ([accounts containsObject:self.userId]) {
            [accounts removeObject:self.userId];
            [BXUser removeRecordedPasswordForAccount:self.userId];
        }
    }
    [accounts insertObject:account atIndex:0];
    [[NSUserDefaults standardUserDefaults] setObject:accounts forKey:kBXDefaultsAccountsServiceKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)recordPassword:(NSString *)password forAccount:(NSString *)account{
    if ([account isKindOfClass:[NSString class]] &&
        ![account isEqualToString:@""] &&
        [password isKindOfClass:[NSString class]] &&
        ![password isEqualToString:@""]) {
        NSString *key = [kBXKeychainPasswordServiceKey stringByAppendingPathExtension:account];
        [BXKeychain bx_setKeychainItem:password forServiceKey:key];
    }
}

#pragma mark - 清楚账号和密码缓存

+ (void)removeRecordedAccountAndPassword:(NSString *)account {
    //remove record account
    [self removeRecordedAccount:account];
    //remove record password
    [self removeRecordedPasswordForAccount:account];
}

+ (void)removeRecordedPasswordForAccount:(NSString *)account {
    if ([account isKindOfClass:[NSString class]] &&
        ![account isEqualToString:@""]) {
        NSString *key = [kBXKeychainPasswordServiceKey stringByAppendingPathExtension:account];
        [BXKeychain bx_setKeychainItem:nil forServiceKey:key];
    }
}

+ (void)removeRecordedAccount:(NSString *)account {
    NSMutableArray *accounts = [NSMutableArray arrayWithArray:[[NSUserDefaults standardUserDefaults] objectForKey:kBXDefaultsAccountsServiceKey]];
    if ([accounts containsObject:account]) {
        [accounts removeObject:account];
    }
    [[NSUserDefaults standardUserDefaults] setObject:accounts forKey:kBXDefaultsAccountsServiceKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

#pragma mark - 获取缓存的账号和密码

+ (NSArray<NSString *> *)recordedAccounts {
    NSMutableArray *accounts = [NSMutableArray arrayWithArray:[[NSUserDefaults standardUserDefaults] objectForKey:kBXDefaultsAccountsServiceKey]];
    return accounts;
}

+ (NSString *)recordedPassword:(NSString *)account{
    if ([account isKindOfClass:[NSString class]]) {
        NSString *key = [kBXKeychainPasswordServiceKey stringByAppendingPathExtension:account];
        return [BXKeychain bx_keychainItemForService:key];
    }
    return nil;
}

+ (BOOL)getAutoLogin{
    return [[NSUserDefaults standardUserDefaults] boolForKey:@"kWYWAutoLogin"];
}

+ (void)setAutoLogin:(BOOL)isAutoLogin{
    [[NSUserDefaults standardUserDefaults] setBool:isAutoLogin forKey:@"kWYWAutoLogin"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

@end
