//
//  BXHeaderView.m
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/9/02.
//  Copyright © 2021 Gavin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BXAttributedLabel.h"

@interface BXProgressHUD : UIView

@property(strong, nonatomic) UIView *bezelView;

@property(strong, nonatomic) UIButton *confirmBtn;

@property(strong, nonatomic) UIButton *cancelBtn;

@property(strong, nonatomic) UILabel *label;

@property(strong, nonatomic) BXAttributedLabel *detailsLabel;

@property (strong, nonatomic) UILabel *remarkLabel;

@property(nonatomic) BOOL hideWhenCallback;

@property(nonatomic) BOOL showCloseBtn;

@property (assign, nonatomic) BOOL hideToolsButtons;

@property(copy, nonatomic) void(^confirmBlock)(void);

@property(copy, nonatomic) void(^cancelBlock)(void);

- (instancetype) initWithView:(UIView *)view;

- (void) showAnimated:(BOOL)animated;

- (void)setDetailsLabelText:(NSString *)text;

@end
