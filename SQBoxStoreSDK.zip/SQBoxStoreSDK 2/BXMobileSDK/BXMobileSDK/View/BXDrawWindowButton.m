//
//  BXDrawWindowButton.m
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/8/24.
//  Copyright © 2021 Gavin. All rights reserved.
//

#import "BXDrawWindowButton.h"
#import <AudioToolbox/AudioToolbox.h>
#import "PureLayout.h"

#define WIDTH self.frame.size.width
#define HEIGHT self.frame.size.height
#define kScreenWidth [[UIScreen mainScreen] bounds].size.width
#define kScreenHeight [[UIScreen mainScreen] bounds].size.height

#define animateDuration 0.3       //位置改变动画时间
#define showDuration 0.1          //展开动画时间
#define statusChangeDuration  1    //状态改变时间
#define normalAlpha  0.9           //正常状态时背景alpha值
#define sleepAlpha  0.9           //隐藏到边缘时的背景alpha值
#define myBorderWidth 1.0         //外框宽度
#define marginWith  16             //间隔
#define kRadius 6	//
#define WZFlashInnerCircleInitialRaius  20
#define ItemSize 44
#define kContentViewHeight 50
// 展开
#define kMainImageButtonX 3
#define kMainImageButtonY 3

@interface BXDrawWindowButton()

@property(nonatomic)NSInteger frameWidth;
@property(nonatomic)BOOL  isShowTab;
@property(nonatomic,strong)UIPanGestureRecognizer *pan;
@property(nonatomic,strong)UITapGestureRecognizer *tap;

@property(strong, nonatomic) UIImage *mainImage;
@property(nonatomic,strong)UIView *contentView;
@property(strong, nonatomic) UIView *mainBoxView;
@property(nonatomic,copy)NSDictionary *imagesAndTitle;
@property(nonatomic,strong)UIColor *bgcolor;
@property(nonatomic,strong)CAAnimationGroup *animationGroup;
@property(nonatomic,strong)CAShapeLayer *circleShape;
@property(nonatomic,strong)UIColor *animationColor;

@property(nonatomic) UIInterfaceOrientation changeOrientation;
@property(nonatomic) BOOL isDraging;
@property(nonatomic) NSInteger icons;

@property(strong, nonatomic) UIView *hiddenView;
@property(strong, nonatomic) UIImageView *hiddenImageView;
@property(strong, nonatomic) UILabel *hiddenLabel;
@property (nonatomic, assign) BOOL willHiddenFlowWindow;
@property (nonatomic, assign) int turnNoticeShowNum; // 翻转提示最多显示5次

@property(nonatomic,strong)UIButton *mainImageButton;

@end

@implementation BXDrawWindowButton

+ (instancetype)sharedInstance {
    static id sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[self alloc]initWithFrame:CGRectMake(0, 100, 44, 44) mainImageName:[UIImage imageNamed:@"bxm_tubiao" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil] icons:1 bgcolor:BXHexColor(0x141414)];
    });
    return sharedInstance;
}

- (UIView *)hiddenView {
    if (!_hiddenView) {
        _hiddenView = [[UIView alloc] initWithFrame:CGRectZero];
        _hiddenView.hidden = YES;
        _hiddenView.backgroundColor = UIColor.clearColor;
        _hiddenView.backgroundColor = BXHexColor(0x141414);
    }
    return _hiddenView;
}

- (UIImageView *)hiddenImageView {
    if (!_hiddenImageView) {
        _hiddenImageView = [[UIImageView alloc] initWithImage:nil];
        _hiddenImageView.image = [UIImage imageNamed:@"bxm_tubiao" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
    }
    return _hiddenImageView;
}

- (UILabel *)hiddenLabel {
    if (!_hiddenLabel) {
        _hiddenLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        _hiddenLabel.text = @"拖到此处隐藏";
        _hiddenLabel.font = BXSystemFont(16);
        _hiddenLabel.textColor = [UIColor whiteColor];
        _hiddenLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _hiddenLabel;
}

- (UIView *)rootView {
    return [[UIApplication sharedApplication].windows firstObject];
}

- (void)setWillHiddenFlowWindow:(BOOL)willHiddenFlowWindow {
    if (_willHiddenFlowWindow != willHiddenFlowWindow) {
        AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
    }
    _willHiddenFlowWindow = willHiddenFlowWindow;
    _hiddenImageView.image = _willHiddenFlowWindow ? [UIImage imageNamed:@"bxm_guide_ic_hide_pre" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil] : [UIImage imageNamed:@"bxm_guide_ic_hide_def" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame mainImageName:(UIImage*)name imagesAndTitle:(NSDictionary*)imagesAndTitle bgcolor:(UIColor *)bgcolor{
    return  [self initWithFrame:frame mainImageName:name imagesAndTitle:imagesAndTitle bgcolor:bgcolor animationColor:nil];
}

- (instancetype)initWithFrame:(CGRect)frame mainImageName:(UIImage *)name icons:(NSInteger)icons bgcolor:(UIColor *)bgcolor
{
	self.icons = icons;
	return [self initWithFrame:frame mainImageName:name imagesAndTitle:@{} bgcolor:bgcolor animationColor:nil];
}

- (instancetype)initWithFrame:(CGRect)frame mainImageName:(UIImage *)mainImage imagesAndTitle:(NSDictionary*)imagesAndTitle bgcolor:(UIColor *)bgcolor animationColor:animationColor
{
    if(self = [super initWithFrame:frame])
    {
        NSAssert(mainImage != nil, @"mainImageName can't be nil !");
        NSAssert(imagesAndTitle != nil, @"imagesAndTitle can't be nil !");
        
        [self addHiddenView];
        
        self.turnNoticeShowNum = 0;
        _isShowTab = FALSE;

		self.mainImage = mainImage;
		
        self.backgroundColor = [UIColor clearColor];		
        self.windowLevel = UIWindowLevelAlert + 1;  //如果想在 alert 之上，则改成 + 2
		DYYController *vc = [DYYController new];
		vc.myWindow = self;
        self.rootViewController = vc;
        self.rootViewController.view.frame = self.bounds;
		
		[[UIApplication sharedApplication].keyWindow addSubview:self];
        
        _bgcolor = bgcolor;
        _frameWidth = 44;
        _imagesAndTitle = imagesAndTitle;
        _animationColor = animationColor;
		
        UIView *parentView = self.rootViewController.view;
		[parentView addSubview:self.contentView];
		self.contentView.alpha = 0;
        
        UIView *boxView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.width)];
        boxView.layer.cornerRadius = boxView.frame.size.height / 2;
        [parentView addSubview:boxView];
        self.mainBoxView = boxView;
        
        _mainImageButton =  [UIButton buttonWithType:UIButtonTypeCustom];
        [_mainImageButton setFrame:(CGRect){0, 0,frame.size.width, frame.size.height}];
        [_mainImageButton setImage:mainImage forState:UIControlStateNormal];
        _mainImageButton.alpha = sleepAlpha;
        [_mainImageButton addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
        if (_animationColor) {
            [_mainImageButton addTarget:self action:@selector(mainBtnTouchDown) forControlEvents:UIControlEventTouchDown];
        }
        
        [parentView addSubview:_mainImageButton];
        
        [self doBorderWidth:myBorderWidth color:nil cornerRadius:kContentViewHeight/2];
        
        _pan = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(locationChange:)];
        _pan.delaysTouchesBegan = NO;
        [self addGestureRecognizer:_pan];
        _tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(click:)];
        [self addGestureRecognizer:_tap];
        
        //设备旋转的时候收回按钮
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(orientChange:) name:UIApplicationDidChangeStatusBarOrientationNotification object:nil];
    }
    return self;
}

- (void)bx_dissmissButtonWindow{
    self.hidden = YES;
}

- (void)bx_showButtonWindow{
    self.hidden = NO;
    if ([self.gestureRecognizers indexOfObject:_pan]==NSNotFound) {
        [self addGestureRecognizer:_pan];
    }
    if (self.frame.origin.y<0 || self.frame.origin.x<0) {
        self.frame = CGRectMake(0, 100, self.frame.size.width,self.frame.size.height);
    }
}

/// 当前是否显示中
- (BOOL)isShow {
    return !self.hidden;
}

/// 改变隐藏或显示
- (void)changeHiddenOrShow {
    if (self.hidden) {
        [self bx_showButtonWindow];
    } else {
        [self bx_dissmissButtonWindow];
    }
}

- (void)addListenForTurn {
    __weak typeof(self) weakSelf = self;
    
}

- (void)bx_refreshUIWithMainIcon:(UIImage *)mainIcon {
    [self.mainImageButton setImage:mainIcon forState:UIControlStateNormal];
    self.mainImage = mainIcon;
}

- (void)addHiddenView {
    [[self rootView] addSubview:self.hiddenView];
    
    CGFloat hiddenViewHeight = kScreenHeight * 0.2;
    [self.hiddenView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0];
    [self.hiddenView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:0];
    [self.hiddenView autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:0];
    [self.hiddenView autoSetDimension:ALDimensionHeight toSize:hiddenViewHeight];
    
    [self.hiddenView addSubview:self.hiddenImageView];
    [self.hiddenView addSubview:self.hiddenLabel];

    [self.hiddenImageView sizeToFit];
//    [self.hiddenImageView autoSetDimensionsToSize:CGSizeMake(36, 36)];
    [self.hiddenLabel autoSetDimensionsToSize:CGSizeMake(100, 18)];
    
    [self.hiddenImageView autoAlignAxisToSuperviewAxis:ALAxisVertical];
    [self.hiddenImageView autoAlignAxis:ALAxisHorizontal toSameAxisOfView:self.hiddenImageView.superview withOffset:-15];
    [self.hiddenLabel autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.hiddenImageView  withOffset:5];
    [self.hiddenLabel autoAlignAxisToSuperviewAxis:ALAxisVertical];
}

- (void)showTurnNotice {
    if (self.turnNoticeShowNum >= 5) {
        return;
    }
    
    self.turnNoticeShowNum++;
    
}

#pragma mark ------- contentview 操作 --------------------
//按钮在屏幕右边时，左移contentview
- (void)moveContentviewLeft{
    _contentView.frame = (CGRect){0, 0 ,_contentView.frame.size.width,_contentView.frame.size.height};
	int count = (int)self.contentView.subviews.count;
	for (int i= count - 1; i>=0; i--) {
		CGRect frame = CGRectMake(5+i*44, 5, 44, 44);
		UIView *button = self.contentView.subviews[count-1-i];
		button.frame = frame;
	}
}

//按钮在屏幕左边时，contentview恢复默认
- (void)resetContentview{
    _contentView.frame = (CGRect){0,0,_contentView.frame.size.width,_contentView.frame.size.height};
	NSInteger count = self.contentView.subviews.count;
	for (int i=0; i<count; i++) {
		CGRect frame = CGRectMake(5+44+i*44, 5, 44, 44);
		UIView *button = self.contentView.subviews[i];
		button.frame = frame;
	}
}


#pragma mark  ------- 绘图操作 ----------
- (void)drawRect:(CGRect)rect {
    [self drawDash];
}

//分割线
- (void)drawDash{
    CGContextRef context =UIGraphicsGetCurrentContext();
    CGContextBeginPath(context);
    CGContextSetLineWidth(context, 0.1);
    CGContextSetStrokeColorWithColor(context, [UIColor clearColor].CGColor);
    CGFloat lengths[] = {2,1};
    CGContextSetLineDash(context, 0, lengths,2);
    for (int i = 1; i < _imagesAndTitle.count; i++){
        CGContextMoveToPoint(context, self.contentView.frame.origin.x + i * self.frameWidth, marginWith * 2);
        CGContextAddLineToPoint(context, self.contentView.frame.origin.x + i * self.frameWidth, self.frameWidth - marginWith * 2);
    }
    CGContextStrokePath(context);
}

//改变位置
- (void)locationChange:(UIPanGestureRecognizer*)p
{
    UIView *window = [self rootView];
    CGPoint panPoint = [p locationInView:window];

    if(p.state == UIGestureRecognizerStateBegan)
    {
        [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(changeStatus) object:nil];
        _mainImageButton.alpha = normalAlpha;
		self.isDraging = YES;
        [self pointDrag];
    }
    if(p.state == UIGestureRecognizerStateChanged)
    {
        self.center = CGPointMake(panPoint.x, panPoint.y);
		if(self.isShowTab){
			[self changeShowTabDirection];
		}
        [self dragHidden];
    }
    else if(p.state == UIGestureRecognizerStateEnded)
    {
        self.isDraging = NO;
        [self dragHidden];
        [self stopAnimation];
		
		CGPoint targetPoint;
        
        if(panPoint.x <= kScreenWidth/2)
        {
            if (panPoint.x < WIDTH/2+ItemSize/2 && panPoint.y > kScreenHeight-HEIGHT/2)
            {
				targetPoint = CGPointMake(WIDTH/2, kScreenHeight-HEIGHT/2);
            }
            else
            {
                CGFloat pointy = panPoint.y < HEIGHT/2 ? HEIGHT/2 :panPoint.y;
				targetPoint = CGPointMake(WIDTH/2, pointy);
            }
        }
        else if(panPoint.x > kScreenWidth/2)
        {
            if (panPoint.x > kScreenWidth-WIDTH/2-ItemSize/2 && panPoint.y < HEIGHT/2)
            {
				targetPoint = CGPointMake(kScreenWidth-WIDTH/2, HEIGHT/2);
				
            }
            else
            {
                CGFloat pointy = panPoint.y > kScreenHeight-HEIGHT/2 ? kScreenHeight-HEIGHT/2 :panPoint.y;
				targetPoint = CGPointMake(kScreenWidth-WIDTH/2, pointy);
            }
        }
		
		if(targetPoint.x!=0 && targetPoint.y!=0){
			[UIView animateWithDuration:animateDuration delay:0 options:UIViewAnimationOptionCurveEaseIn animations:^{
				self.center = targetPoint;
			} completion:^(BOOL finished) {
				if(!self.isShowTab){
					[self changeStatus];
				}
			}];
		}
		
		if (self.isShowTab) {
			[self autoDismissMe];
		}else{
//			[self performSelector:@selector(changeStatus) withObject:nil afterDelay:statusChangeDuration];
		}
	}else{
		
	}
}

// 拖动隐藏悬浮标
- (void)dragHidden {
    self.hiddenView.hidden = !self.isDraging;
    CGRect area = self.hiddenView.frame;
    CGFloat min = area.size.width * 0.2;
    area.size.width = min;
    area.origin.x = (self.hiddenView.frame.size.width - min) / 2;
    
    if (self.isDraging) {
        self.willHiddenFlowWindow = CGRectIntersectsRect(area, self.frame);
        
        if (!self.isShowTab) {
            self.mainBoxView.layer.borderWidth = 1;
            self.mainBoxView.layer.borderColor = UIColor.redColor.CGColor;
            self.mainBoxView.layer.cornerRadius = self.mainBoxView.frame.size.height / 2;
        }
    } else {
        self.willHiddenFlowWindow = NO;
        
        if (CGRectIntersectsRect(area, self.frame)) {
                [self bx_dissmissButtonWindow];
            }
        
        self.mainBoxView.layer.borderWidth = 0;
        self.mainBoxView.layer.borderColor = UIColor.clearColor.CGColor;
        self.mainBoxView.layer.cornerRadius = self.mainBoxView.frame.size.height / 2;
    }
}

- (void) changeShowTabDirection {
	CGFloat posY = MIN(self.frame.origin.y, kScreenHeight-_contentView.frame.size.height);
	CGFloat posX = MIN(self.frame.origin.x, kScreenWidth  - _contentView.frame.size.width);
	if (self.frame.origin.x <= kScreenWidth/2) {
		[self resetContentview];
		
		self.mainImageButton.frame = CGRectMake(kMainImageButtonX, kMainImageButtonY, self.frameWidth, self.frameWidth);
		
		self.frame = CGRectMake(self.frame.origin.x, posY, _contentView.frame.size.width , _contentView.frame.size.height);
	}else{
		[self moveContentviewLeft];
		
		self.mainImageButton.frame = CGRectMake(_contentView.frame.size.width - self.frameWidth - kMainImageButtonX, kMainImageButtonY, self.frameWidth, self.frameWidth);
		
		self.frame = CGRectMake( posX , posY, _contentView.frame.size.width ,_contentView.frame.size.height);
	}
}

- (void)autoDismissMe {
	//5秒自动收起
	static NSTimeInterval lastTime = 0;
	lastTime = [NSDate date].timeIntervalSince1970;
	dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
		if (self.isDraging) {
			return;
		}
		if (self.isShowTab && [NSDate date].timeIntervalSince1970 - lastTime >= 5) {
			[self performSelector:@selector(changeStatus) withObject:nil afterDelay:statusChangeDuration];
			[self click:nil];
		}
	});
}

//点击事件
- (void)click:(UITapGestureRecognizer*)p
{
    [self stopAnimation];
    self.itemClickBlock(0);
}

- (void)changeStatus
{
	CGFloat scale = 0.7;
	self.transform = CGAffineTransformMakeScale(scale, 1);
	CGPoint origin = self.center;
	CGFloat del = 15;
	if(self.frame.origin.x<10){
		self.center = CGPointMake(self.center.x+del, self.center.y);
	}else{
		self.center = CGPointMake(self.center.x-del, self.center.y);
	}
	[UIView animateWithDuration:0.5 delay:0 usingSpringWithDamping:0.4 initialSpringVelocity:0.3 options:0 animations:^{
		self.center = origin;
		// 放大
		self.transform = CGAffineTransformMakeScale(1, 1);
	} completion:^(BOOL finished) {
		[UIView animateWithDuration:1.0 animations:^{
			_mainImageButton.alpha = sleepAlpha;
		}];
		[UIView animateWithDuration:0.1 animations:^{
			CGFloat x = self.center.x < ItemSize/2+WIDTH/2 ? 0 :  self.center.x > kScreenWidth - ItemSize/2 -WIDTH/2 ? kScreenWidth : self.center.x;
			CGFloat y = self.center.y < ItemSize + HEIGHT/2 ? 0 : self.center.y > kScreenHeight - ItemSize - HEIGHT/2 ? kScreenHeight : self.center.y;
			
			//禁止停留在4个角
			if((x == 0 && y ==0) || (x == kScreenWidth && y == 0) || (x == 0 && y == kScreenHeight) || (x == kScreenWidth && y == kScreenHeight)){
				y = self.center.y;
			}
			self.center = CGPointMake(x, y);
		}];
	}];
}

- (void)doBorderWidth:(CGFloat)width color:(UIColor *)color cornerRadius:(CGFloat)cornerRadius{
    self.layer.cornerRadius = cornerRadius;
    self.layer.borderWidth = width;
    if (!color) {
        self.layer.borderColor = [UIColor clearColor].CGColor;
    }else{
        self.layer.borderColor = color.CGColor;
    }
}

#pragma mark  ------- animation -------------

- (void)buttonAnimation{

    self.layer.masksToBounds = NO;
    
    CGFloat scale = 1.0f;
    
    CGFloat width = self.mainImageButton.bounds.size.width, height = self.mainImageButton.bounds.size.height;

    CGFloat biggerEdge = width > height ? width : height, smallerEdge = width > height ? height : width;
    CGFloat radius = smallerEdge / 2 > WZFlashInnerCircleInitialRaius ? WZFlashInnerCircleInitialRaius : smallerEdge / 2;
    
    scale = biggerEdge / radius + 0.5;
    _circleShape = [self createCircleShapeWithPosition:CGPointMake(width/2, height/2)
                                                 pathRect:CGRectMake(0, 0, radius * 2, radius * 2)
                                                   radius:radius];
    
    [self.mainImageButton.layer addSublayer:_circleShape];
    
    CAAnimationGroup *groupAnimation = [self createFlashAnimationWithScale:scale duration:1.0f];
    
    [_circleShape addAnimation:groupAnimation forKey:nil];
}

- (void)stopAnimation{
  
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(buttonAnimation) object:nil];
    
    if (_circleShape) {
        [_circleShape removeFromSuperlayer];
    }
}

- (CAShapeLayer *)createCircleShapeWithPosition:(CGPoint)position pathRect:(CGRect)rect radius:(CGFloat)radius
{
    CAShapeLayer *circleShape = [CAShapeLayer layer];
    circleShape.path = [self createCirclePathWithRadius:rect radius:radius];
    circleShape.position = position;
    

    circleShape.bounds = CGRectMake(0, 0, radius * 2, radius * 2);
    circleShape.fillColor = _animationColor.CGColor;

    circleShape.opacity = 0;
    circleShape.lineWidth = 1;
    
    return circleShape;
}

- (CAAnimationGroup *)createFlashAnimationWithScale:(CGFloat)scale duration:(CGFloat)duration
{
    CABasicAnimation *scaleAnimation = [CABasicAnimation animationWithKeyPath:@"transform.scale"];
    scaleAnimation.fromValue = [NSValue valueWithCATransform3D:CATransform3DIdentity];
    scaleAnimation.toValue = [NSValue valueWithCATransform3D:CATransform3DMakeScale(scale, scale, 1)];
    
    CABasicAnimation *alphaAnimation = [CABasicAnimation animationWithKeyPath:@"opacity"];
    alphaAnimation.fromValue = @1;
    alphaAnimation.toValue = @0;
    
    _animationGroup = [CAAnimationGroup animation];
    _animationGroup.animations = @[scaleAnimation, alphaAnimation];
    _animationGroup.duration = duration;
    _animationGroup.repeatCount = INFINITY;
    _animationGroup.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut];
    
    return _animationGroup;
}


- (CGPathRef)createCirclePathWithRadius:(CGRect)frame radius:(CGFloat)radius
{
    return [UIBezierPath bezierPathWithRoundedRect:frame cornerRadius:radius].CGPath;
}

#pragma mark - getter

- (UIView *)contentView
{
	if (!_contentView) {
		if (self.icons==4) {
            _contentView = [[UIView alloc] init];
		}else{
			_contentView = [[UIView alloc] init];
		}
	}
	return _contentView;
}

#pragma mark - 埋点辅助
- (void)pointshowButtonWindow {}
- (void)pointHideWindow {}
- (void)pointDrag {}

- (void)mainBtnTouchDown{
    if (!self.isShowTab) {
        [self performSelector:@selector(buttonAnimation) withObject:nil afterDelay:0.5];
    }
}

#pragma mark  ------- 设备旋转 -----------
- (void)orientChange:(NSNotification *)notification{
    self.changeOrientation = [notification.userInfo[UIApplicationStatusBarOrientationUserInfoKey] intValue];
    
    //旋转前要先改变frame，否则坐标有问题（临时办法）
    self.frame = CGRectMake(0, kScreenHeight - self.frame.origin.y - self.frame.size.height, self.frame.size.width,self.frame.size.height);
    
    if (self.frame.origin.y<0 || self.frame.origin.x<0) {
        self.frame = CGRectMake(0, 100, self.frame.size.width,self.frame.size.height);
    }
}

@end

@implementation DYYController

- (BOOL)shouldAutorotate
{
	return YES;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations
{
		return UIInterfaceOrientationMaskAll;
}

@end
