//
//  BXThreeSelectionController.m
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/8/23.
//  Copyright © 2021 Gavin. All rights reserved.
//

#import "BXThreeSelectionView.h"
#import "BXPrivacyUtil.h"
#import "BXConfig.h"
#import "PureLayout.h"

@implementation BXThreeSelectionView

+(void)bx_showPrivacyViewWithPolicy:(BXVVThreeSelectionPrivacyStatus)policyState callback:(AgreeCallback)callBack{
    
    BXThreeSelectionView *view = [[BXThreeSelectionView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
    view.bx_eventCallback = callBack;
    view.bx_Status = policyState;
    
    if (policyState == bx_devicePrivacy){
        view.bx_titleLabel.text = [BXConfig config].grcDeviceInfo;
    }else{
        view.bx_titleLabel.text = [BXConfig config].grcDevicePermissions;
    }
        
    if (UIApplication.sharedApplication.keyWindow != nil){
        [UIApplication.sharedApplication.keyWindow addSubview:view];
    }else{
        UIWindow *window = [UIApplication.sharedApplication.windows objectAtIndex:0];
        [window addSubview:view];
    }
}

-(instancetype)initWithFrame:(CGRect)frame{
    
    self = [super initWithFrame:frame];
    if (self) {
        [self commonInit];
    }
    return self;
}

-(void)commonInit{
    
    UIView *bx_whiteView = [[UIView alloc]init];
    bx_whiteView.center = self.center;
    bx_whiteView.backgroundColor = UIColor.whiteColor;
    bx_whiteView.layer.cornerRadius = 5;
    bx_whiteView.layer.masksToBounds = YES;
    [self addSubview:bx_whiteView];
    
    UILabel *bx_topLabel = [[UILabel alloc]init];
    bx_topLabel.numberOfLines = 0;
    bx_topLabel.textAlignment = NSTextAlignmentCenter;
    bx_topLabel.textColor = BXHexColor(0x333333);
    bx_topLabel.font = BXBoldSystemFont(14);
    bx_topLabel.text = @"设备信息操作";
    [bx_whiteView addSubview:bx_topLabel];
    
    UILabel *bx_titleLabel = [[UILabel alloc]init];
    bx_titleLabel.numberOfLines = 0;
    bx_titleLabel.textAlignment = NSTextAlignmentJustified;
    bx_titleLabel.textColor = BXHexColor(0x666666);
    bx_titleLabel.font = BXSystemFont(12);
    [bx_whiteView addSubview:bx_titleLabel];
    
    UIButton *bx_rejectButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [bx_rejectButton setTitle:@"拒绝" forState:UIControlStateNormal];
    bx_rejectButton.backgroundColor = BXBackgroundColor;
    [bx_rejectButton setTitleColor:BXMainColor forState:UIControlStateNormal];
    bx_rejectButton.titleLabel.font = BXSystemFont(14);
    bx_rejectButton.layer.cornerRadius = 4;
    bx_rejectButton.layer.borderColor = BXMainColor.CGColor;
    bx_rejectButton.layer.borderWidth = 0.5;
    bx_rejectButton.layer.masksToBounds = YES;
    [bx_rejectButton addTarget:self action:@selector(clickReject) forControlEvents:UIControlEventTouchUpInside];
    [bx_whiteView addSubview:bx_rejectButton];
    
    UIButton *bx_thisTimeButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [bx_thisTimeButton setTitle:@"本次运行允许" forState:UIControlStateNormal];
    bx_thisTimeButton.backgroundColor = BXBackgroundColor;
    [bx_thisTimeButton setTitleColor:BXMainColor forState:UIControlStateNormal];
    bx_thisTimeButton.titleLabel.font = BXSystemFont(14);
    bx_thisTimeButton.layer.cornerRadius = 4;
    bx_thisTimeButton.layer.borderColor = BXMainColor.CGColor;
    bx_thisTimeButton.layer.borderWidth = 0.5;
    bx_thisTimeButton.layer.masksToBounds = YES;
    [bx_thisTimeButton addTarget:self action:@selector(clickThisTime) forControlEvents:UIControlEventTouchUpInside];
    [bx_whiteView addSubview:bx_thisTimeButton];
    
    
    UIButton *bx_acceptButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [bx_acceptButton setTitle:@"仅在使用中允许" forState:UIControlStateNormal];
    UIImage *aImage = [UIImage imageNamed:@"bxm_Anniu" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
    [bx_acceptButton setBackgroundImage:aImage forState:UIControlStateNormal];
    [bx_acceptButton setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    bx_acceptButton.titleLabel.font = BXSystemFont(14);
    bx_acceptButton.layer.cornerRadius = 4;
    bx_acceptButton.layer.masksToBounds = YES;
    [bx_acceptButton addTarget:self action:@selector(clickAccept) forControlEvents:UIControlEventTouchUpInside];
    [bx_whiteView addSubview:bx_acceptButton];
    
    UILabel *bx_bottomLabel = [[UILabel alloc]init];
    bx_bottomLabel.text = @"为了更好的游戏体验，建议允许本操作。";
    bx_bottomLabel.numberOfLines = 0;
    bx_bottomLabel.textAlignment = NSTextAlignmentCenter;
    bx_bottomLabel.textColor = BXHexColor(0x797979);
    bx_bottomLabel.font = BXSystemFont(12);
    [bx_whiteView addSubview:bx_bottomLabel];
    
    _bx_whiteView = bx_whiteView;
    _bx_topLabel = bx_topLabel;
    _bx_titleLabel = bx_titleLabel;
    _bx_rejectButton = bx_rejectButton;
    _bx_thisTimeButton = bx_thisTimeButton;
    _bx_acceptButton = bx_acceptButton;
    _bx_bottomLabel = bx_bottomLabel;
}

-(void)layoutSubviews{
    [super layoutSubviews];
    
    self.bx_whiteView.center = self.center;
    [self.bx_whiteView setFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
    
    self.bx_topLabel.frame = CGRectMake(15, 15, self.frame.size.width - 30, 20);
    self.bx_titleLabel.frame = CGRectMake(15, 45, self.frame.size.width - 30, self.bx_Status == bx_devicePrivacy ? 70 : 35);
    
    [self.bx_acceptButton autoSetDimensionsToSize:CGSizeMake(self.frame.size.width - 20, 40)];
    [self.bx_acceptButton autoAlignAxisToSuperviewMarginAxis:ALAxisVertical];
    [self.bx_acceptButton autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_titleLabel withOffset:10.0];
    
    [self.bx_rejectButton autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_acceptButton withOffset:10.0];
    [self.bx_rejectButton autoSetDimensionsToSize:CGSizeMake((self.frame.size.width - 40) / 2, 40)];
    [self.bx_rejectButton autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:10];
    [self.bx_rejectButton autoAlignAxis:ALAxisHorizontal toSameAxisOfView:self.bx_thisTimeButton];
    
    [self.bx_thisTimeButton autoSetDimensionsToSize:CGSizeMake((self.frame.size.width - 40) / 2, 40)];
    [self.bx_thisTimeButton autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:10];
    [self.bx_thisTimeButton autoMatchDimension:ALDimensionWidth toDimension:ALDimensionWidth ofView:self.bx_rejectButton];
    
    [self.bx_bottomLabel sizeToFit];
    [self.bx_bottomLabel autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:10];
    [self.bx_bottomLabel autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:10];
    [self.bx_bottomLabel autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_rejectButton withOffset:10.0];
}

-(void)clickReject{
    self.bx_eventCallback(false);
    [self removeFromSuperview];
}

-(void)clickThisTime{
    
    self.bx_eventCallback(true);
    [self removeFromSuperview];
    
    if (self.bx_Status == bx_devicePrivacy){
    }else{
        [BXPrivacyUtil bx_allowDeviceSendMsgCodeTemporary];
    }
}

-(void)clickAccept{
    self.bx_eventCallback(true);
    [self removeFromSuperview];
    
    if (self.bx_Status == bx_devicePrivacy){        
        [BXPrivacyUtil bx_allowbx_devicePrivacy];
    }else{
        [BXPrivacyUtil bx_allowDeviceSendMsgCode];
    }
}

@end
