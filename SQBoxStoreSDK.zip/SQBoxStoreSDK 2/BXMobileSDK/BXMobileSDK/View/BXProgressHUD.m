//
//  BXHeaderView.m
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/9/02.
//  Copyright © 2021 Gavin. All rights reserved.
//

#import "BXProgressHUD.h"
#import "UIImage+BXExtern.h"
#import "PureLayout.h"
#import "BXPrivacyUtil.h"

@interface BXProgressHUD()
@property (strong, nonatomic) UIView *line;
@property (strong, nonatomic) UIView *line2;
@property(strong, nonatomic) UIButton *backBtn;
@property (strong, nonatomic) CALayer *backgroundLayer;
@end

@implementation BXProgressHUD

-(instancetype)initWithView:(UIView *)view
{
    self = [super init];
    if (self) {
        _hideWhenCallback = YES;
        
        self.frame = view.bounds;
        self.backgroundColor = BXHexAColor(0x000000, 0.8);
        [view addSubview:self];
        
        _bezelView = [[UIView alloc]init];
        _bezelView.clipsToBounds = YES;
        _bezelView.layer.cornerRadius = 4;
        [self addSubview:_bezelView];
        
        _label = [UILabel new];
        _label.font = BXSystemFont(16);
        _label.textColor = [UIColor whiteColor];
        _label.textAlignment = NSTextAlignmentCenter;
        _label.numberOfLines = 2;
        _label.adjustsFontSizeToFitWidth = YES;
        _label.minimumScaleFactor = 0.5;
        [_bezelView addSubview:_label];
        
        _detailsLabel = [[BXAttributedLabel alloc] initWithFrame:CGRectZero];
        _detailsLabel.textAlignment = NSTextAlignmentCenter;
        _detailsLabel.font = BXSystemFont(14);
        _detailsLabel.textColor = BXHexAColor(0xffffff, 0.6);
        _detailsLabel.numberOfLines = 0;
        _detailsLabel.adjustsFontSizeToFitWidth = YES;
        _detailsLabel.minimumScaleFactor = 0.5;
        [_bezelView addSubview:_detailsLabel];
        
        _line = [[UIView alloc] init];
        _line.backgroundColor = BXHexAColor(0xffffff, 0.2);
        [_bezelView addSubview:_line];
        
        _line2 = [[UIView alloc] init];
        _line2.backgroundColor = BXHexAColor(0xffffff, 0.2);
        [_bezelView addSubview:_line2];
        
        _confirmBtn = [UIButton new];
        [_confirmBtn setTitleColor:BXHexColor(0xFF8800) forState:(UIControlStateNormal)];
        _confirmBtn.titleLabel.font = BXSystemFont(17);
        [_bezelView addSubview:_confirmBtn];
        
        _cancelBtn = [UIButton new];
        [_cancelBtn setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
        _cancelBtn.titleLabel.font = BXSystemFont(17);
        _cancelBtn.layer.borderColor = BXHexAColor(0xffffff, 0.2).CGColor;
        _cancelBtn.layer.borderWidth = 0.5;
        [_bezelView addSubview:_cancelBtn];
        
        _remarkLabel = [UILabel new];
        _remarkLabel.textAlignment = NSTextAlignmentCenter;
        _remarkLabel.font = BXSystemFont(15);
        _remarkLabel.textColor = BXHexAColor(0xffffff, 0.6);
        _remarkLabel.numberOfLines = 0;
        [_bezelView addSubview:_remarkLabel];
        
        _backBtn = [UIButton new];
        [_backBtn setImage:[UIImage bx_bundleImageWithName:@"nav_close_black"] forState:(UIControlStateNormal)];
        [_bezelView addSubview:_backBtn];
        
        [_backBtn addTarget:self action:@selector(closeAction) forControlEvents:UIControlEventTouchUpInside];
        [_confirmBtn addTarget:self action:@selector(confirmAction) forControlEvents:(UIControlEventTouchUpInside)];
        [_cancelBtn addTarget:self action:@selector(cancelAction) forControlEvents:(UIControlEventTouchUpInside)];
        
        //[self updateSize];
        
    }
    return self;
}

- (void) closeAction {
    [self hide:YES];
}

- (void)confirmAction{
    if(_hideWhenCallback){
        [self hide:YES];
    }
    if (self.confirmBlock) {
        self.confirmBlock();
        if(_hideWhenCallback){
            self.confirmBlock = nil;
        }
    }
}

- (void)cancelAction{
    [self hide:YES];
    if (self.cancelBlock) {
        self.cancelBlock();
        if(_hideWhenCallback){
            self.cancelBlock = nil;
        }
    }
}

- (void) updateSize {
    
    [self.bezelView autoSetDimensionsToSize:CGSizeMake(270, 135)];
    [self.bezelView autoCenterInSuperview];
    
    [self.label sizeToFit];
    [self.label autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:24];
    [self.label autoAlignAxis:ALAxisVertical toSameAxisOfView:self.bezelView withOffset:0];
    [self.label autoSetDimensionsToSize:CGSizeMake(238, 30)];
    
    CGSize size = [self.detailsLabel.text boundingRectWithSize:CGSizeMake(self.bezelView.frame.size.width - 40, 100) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName: self.detailsLabel.font} context:nil].size;
    self.detailsLabel.frame = CGRectMake(0, 0, size.width, size.height + 10);
    
    CGFloat line = self.detailsLabel.frame.size.height / 15;
    [self.detailsLabel autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:10];
    [self.detailsLabel autoAlignAxisToSuperviewAxis:ALAxisVertical];
    
    CGRect rect = self.bezelView.frame;
    rect.size.height += (line-1)*15;
    self.bezelView.frame = rect;
    [self.bezelView autoCenterInSuperview];
    
    [self.backBtn autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:8];
    [self.backBtn autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:self.bezelView.frame.size.width - self.backBtn.frame.size.width - 8];
    
    if (self.hideToolsButtons) {
        [self.line removeFromSuperview];
        [self.line2 removeFromSuperview];
        [self.confirmBtn removeFromSuperview];
        [self.cancelBtn removeFromSuperview];
        
        [self.bezelView autoSetDimensionsToSize:CGSizeMake(270, 70)];
        [self.bezelView autoCenterInSuperview];
        
        [self.backBtn autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:8];
        [self.backBtn autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:self.bezelView.frame.size.width - self.backBtn.frame.size.width - 8];
        return;
    }
    
    if (self.confirmBtn.titleLabel.text.length && self.cancelBtn.titleLabel.text.length == 0) {
        [self.confirmBtn autoSetDimensionsToSize:CGSizeMake(self.bezelView.frame.size.width + 1, 47)];
        [self.confirmBtn autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:-0.5];
        [self.confirmBtn autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:-1];
    }else if(self.confirmBtn.titleLabel.text.length && self.cancelBtn.titleLabel.text.length){
        [self.cancelBtn autoSetDimensionsToSize:CGSizeMake(self.bezelView.frame.size.width / 2 + 0.5, 47)];
        [self.cancelBtn autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:-1];
        [self.cancelBtn autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:-0.5];
        
        [self.confirmBtn autoSetDimensionsToSize:CGSizeMake(self.bezelView.frame.size.width, 47)];
        [self.confirmBtn autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:-1];
        [self.confirmBtn autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.cancelBtn withOffset:0];
    }
    
    [self.line autoSetDimensionsToSize:CGSizeMake(self.bezelView.frame.size.width, 0.5)];
    [self.line autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0];
    [self.line autoPinEdge:ALEdgeTop toEdge:ALEdgeTop ofView:self.confirmBtn withOffset:0];
    
    [self.line2 autoSetDimensionsToSize:CGSizeMake(self.bezelView.frame.size.width, 0.5)];
    [self.line2 autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0];
    [self.line2 autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.confirmBtn withOffset:0];
    
    if (self.remarkLabel.attributedText.length > 0) {
        [self.remarkLabel sizeToFit];
        [self.remarkLabel autoCenterInSuperview];
        [self.remarkLabel autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.confirmBtn withOffset:10];
        
        //        self.bezelView
        
        CGRect rect = self.bezelView.frame;
        rect.size.height += 10 * 2 + self.remarkLabel.frame.size.height;
        self.bezelView.frame = rect;
        [self.bezelView autoCenterInSuperview];
    }
}

- (void)setShowCloseBtn:(BOOL)showCloseBtn
{
    _showCloseBtn = showCloseBtn;
    self.backBtn.hidden = !showCloseBtn;
}

- (void)showAnimated:(BOOL)animated
{
    [self updateSize];
    
    self.bezelView.backgroundColor = UIColor.clearColor;
    CALayer *layer = [BXPrivacyUtil bx_alertBackgroundGradient];
    layer.frame = self.bezelView.bounds;
    [self.bezelView.layer insertSublayer:layer atIndex:0];
    self.backgroundLayer = layer;
    
    if (!animated) {
        return;
    }
    _bezelView.alpha = 0;
    [UIView animateWithDuration:.15 animations:^{
        _bezelView.alpha = 1;
    }];
}

- (void)setDetailsLabelText:(NSString *)text {
    self.detailsLabel.text = text;
    [self updateSize];
}

- (void) hide:(BOOL)animated {
    if (!animated) {
        [self removeFromSuperview];
    }else{
        [UIView animateWithDuration:.15 animations:^{
            _bezelView.alpha = 0;
        } completion:^(BOOL finished) {
            [self removeFromSuperview];
        }];
    }
}

@end
