//
//  BXTextField.m
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/24.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXTextField.h"
#import "UIImage+BXExtern.h"
#import "PureLayout.h"

typedef void (^BXTextFieldActionHander)(id);//定义block类型

@interface BXTextFieldAction ()
@property (nonatomic, readwrite, strong) UIButton *actionButton;
@property (nonatomic, copy) BXTextFieldActionHander actionHandler;
@end

@implementation BXTextFieldAction

- (instancetype)init
{
    self = [super init];
    if (self) {
        _enabled = YES;
        _userInteractionEnabled = YES;
    }
    return self;
}

#pragma mark Action With Title

+ (instancetype)actionWithTitle:(NSString *)title handler:(void (^)(BXTextFieldAction *action))handler {
    return [self actionWithTitle:title backgroundColor:nil disableBackgroundColor:nil handler:handler];
}

+ (instancetype)actionWithTitle:(NSString *)title backgroundColor:(UIColor *)backgroundColor disableBackgroundColor:(UIColor *)disableBackgroundColor handler:(void (^)(BXTextFieldAction *))handler {
    return [self actionWithTitle:title image:nil selectedImage:nil backgroundColor:backgroundColor disableBackgroundColor:disableBackgroundColor handler:handler];
}

#pragma mark Action With Image

+ (instancetype)actionWithImage:(NSString *)image handler:(void (^)(BXTextFieldAction *action))handler {
    return [self actionWithImage:image selectedImage:nil handler:handler];
}

+ (instancetype)actionWithImage:(NSString *)image selectedImage:(NSString *)selectedImage handler:(void (^)(BXTextFieldAction *action))handler {
    return [self actionWithTitle:nil image:image selectedImage:selectedImage backgroundColor:nil disableBackgroundColor:nil handler:handler];
}

+ (instancetype)actionWithTitle:(NSString *)title image:(NSString *)image selectedImage:(NSString *)selectedImage backgroundColor:(UIColor *)backgroundColor disableBackgroundColor:(UIColor *)disableBackgroundColor handler:(void (^)(BXTextFieldAction *action))handler {
    BXTextFieldAction *action = [[BXTextFieldAction alloc] init];
    
    UIButton *button = [[UIButton alloc] init];
    
    [button setTitleColor:BXHexColor(0xFFFFFF) forState:UIControlStateNormal];
    [button setTitleColor:BXHexColor(0x767B82) forState:UIControlStateHighlighted];
    [button setTitleColor:BXHexColor(0x767B82) forState:UIControlStateDisabled];
    [button.titleLabel setFont:[UIFont systemFontOfSize:12]];
    [button setClipsToBounds:YES];
    [button addTarget:action action:@selector(touchActionButton:) forControlEvents:UIControlEventTouchUpInside];
    
    if (title) {
        [button setTitle:title forState:UIControlStateNormal];
    }
    
    if (image) {
        UIImage *aImage = [UIImage imageNamed:image inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
        [button setImage:aImage forState:UIControlStateNormal];
    }
    
    if (selectedImage) {
        UIImage *aImage = [UIImage imageNamed:selectedImage inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
        [button setImage:aImage forState:UIControlStateSelected];
    }
    
    if (backgroundColor) {
        UIImage *aImage = [UIImage bx_imageWithColor:backgroundColor];
        [button setBackgroundImage:aImage forState:UIControlStateNormal];
    }
    
    if (disableBackgroundColor) {
        UIImage *aImage = [UIImage bx_imageWithColor:disableBackgroundColor];
        [button setBackgroundImage:aImage forState:UIControlStateDisabled];
    }

    action.actionButton = button;
    
    if (handler) {
        action.actionHandler = handler;
    }
    
    return action;
}

- (void)touchActionButton:(id)sender {
    if (self.actionHandler) { self.actionHandler(self); }
}

- (void)setEnabled:(BOOL)enabled {
    _enabled = enabled;
    self.actionButton.enabled = enabled;
}

- (void)setUserInteractionEnabled:(BOOL)userInteractionEnabled {
    _userInteractionEnabled = userInteractionEnabled;
    self.actionButton.userInteractionEnabled = userInteractionEnabled;
}

- (void)setActionTitle:(NSString *)title forState:(UIControlState)state {
    if (title) {
        [self.actionButton setTitle:title forState:state];
        if ([self.actionButton.superview superview]) {
            [[self.actionButton.superview superview] setNeedsLayout];
        }
    }
}

@end

@interface BXTextField ()<UITextFieldDelegate>
{
    NSMutableArray *_leddingActions;
    NSMutableArray *_trillingActions;
}
@property (nonatomic, strong, readwrite) NSMutableArray *leftviews;
@property (nonatomic, strong, readwrite) NSMutableArray *rightviews;
@end

@implementation BXTextField

#ifdef DEBUG
- (void)dealloc
{
    BXLogDebug(@"dealloc");
}
#endif

- (void)drawRect:(CGRect)rect {
    [super drawRect:rect];
    
    if (_lineColor) {
        CGContextRef context = UIGraphicsGetCurrentContext();
        UIColor *fillColor = _lineColor ?: [UIColor darkGrayColor];
        CGContextSetFillColorWithColor(context, fillColor.CGColor);
        CGRect fillRect = CGRectMake(0, CGRectGetHeight(self.bounds) - 0.5, CGRectGetWidth(self.bounds), 0.5);
        CGContextFillRect(context,fillRect);
    }
}

- (void)setLineColor:(UIColor *)underlineColor {
    _lineColor = underlineColor;
    [self setNeedsDisplay];
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.delegate = self;
        _leftviews = [NSMutableArray array];
        _leddingActions = [NSMutableArray array];
        
        _trillingActions = [NSMutableArray array];
        _rightviews = [NSMutableArray array];
        
        self.font = BXSystemFont(14);
        self.keyboardType = UIKeyboardTypeASCIICapable;
        self.autocorrectionType = UITextAutocorrectionTypeNo;
        self.autocapitalizationType = UITextAutocapitalizationTypeNone;
        self.clipsToBounds = YES;
        
        UIView *leftView = [[UIView alloc] init];
        [leftView setFrame:CGRectMake(0, 0, 15, 15)];
        self.leftView = leftView;
        self.leftViewMode = UITextFieldViewModeAlways;
        
        UIView *rightView = [[UIView alloc] init];
        [rightView setFrame:CGRectMake(0, 0, 15, 15)];
        self.rightView = [[UIView alloc] init];
        self.rightViewMode = UITextFieldViewModeWhileEditing;
    }
    return self;
}

+ (instancetype)textFieldWithTitle:(nullable NSString *)title placeHolder:(nullable NSString *)placeHolder {
    BXTextField *textField = [[BXTextField alloc] init];
    textField.text = title;
    textField.placeholder = placeHolder;
    NSAttributedString *attributedPlaceholder = [[NSAttributedString alloc] initWithString:placeHolder attributes: @{NSForegroundColorAttributeName:BXTextFieldPlaceHolderColor, NSFontAttributeName:textField.font}];
    textField.attributedPlaceholder = attributedPlaceholder;
    return textField;
}

- (void)setLeddingActions:(NSArray<BXTextFieldAction *> *)actions {
    if (nil == self.leftView) {
        self.leftView = [[UIView alloc] init];
    }
    
     // actions 为空时移除leftView
    [self.leftView.subviews enumerateObjectsUsingBlock:^(__kindof UIView * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [obj removeFromSuperview];
    }];

    [self.leftviews removeAllObjects];
    self.leftviews = nil;
    
    [_leddingActions removeAllObjects];
    _leddingActions = nil;
    
    _leddingActions = [actions mutableCopy];
    NSMutableArray *views = [NSMutableArray array];
    [_leddingActions enumerateObjectsUsingBlock:^(BXTextFieldAction * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [views addObject:obj.actionButton];
        [self.leftView addSubview:obj.actionButton];
    }];
    self.leftviews = [views mutableCopy];
    
    if (self.leftviews.count) {
        CGFloat contentWidth = 0;
        CGFloat contentHeight = 0;
        
        contentWidth+=10;
        [self.leftviews.firstObject autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:10];
        [self.leftviews.firstObject autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
        
        if (self.leftviews.count > 1) {
            [self.leftviews autoAlignViewsToAxis:ALAxisHorizontal];
        }
        
        UIView *previousView = nil;
        for (UIButton *view in self.leftviews) {
            if (previousView) {
                contentWidth+=10;
                [view autoPinEdge:ALEdgeLeading toEdge:ALEdgeTrailing ofView:previousView withOffset:10.0];
            }
            
            CGSize imageSize = view.currentImage.size;
            CGSize bgImageSize = view.currentBackgroundImage.size;
            CGSize textSize = [view.titleLabel.text sizeWithAttributes:@{NSFontAttributeName:view.titleLabel.font}];
            CGFloat width = MAX(MAX(ceil(textSize.width), ceil(imageSize.width)), ceil(bgImageSize.width));
            CGFloat height = MAX(MAX(ceil(textSize.height), ceil(imageSize.height)), ceil(bgImageSize.height));
        
            if ((width == 0 || height == 0) && self.leftviews) {
                width = 1;
                height = 15;
                [view autoSetDimensionsToSize:CGSizeMake(width, height)];
            }

            contentWidth += width;
            contentHeight = MAX(contentHeight, height);
            
            previousView = view;
        }
        
        contentWidth+=10;
        [previousView autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:10];
        [self.leftView setFrame:CGRectMake(0, 0, contentWidth, contentHeight)];
    }
    
    [self setNeedsLayout];
}

- (void)setTrillingActions:(NSArray<BXTextFieldAction *> *)actions {
    if (nil == self.rightView) {
        self.rightView = [[UIView alloc] init];
    }
    
    // actions 为空时移除leftView
    [self.rightView.subviews enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [(UIView *)obj removeFromSuperview];
    }];
  
    [self.rightviews removeAllObjects];
    self.rightviews = nil;
    
    [_trillingActions removeAllObjects];
    _trillingActions = nil;
    
    _trillingActions = [actions mutableCopy];
    NSMutableArray *views = [NSMutableArray arrayWithCapacity:self.leddingActions.count];
    [_trillingActions enumerateObjectsUsingBlock:^(BXTextFieldAction * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [views addObject:obj.actionButton];
        [self.rightView addSubview:obj.actionButton];
    }];
    self.rightviews = [views mutableCopy];
    
    if (self.rightviews.count > 0) {
        CGFloat contentWidth = 0;
        CGFloat contentHeight = 0;
        
        contentWidth+=10;
        [self.rightviews.firstObject autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:14];
        [self.rightviews.firstObject autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
        
        if (self.rightviews.count > 1) {
            [self.rightviews autoAlignViewsToAxis:ALAxisHorizontal];
        }
        
        UIView *previousView = nil;
        for (UIButton *view in self.rightviews) {
            if (previousView) {
                contentWidth+=10;
                [view autoPinEdge:ALEdgeTrailing toEdge:ALEdgeLeading ofView:previousView withOffset:-10.0];
            }
            
            CGSize imageSize = view.currentImage.size;
            CGSize bgImageSize = view.currentBackgroundImage.size;
            CGSize textSize = [view.titleLabel.text sizeWithAttributes:@{NSFontAttributeName:view.titleLabel.font}];
            CGFloat width = MAX(MAX(ceil(textSize.width), ceil(imageSize.width)), ceil(bgImageSize.width));
            CGFloat height = MAX(MAX(ceil(textSize.height), ceil(imageSize.height)), ceil(bgImageSize.height));
            
            if ((width == 0 || height == 0) && self.rightviews) {
                width = 1;
                height = 15;
                [view autoSetDimensionsToSize:CGSizeMake(width, height)];
            }
            
            contentWidth += width;
            contentHeight = MAX(contentHeight, height);
            
            if ([view.titleLabel.text isEqualToString:@"发送验证码"]) {
                [view autoSetDimension:ALDimensionHeight toSize:40];
                [view autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:0];
                [view autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0];
            }
            
            previousView = view;
        }
        
        contentWidth+=10;
        [previousView autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:10];
        [self.rightView setFrame:CGRectMake(0, 0, contentWidth, contentHeight)];
    }
    
    [self setNeedsLayout];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField{
    self.backgroundColor = BXHexColor(0xE9F2FF);
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    self.backgroundColor = [UIColor clearColor];
}

////控制清除按钮的位置
//-(CGRect)clearButtonRectForBounds:(CGRect)bounds{
//   return CGRectMake(bounds.origin.x + bounds.size.width - 50, bounds.origin.y + bounds.size.height -20, 16, 16);
//}
//
////控制placeHolder的位置，左右缩20
//-(CGRect)placeholderRectForBounds:(CGRect)bounds
//{
//    //return CGRectInset(bounds, 20, 0);
//   CGRect inset = CGRectMake(bounds.origin.x+100, bounds.origin.y, bounds.size.width -10, bounds.size.height);//更好理解些
//   return inset;
//}
//
////控制显示文本的位置
//-(CGRect)textRectForBounds:(CGRect)bounds
//{
//    //return CGRectInset(bounds, 50, 0)
//    CGRect inset = CGRectMake(bounds.origin.x+190, bounds.origin.y, bounds.size.width -10, bounds.size.height);//更好理解些
//    return inset;
//}
//
////控制编辑文本的位置
//-(CGRect)editingRectForBounds:(CGRect)bounds
//{
//    //return CGRectInset( bounds, 10 , 0 );
//   CGRect inset = CGRectMake(bounds.origin.x +10, bounds.origin.y, bounds.size.width -10, bounds.size.height);
//   return inset;
//}
//
////控制左视图位置
//- (CGRect)leftViewRectForBounds:(CGRect)bounds
//{
//   CGRect inset = CGRectMake(bounds.origin.x +10, bounds.origin.y, bounds.size.width-250, bounds.size.height);
//   return inset;
//    //return CGRectInset(bounds,50,0);
//}

@end
