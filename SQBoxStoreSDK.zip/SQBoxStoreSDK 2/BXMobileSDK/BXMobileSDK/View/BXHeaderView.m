//
//  BXHeaderView.m
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/8/27.
//  Copyright © 2021 Gavin. All rights reserved.
//

#import "BXHeaderView.h"
#import "PureLayout.h"
#import "UIImage+BXExtern.h"

@implementation BXHeaderView

-(instancetype)initWithFrame:(CGRect)frame{
    
    self = [super initWithFrame:frame];
    if (self) {
        [self commonInit];
    }
    return self;
}

-(void)commonInit{
    UIView *bx_whiteView = [[UIView alloc]init];
    bx_whiteView.center = self.center;
    bx_whiteView.backgroundColor = UIColor.whiteColor;
    [self addSubview:bx_whiteView];
    
    UILabel *bx_titleLabel = [[UILabel alloc]init];
    bx_titleLabel.textAlignment = NSTextAlignmentCenter;
    bx_titleLabel.textColor = BXHexColor(0x333333);
    bx_titleLabel.font = BXBoldSystemFont(14);
    [bx_whiteView addSubview:bx_titleLabel];
    
    UIButton *bx_leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [bx_leftButton setImage:[UIImage bx_bundleImageWithName:@"bxm_back"] forState:(UIControlStateNormal)];
    [bx_leftButton addTarget:self action:@selector(clickReject) forControlEvents:UIControlEventTouchUpInside];
    [bx_whiteView addSubview:bx_leftButton];
    
    UIButton *bx_rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [bx_rightButton setImage:[UIImage imageNamed:@"bxm_shuaxin" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil] forState:(UIControlStateNormal)];
    [bx_rightButton addTarget:self action:@selector(clickAccept) forControlEvents:UIControlEventTouchUpInside];
    [bx_whiteView addSubview:bx_rightButton];
    bx_rightButton.hidden = YES;
    
    _bx_whiteView = bx_whiteView;
    _bx_leftButton = bx_leftButton;
    _bx_titleLabel = bx_titleLabel;
    _bx_rightButton = bx_rightButton;
}

- (void)drawRect:(CGRect)rect {
    [super drawRect:rect];
    
    self.bx_whiteView.center = self.center;
    [self.bx_whiteView setFrame:CGRectMake(0, 0, rect.size.width, rect.size.height)];
    
    [self.bx_titleLabel autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:40];
    [self.bx_titleLabel autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:0];
    [self.bx_titleLabel autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:0];
    [self.bx_titleLabel autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:40];
    
    [self.bx_leftButton autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:10];
    [self.bx_leftButton autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:0];
    [self.bx_leftButton autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:0];
    [self.bx_leftButton autoSetDimension:ALDimensionWidth toSize:30];
    
    [self.bx_rightButton autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:10];
    [self.bx_rightButton autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:0];
    [self.bx_rightButton autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:0];
    [self.bx_rightButton autoSetDimension:ALDimensionWidth toSize:30];
}

-(void)bx_baseHeaderViewSetString:(NSString *)titleString rightButtonIs:(BOOL)flag{
    self.bx_titleLabel.text = titleString;
    self.bx_rightButton.hidden = flag;
}

-(void)bx_baseHeaderViewSetString:(NSString *)titleString{
    self.bx_titleLabel.text = titleString;
}

-(void)clickReject{
    if (self.bx_leftCallback) {
        self.bx_leftCallback();
    }
}

-(void)clickAccept{
    if (self.bx_rightCallback) {
        self.bx_rightCallback();
    }
}

@end
