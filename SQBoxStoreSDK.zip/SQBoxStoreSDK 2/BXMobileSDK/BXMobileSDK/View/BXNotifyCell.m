//
//  BXNotifyCell.m
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/30.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXNotifyCell.h"

@interface BXNotifyCell ()

@end

@implementation BXNotifyCell


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        UIImage *normalImage = [UIImage imageNamed:@"notify_cell_normal" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
        UIImage *selectedImage = [UIImage imageNamed:@"notify_cell_selected" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
        
        self.backgroundView = [[UIImageView alloc] initWithImage:normalImage];
        self.backgroundColor = [UIColor clearColor];
        self.contentView.backgroundColor = [UIColor clearColor];
        self.selectedBackgroundView = [[UIImageView alloc] initWithImage:selectedImage];
        self.textLabel.textAlignment = NSTextAlignmentCenter;
        self.textLabel.font = BXSystemFont(12);
        self.textLabel.textColor = BXHexColor(0x60d1b1);
        self.textLabel.numberOfLines = 2;
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
    if (selected) {
        self.textLabel.textColor = BXHexColor(0xFFFFFF);
    }else{
        self.textLabel.textColor = BXHexColor(0x60D1B1);
    }
}

@end
