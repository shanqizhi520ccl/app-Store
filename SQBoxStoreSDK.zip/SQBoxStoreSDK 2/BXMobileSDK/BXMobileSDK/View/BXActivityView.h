//
//  BXActivityView.h
//  BXActivityView
//
//  Created by MAC on 16/12/16.
//  Copyright © 2016年 MrBai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BXActivityView : UIView

@end
