//
//  BXTextField.h
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/24.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import <UIKit/UIKit.h>

//NS_ASSUME_NONNULL_BEGIN

@interface BXTextFieldAction : NSObject

@property (nonatomic, readonly) UIButton *actionButton;
@property (nonatomic, getter=isEnabled) BOOL enabled;
@property (nonatomic, getter=isUserInteractionEnabled) BOOL userInteractionEnabled;

//Action with title.
+ (instancetype)actionWithTitle:(NSString *)title
                        handler:(void (^)(BXTextFieldAction *action))handler;
//Action with title and background image.
+ (instancetype)actionWithTitle:(NSString *)title
                backgroundColor:(UIColor *)backgroundColor
         disableBackgroundColor:(UIColor *)disableBackgroundColor
                        handler:(void (^)(BXTextFieldAction *action))handler;

//Action with image.
+ (instancetype)actionWithImage:(NSString *)image
                        handler:(void (^)(BXTextFieldAction *action))handler;
//Action with image and selected image.
+ (instancetype)actionWithImage:(NSString *)image
                  selectedImage:(NSString *)selectedImage
                        handler:(void (^)(BXTextFieldAction *action))handler;

- (void)setActionTitle:(NSString *)title forState:(UIControlState)state;

@end


@interface BXTextField : UITextField

@property (nonatomic, readonly) NSArray<BXTextFieldAction *> *leddingActions;

@property (nonatomic, readonly) NSArray<BXTextFieldAction *> *trillingActions;

@property (nonatomic, strong) UIColor *lineColor;

+ (instancetype)textFieldWithTitle:(NSString *)title placeHolder:(NSString *)placeHolder;

- (void)setLeddingActions:(NSArray<BXTextFieldAction *> *)actions;

- (void)setTrillingActions:(NSArray<BXTextFieldAction *> *)actions;

@end

//NS_ASSUME_NONNULL_END
