//
//  BXThreeSelectionController.m
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/8/23.
//  Copyright © 2021 Gavin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, BXVVThreeSelectionPrivacyStatus) {
    bx_devicePrivacy = 0,
    bx_msgCodePrivacy = 1
};

@interface BXThreeSelectionView : UIView

typedef void (^AgreeCallback)(BOOL); // 同意回调
@property (copy, nonatomic) AgreeCallback bx_eventCallback;
@property (assign, nonatomic) BXVVThreeSelectionPrivacyStatus bx_Status;
@property (retain, nonatomic) UILabel *bx_titleLabel;
@property (retain, nonatomic) UILabel *bx_topLabel;
@property (nonatomic, strong) UIView *bx_whiteView;
@property (nonatomic, strong) UIButton *bx_rejectButton;
@property (nonatomic, strong) UIButton *bx_thisTimeButton;
@property (nonatomic, strong) UIButton *bx_acceptButton;
@property (nonatomic, strong) UILabel *bx_bottomLabel;

+(void)bx_showPrivacyViewWithPolicy:(BXVVThreeSelectionPrivacyStatus)policyState callback:(AgreeCallback)callBack;

@end

NS_ASSUME_NONNULL_END
