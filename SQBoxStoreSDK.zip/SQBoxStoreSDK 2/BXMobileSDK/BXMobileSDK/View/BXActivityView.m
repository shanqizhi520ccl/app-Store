//
//  BXActivityView.m
//  BXActivityView
//
//  Created by MAC on 16/12/16.
//  Copyright © 2016年 MrBai. All rights reserved.
//

#import "BXActivityView.h"

@interface BXActivityView ()
@property (nonatomic, strong) UIView *contentView;
@property (nonatomic, strong) CAReplicatorLayer *reaplicator;
@property (nonatomic, strong) CALayer *showlayer;
@end

@implementation BXActivityView

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self setupViews];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setupViews];
    }
    return self;
}

- (void)setupViews {
    self.backgroundColor = [UIColor clearColor];
    UIView *contentView = [[UIView alloc] init];
    contentView.backgroundColor = [UIColor clearColor];
    [self addSubview:contentView];
    
    CAReplicatorLayer *repelicator = [CAReplicatorLayer layer];
    [contentView.layer addSublayer:repelicator];
    
    CALayer *layer = [CALayer layer];
    [repelicator addSublayer:layer];
    
    _contentView = contentView;
    _showlayer = layer;
    _reaplicator = repelicator;
    
    [self startAnimation];
}

- (void)dealloc
{
    [self.showlayer removeAllAnimations];
    [self.showlayer removeFromSuperlayer];
    [self.reaplicator removeFromSuperlayer];
    self.showlayer = nil;
    self.reaplicator = nil;
}

- (void)startAnimation {
    CABasicAnimation *animaiton = [CABasicAnimation animation];
    animaiton.keyPath = @"transform.scale";
    animaiton.fromValue = @(1);
    animaiton.toValue = @(0.1);
    animaiton.duration = 1.0f;
    animaiton.fillMode = kCAFillModeForwards;
    animaiton.removedOnCompletion = NO;
    animaiton.repeatCount = INT_MAX;
    [self.showlayer addAnimation:animaiton forKey:@"anmation"];
}

- (void)stopAnimation {
    [self.showlayer removeAllAnimations];
}

- (void)drawRect:(CGRect)rect {
    [super drawRect:rect];
    
    self.contentView.center = self.center;
    [self.contentView setFrame:CGRectMake(0, 0, rect.size.width, rect.size.height)];
    
    int numofInstance = 8;
    CGFloat duration = 1.0f;
    self.reaplicator.bounds = CGRectMake(0, 0, self.contentView.bounds.size.width, self.contentView.bounds.size.height);
    self.reaplicator.position = CGPointMake(self.contentView.bounds.size.width*0.5, self.contentView.bounds.size.height*0.5);
    self.reaplicator.instanceCount = numofInstance;
    self.reaplicator.instanceDelay = duration / numofInstance;
    self.reaplicator.instanceTransform = CATransform3DMakeRotation(M_PI * 2.0 / 8.0, 0, 0, 1);
    
    self.showlayer.frame = CGRectMake(0, 0, 6, 6);
    CGPoint point = [self.reaplicator convertPoint:self.reaplicator.position fromLayer:self.contentView.layer];
    self.showlayer.position = CGPointMake(point.x, point.y - 10);
    self.showlayer.backgroundColor = BXHexColor(0x60D1B1).CGColor;
    self.showlayer.cornerRadius = 3;
    self.showlayer.transform = CATransform3DMakeScale(0.01, 0.01, 1);
}


@end
