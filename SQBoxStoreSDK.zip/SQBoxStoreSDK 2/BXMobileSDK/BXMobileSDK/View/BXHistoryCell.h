//
//  BXHistoryCell.h
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/8/3.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BXHistoryCell : UITableViewCell

@property (nonatomic, strong) UIImageView *iconImageView;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *subTitleLabel;
@property (nonatomic, strong) UIButton *accessoryButton;

@end

NS_ASSUME_NONNULL_END
