//
//  BXHistoryCell.m
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/8/3.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXHistoryCell.h"
#import "PureLayout.h"

@interface BXHistoryCell ()
@property (nonatomic, assign) BOOL bx_didSetupConstraints;
@property (nonatomic) UITableViewCellStyle aCellStyle;
@end

@implementation BXHistoryCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.backgroundColor = BXTextFieldBackgroundColor;
        self.backgroundView = nil;
        self.selectedBackgroundView = nil;
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    
        if (style != UITableViewCellStyleValue2) {
            [self addSubview:self.iconImageView];
        }
        
        [self addSubview:self.titleLabel];
        [self addSubview:self.subTitleLabel];
        
        self.accessoryView = self.accessoryButton;
        
        [self updateConstraintsIfNeeded];
    }
    return self;
}

- (void)updateConstraints {
    if (!_bx_didSetupConstraints) {
        if (self.aCellStyle != UITableViewCellStyleValue2) {
            [self.iconImageView autoAlignAxis:ALAxisHorizontal toSameAxisOfView:self.titleLabel];
            [self.iconImageView autoPinEdgeToSuperviewMargin:ALEdgeLeading withInset:0];
            [self.iconImageView autoSetDimensionsToSize:self.iconImageView.image.size];
            
            [self.titleLabel autoPinEdgeToSuperviewMargin:ALEdgeTop withInset:0];
            [self.titleLabel autoPinEdge:ALEdgeLeading toEdge:ALEdgeTrailing ofView:self.iconImageView withOffset:5];
            
            [self.subTitleLabel autoPinEdgeToSuperviewMargin:ALEdgeBottom withInset:0];
            [self.subTitleLabel autoPinEdge:ALEdgeLeading toEdge:ALEdgeTrailing ofView:self.iconImageView withOffset:5];
            
            [self.titleLabel autoPinEdgeToSuperviewMargin:ALEdgeTrailing withInset:55];
            [self.subTitleLabel autoPinEdgeToSuperviewMargin:ALEdgeTrailing withInset:55];
        }else{
            [self.titleLabel autoAlignAxisToSuperviewAxis:ALAxisVertical];
            [self.titleLabel autoPinEdgeToSuperviewMargin:ALEdgeLeading];
            
            [self.subTitleLabel autoAlignAxisToSuperviewAxis:ALAxisVertical];
            [self.subTitleLabel autoPinEdge:ALEdgeTop toEdge:ALEdgeTrailing ofView:self.titleLabel withOffset:5];
        }
        
        _bx_didSetupConstraints = YES;
    }
    [super updateConstraints];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (UILabel *)titleLabel {
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc] init];
        _titleLabel.font = BXSystemFont(12);
        _titleLabel.textColor = BXHexColor(0x767B82);
    }
    return _titleLabel;
}

- (UILabel *)subTitleLabel {
    if (!_subTitleLabel) {
        _subTitleLabel = [[UILabel alloc] init];
        _subTitleLabel.font = BXSystemFont(10);
        _subTitleLabel.textColor = BXHexColor(0x767B82);
    }
    return _subTitleLabel;
}

- (UIImageView *)iconImageView {
    if (!_iconImageView) {
        _iconImageView = [[UIImageView alloc] init];
        UIImage *headIcon = [UIImage imageNamed:@"tf_account" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
        _iconImageView.image = headIcon;
    }
    return _iconImageView;
}

- (UIButton *)accessoryButton {
    if (!_accessoryButton) {
        _accessoryButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _accessoryButton.frame = CGRectMake(0, 0, 50, 21);
        UIImage *image = [UIImage imageNamed:@"cell_btn_bg" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
        [_accessoryButton setTitle:@"选择" forState:UIControlStateNormal];
        [_accessoryButton setBackgroundImage:image forState:UIControlStateNormal];
        [_accessoryButton setTitleColor:BXHexColor(0xFFFFFF) forState:UIControlStateNormal];
        [_accessoryButton.titleLabel setFont:BXSystemFont(12)];
    }
    return _accessoryButton;
}

@end
