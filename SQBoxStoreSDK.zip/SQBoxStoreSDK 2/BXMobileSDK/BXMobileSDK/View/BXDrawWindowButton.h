//
//  BXDrawWindowButton.m
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/8/24.
//  Copyright © 2021 Gavin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BXDrawWindowButton : UIWindow

@property (nonatomic,copy) void(^itemClickBlock)(NSInteger index);

+ (instancetype)sharedInstance;

// 显示（默认）
- (void)bx_showButtonWindow;

// 隐藏
- (void)bx_dissmissButtonWindow;

//重要：所有图片都要是圆形的，程序里并没有自动处理成圆形
// 更换悬浮窗图标(可选)
- (void)bx_refreshUIWithMainIcon:(UIImage *)mainIcon;

@end

@interface DYYController : UIViewController

@property(weak, nonatomic) UIWindow *myWindow;

@end
