//
//  BXHeaderView.h
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/8/27.
//  Copyright © 2021 Gavin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

//NS_ASSUME_NONNULL_BEGIN
typedef void(^LeftBlock)(void);
typedef void(^RightBlock)(void);

@interface BXHeaderView : UIView

@property (copy, nonatomic) LeftBlock bx_leftCallback;
@property (copy, nonatomic) RightBlock bx_rightCallback;

@property (nonatomic, strong) UIView *bx_whiteView;
@property (nonatomic, strong) UIButton *bx_leftButton;
@property (retain, nonatomic) UILabel *bx_titleLabel;
@property (nonatomic, strong) UIButton *bx_rightButton;

-(void)bx_baseHeaderViewSetString:(NSString *)titleString rightButtonIs:(BOOL)flag;
-(void)bx_baseHeaderViewSetString:(NSString *)titleString;

@end

//NS_ASSUME_NONNULL_END
