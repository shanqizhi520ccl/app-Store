//
//  NSString+BXExtern.h
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/14.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import <Foundation/Foundation.h>


//NS_ASSUME_NONNULL_BEGIN

@interface NSString (BXExtern)

/// 校验输入用户名
/// @param value 用户名
+ (BOOL)bx_checkValidityForUsername:(NSString *)value;

/// 校验输入密码
/// @param value 密码
+ (BOOL)bx_checkValidityForPassword:(NSString *)value;

/// 校验是否数字
/// @param value 文本
+ (BOOL)isdigit:(NSString *)value;

/// 校验输入手机号
/// @param value 手机号
+ (BOOL)bx_checkValidityForPhoneNumber:(NSString *)value;

/// 校验输入验证码
/// @param value 验证码
+ (BOOL)bx_checkValidityForSmsCode:(NSString *)value;

/// 简单校验输入身份证号码
/// @param value 身份证号码
+ (BOOL)bx_simplyCheckValidityForIDCard:(NSString *)value;

/// 校验输入身份证号码
/// @param value 身份证号码
+ (BOOL)bx_checkValidityForIDCard:(NSString *)value;

/// 校验是否是URL
/// @param value URL
+ (BOOL)bx_checkValidityForURL:(NSString *)value;

- (NSString *)bx_md5;

- (BOOL)bx_isEmpty;

- (NSString *)bx_urlEncode;

+ (NSString *)randomString:(NSInteger)number;
@end

//NS_ASSUME_NONNULL_END
