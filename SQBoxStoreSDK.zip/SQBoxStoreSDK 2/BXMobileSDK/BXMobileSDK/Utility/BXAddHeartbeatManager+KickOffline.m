//
//  asdadViewController.h
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/9/1.
//  Copyright © 2021 Gavin. All rights reserved.
//


#import "BXAddHeartbeatManager+KickOffline.h"
#import "BXPrivacyUtil.h"
#import "BXMBProgressHUD+BXExtern.h"
#import "BXAttributedLabel.h"
#import "BXProgressHUD.h"

@interface BXAddHeartbeatManager ()<BXAttributedLabelDelegate>

@end

@implementation BXAddHeartbeatManager (KickOffline)
- (NSAttributedString *)remarkAttributedString {
    NSDictionary *attributes = @{
        NSFontAttributeName: BXSystemFont(15),
        NSForegroundColorAttributeName: BXHexColor(0xFF8800),
    };
    NSDictionary *appendAttributes = @{
        NSFontAttributeName: BXSystemFont(15),
        NSForegroundColorAttributeName: BXHexAColor(0xffffff, .6),
    };
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"%ld", (long)self.bx_forceOffLineTimeout] attributes:attributes];
    NSAttributedString *appendString = [[NSAttributedString alloc] initWithString:@" 秒后自动退出游戏" attributes:appendAttributes];
    [attributedString appendAttributedString:appendString];
    return [attributedString copy];
}

- (void)bx_processKickOffWithSuccessResponse:(NSDictionary *)response {
    NSDictionary *forceOffLine = response[@"forceOffLine"];
    
    NSString *kickOffMsg = [forceOffLine objectForKey:@"msg"];
    
    NSString *kickOffTimeout = [forceOffLine objectForKey:@"time"];
    
    NSString *type = [forceOffLine objectForKey:@"type"];
    
    self.bx_forceOffLineTimeout = [kickOffTimeout integerValue];
    
    __weak typeof(self) weakSelf = self;
    if ([type isEqualToString:@"0"]) {
        if (self.bx_forceOffLineTimeout < 1) {
            BXLog(@"[kick]: timeout value is unsupport");
            return;
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            [weakSelf showKickOfflineViewWithText:@"亲爱的玩家，您的账号已被封禁，如有疑问，请联系在线客服" highlightText:@"在线客服"];
            
            weakSelf.bx_forceOffLineTimer = [NSTimer timerWithTimeInterval:1 target:weakSelf selector:@selector(forceOffLineAction) userInfo:nil repeats:YES];
            
            [[NSRunLoop currentRunLoop] addTimer:weakSelf.bx_forceOffLineTimer forMode:NSRunLoopCommonModes];
        });
    } else if ([type isEqualToString:@"1"]) { // 实名认证踢下线和踢下线同样逻辑
        dispatch_async(dispatch_get_main_queue(), ^{
            if (![kickOffMsg isKindOfClass:[NSString class]] || [kickOffMsg isEqualToString:@""]) {
                BXLog(@"普通-直接踢下线");
                [BXPrivacyUtil bx_exitApplication];
                return;
            }
            BXLog(@"普通-踢下线");
            [weakSelf showKickOfflineViewWithText:kickOffMsg highlightText:nil];
            
            weakSelf.bx_forceOffLineTimer = [NSTimer timerWithTimeInterval:1 target:weakSelf selector:@selector(forceOffLineAction) userInfo:nil repeats:YES];
            
            [[NSRunLoop currentRunLoop] addTimer:weakSelf.bx_forceOffLineTimer forMode:NSRunLoopCommonModes];
        });
    }
}

- (void)bx_processAntiAuthRealNameResponse:(NSDictionary *)response {
    NSString *msg = [response objectForKey:@"adultLimitMsg"];
    
    self.bx_forceOffLineTimeout = 6;
    
    [self showKickOfflineViewWithText:msg highlightText:nil];
    
    self.bx_forceOffLineTimer = [NSTimer timerWithTimeInterval:1 target:self selector:@selector(forceOffLineAction) userInfo:nil repeats:YES];
    
    [[NSRunLoop currentRunLoop] addTimer:self.bx_forceOffLineTimer forMode:NSRunLoopCommonModes];
}

- (void)forceOffLineAction {
    self.bx_forceOffLineTimeout--;
    
    if (self.bx_forceOffLineTimeout <= 0) {
        [self.bx_forceOffLineTimer invalidate];
        
        self.bx_forceOffLineTimer = nil;
        
        [BXPrivacyUtil bx_exitApplication];
    }
    
    [BXMBProgressHUD bx_showMessage:[[self remarkAttributedString] string]];
}

//- (void)showKickOfflineViewWithText:(NSString *)text highlightText:(NSString *)highlightText {
//
//    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"系统提示" message:text preferredStyle:UIAlertControllerStyleAlert];
//    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
//
//    }];
//    [alertController addAction:okAction];
//    [[BXPrivacyUtil bx_currentPresentestController] presentViewController:alertController animated:NO completion:nil];
//}

- (void)showKickOfflineViewWithText:(NSString *)text highlightText:(NSString *)highlightText {
    UIView *view = [BXPrivacyUtil bx_currentController].view;
    
    self.bx_forceOffLineHud = [[BXProgressHUD alloc] initWithView:view];
    self.bx_forceOffLineHud.label.text = @"系统提示";
    self.bx_forceOffLineHud.remarkLabel.attributedText = [self remarkAttributedString];
    [self.bx_forceOffLineHud.confirmBtn setTitle:@"确认" forState:(UIControlStateNormal)];
    [self.bx_forceOffLineHud.cancelBtn setTitle:nil forState:(UIControlStateNormal)];
    self.bx_forceOffLineHud.confirmBlock = ^{
        [BXPrivacyUtil bx_exitApplication];
    };
    self.bx_forceOffLineHud.cancelBlock = nil;
    
    NSString *detailMessage = text;
    [self.bx_forceOffLineHud.detailsLabel setText:detailMessage afterInheritingLabelAttributesAndConfiguringWithBlock:^NSMutableAttributedString *(NSMutableAttributedString *att) {
        [att setAttributes:@{NSForegroundColorAttributeName:BXHexAColor(0xffffff, .6),
                             NSFontAttributeName:BXSystemFont(15)} range:NSMakeRange(0, detailMessage.length)];
        return att;
    }];
    
    if (highlightText) {
        NSRange range = [detailMessage rangeOfString:highlightText];
        NSDictionary *dic = @{NSForegroundColorAttributeName:BXHexColor(0xFF8800),
                              NSFontAttributeName:BXSystemFont(15),
                              NSUnderlineStyleAttributeName:@1};
        self.bx_forceOffLineHud.detailsLabel.activeLinkAttributes = dic;
        self.bx_forceOffLineHud.detailsLabel.linkAttributes = dic;
        
        [self.bx_forceOffLineHud.detailsLabel addLinkToURL:nil withRange:range];
        self.bx_forceOffLineHud.detailsLabel.delegate = self;
    }
    
    [self.bx_forceOffLineHud showAnimated:YES];
}

#pragma mark - BXAttributedLabelDelegate
- (void)attributedLabel:(BXAttributedLabel *)label didSelectLinkWithURL:(NSURL *)url {
    if (self.isGoService) {
        [self gotoService];
    }
    [BXPrivacyUtil bx_exitApplication];
}

- (void)gotoService {
    NSString *service = [BXPrivacyUtil bx_serviceWebUrl];
    NSURL *serviceUrl = [NSURL URLWithString:service];
    BOOL success = [[UIApplication sharedApplication] openURL:serviceUrl];
    BXLog(@"[kick]: Open service %@, success - %d", serviceUrl, success);
}

@end
