//
//  BXHelper.h
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/14.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import <Foundation/Foundation.h>

//NS_ASSUME_NONNULL_BEGIN

@interface BXHelper : NSObject

//Bundle Info
+ (NSString *)getBundleIdentifier;
+ (NSString *)getBundleVersion;
+ (NSString *)getBundleShortVersionString;

+ (NSDictionary *)paltformInfoDictionary;
+ (NSDictionary *)versionInfoDictionary;

@end

//NS_ASSUME_NONNULL_END
