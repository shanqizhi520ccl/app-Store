//
//  asdadViewController.h
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/9/1.
//  Copyright © 2021 Gavin. All rights reserved.
//


#import <Foundation/Foundation.h>
@class BXProgressHUD;

NS_ASSUME_NONNULL_BEGIN

@interface BXAddHeartbeatManager : NSObject

+ (nonnull instancetype)sharedInstance;

- (void)start;

- (void)stop;
/**
 停止5分钟后弹出的实名认证 hud 计时器
 */
- (void)bx_stopAntiAddictionTimer;
@end

@interface BXAddHeartbeatManager ()

@property (assign, nonatomic, getter=isGoService) BOOL goService;

@property (strong, nonatomic) BXProgressHUD *bx_forceOffLineHud;

@property (assign, nonatomic) NSInteger bx_forceOffLineTimeout;

@property (strong, nonatomic, nullable) NSTimer *bx_forceOffLineTimer;

@end

NS_ASSUME_NONNULL_END
