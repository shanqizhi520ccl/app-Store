/**
 * Copyright 2014 Accela, Inc.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Accela.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#import <Foundation/Foundation.h>

/**
 *  Flags accompany each log. They are used together with levels to filter out logs.
 */
typedef NS_OPTIONS(NSUInteger, BXLogFlag){
    /**
     *  0...00000 BXLogFlagError
     */
    BXLogFlagError      = (1 << 0),
    
    /**
     *  0...00001 BXLogFlagWarning
     */
    BXLogFlagWarning    = (1 << 1),
    
    /**
     *  0...00010 BXLogFlagInfo
     */
    BXLogFlagInfo       = (1 << 2),
    
    /**
     *  0...00100 BXLogFlagDebug
     */
    BXLogFlagDebug      = (1 << 3),
    
    /**
     *  0...01000 BXLogFlagVerbose
     */
    BXLogFlagVerbose    = (1 << 4)
};

/**
 *  Log levels are used to filter out logs. Used together with flags.
 */
typedef NS_ENUM(NSUInteger, BXLogLevel){
    /**
     *  No logs
     */
    BXLogLevelOff       = 0,
    
    /**
     *  Error logs only
     */
    BXLogLevelError     = (BXLogFlagError),
    
    /**
     *  Error and warning logs
     */
    BXLogLevelWarning   = (BXLogLevelError   | BXLogFlagWarning),
    
    /**
     *  Error, warning and info logs
     */
    BXLogLevelInfo      = (BXLogLevelWarning | BXLogFlagInfo),
    
    /**
     *  Error, warning, info and debug logs
     */
    BXLogLevelDebug     = (BXLogLevelInfo    | BXLogFlagDebug),
    
    /**
     *  Error, warning, info, debug and verbose logs
     */
    BXLogLevelVerbose   = (BXLogLevelDebug   | BXLogFlagVerbose),
    
    /**
     *  All logs (1...11111)
     */
    BXLogLevelAll       = NSUIntegerMax
};

@interface BXLogger : NSObject {
    
}

/**
 * Sets the log level.
 *
 * @param level The level to set. 
 *
 * @since 1.0
 */

+ (void)setLogLevel: (BXLogLevel)level;

/**
 * Logs an error message to the Apple System Log facility.
 *
 * @param format The string to write to the Apple System Log facility.
 *
 * @since 1.0
 */
+ (void)logError: (NSString *)format,...;

/**
 * Logs an warning message to the Apple System Log facility.
 *
 * @param format The string to write to the Apple System Log facility.
 *
 * @since 1.0
 */
+ (void)logWarn: (NSString *)format,...;

/**
 * Logs an information message to the Apple System Log facility.
 *
 * @param format The string to write to the Apple System Log facility.
 *
 * @since 1.0
 */
+ (void)logInfo: (NSString *)format,...;

/**
 * Logs an information message to the Apple System Log facility.
 *
 * @param format The string to write to the Apple System Log facility.
 *
 * @since 1.0
 */
+ (void)logDebug: (NSString *)format,...;

/**
 * Logs a verbose message to the Apple System Log facility.
 *
 * @param format The string to write to the Apple System Log facility.
 *
 * @since 1.0
 */
+ (void)logVerbose: (NSString *)format,...;

/**
 * Clears buffers and causes any buffered data to be written to the Apple System Log facility.
 *
 * @since 1.0
 */
+ (void)flush;

@end


#ifdef DEBUG
        #define BXLogError(frmt, ...) [BXLogger logError:@"[Log][❌]: %s " frmt, __PRETTY_FUNCTION__, ##__VA_ARGS__]
        #define BXLogWarn(frmt, ...) [BXLogger logWarn:@"[Log][⚠️]: %s " frmt, __PRETTY_FUNCTION__, ##__VA_ARGS__]
        #define BXLogInfo(frmt, ...) [BXLogger logInfo:@"[Log]: %s " frmt, __PRETTY_FUNCTION__, ##__VA_ARGS__]
        #define BXLogDebug(frmt, ...) [BXLogger logDebug:@"[Log]: %s " frmt, __PRETTY_FUNCTION__, ##__VA_ARGS__]
        #define BXLogVerbose(frmt, ...) [BXLogger logVerbose:@"[Log]: %s " frmt, __PRETTY_FUNCTION__, ##__VA_ARGS__]
#else
        #define BXLogError(frmt, ...) [BXLogger logError:@"[Log][❌]: %s " frmt, __FUNCTION__, ##__VA_ARGS__]
        #define BXLogWarn(frmt, ...) [BXLogger logWarn:@"[Log][⚠️]: %s " frmt, __FUNCTION__, ##__VA_ARGS__]
        #define BXLogInfo(frmt, ...) [BXLogger logInfo:@"[Log]: %s " frmt, __FUNCTION__, ##__VA_ARGS__]
        #define BXLogDebug(frmt, ...) [BXLogger logDebug:@"[Log]: %s " frmt, __FUNCTION__, ##__VA_ARGS__]
        #define BXLogVerbose(frmt, ...) [BXLogger logVerbose:@"[Log]: %s " frmt, __FUNCTION__, ##__VA_ARGS__]
#endif


