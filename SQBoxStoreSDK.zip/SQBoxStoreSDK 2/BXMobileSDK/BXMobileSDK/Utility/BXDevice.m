//
//  BXDevice.m
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/2.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXDevice.h"
#import <sys/utsname.h>
#import <AdSupport/AdSupport.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
#import <CoreTelephony/CTCarrier.h>

@implementation BXDevice

+ (NSString *)deviceIDFV {
    return [[UIDevice currentDevice].identifierForVendor UUIDString];
}

+ (NSString *)deviceName {
    return [[UIDevice currentDevice] name];
}

+ (NSString *)systemVerson {
    return [[UIDevice currentDevice] systemVersion];
}

+ (NSString *)systemName {
    return [[UIDevice currentDevice] systemName];
}

+ (NSString *)systemModel {
    return  [[UIDevice currentDevice] localizedModel];
}

+ (NSString *)systemInfo {
    // All iOS Models: https://www.theiphonewiki.com/wiki/Models
    static dispatch_once_t onceToken;
    static NSDictionary *dictModels;
    dispatch_once(&onceToken, ^{
        dictModels = @{
            /************ Apple Watch ************/
            /* Apple Watch */
            @"Watch1,1" : @"Apple Watch",
            @"Watch1,2" : @"Apple Watch",
            /* Apple Watch Series 1 */
            @"Watch2,6" : @"Apple Watch Series 1",
            @"Watch2,7" : @"Apple Watch Series 1",
            /* Apple Watch Series 2 */
            @"Watch2,3" : @"Apple Watch Series 2",
            @"Watch2,4" : @"Apple Watch Series 2",
            /* Apple Watch Series 3 */
            @"Watch3,1" : @"Apple Watch Series 3",
            @"Watch3,2" : @"Apple Watch Series 3",
            @"Watch3,3" : @"Apple Watch Series 3",
            @"Watch3,4" : @"Apple Watch Series 3",
            /* Apple Watch Series 4 */
            @"Watch4,1" : @"Apple Watch Series 4",
            @"Watch4,2" : @"Apple Watch Series 4",
            @"Watch4,3" : @"Apple Watch Series 4",
            @"Watch4,4" : @"Apple Watch Series 4",
            
            /************ iPad ************/
            /* iPad */
            @"iPad1,1" : @"iPad",
            /* iPad 2 */
            @"iPad2,1" : @"iPad 2",
            @"iPad2,2" : @"iPad 2",
            @"iPad2,3" : @"iPad 2",
            @"iPad2,4" : @"iPad 2",
            /* iPad 3 */
            @"iPad3,1" : @"iPad 3",
            @"iPad3,2" : @"iPad 3",
            @"iPad3,3" : @"iPad 3",
            /* iPad 4 */
            @"iPad3,4" : @"iPad 4",
            @"iPad3,5" : @"iPad 4",
            @"iPad3,6" : @"iPad 4",
            /* iPad Air */
            @"iPad4,1" : @"iPad Air",
            @"iPad4,2" : @"iPad Air",
            @"iPad4,3" : @"iPad Air",
            /* iPad Air 2 */
            @"iPad5,3" : @"iPad Air 2",
            @"iPad5,4" : @"iPad Air 2",
            /* iPad Pro (12.9 inch) */
            @"iPad6,7" : @"iPad Pro",
            @"iPad6,8" : @"iPad Pro",
            /* iPad Pro (9.7 inch) */
            @"iPad6,3" : @"iPad Pro",
            @"iPad6,4" : @"iPad Pro",
            /* iPad (5th generation) */
            @"iPad6,11" : @"iPad 5",
            @"iPad6,12" : @"iPad 5",
            /* iPad Pro (12.9-inch, 2nd generation) */
            @"iPad7,1" : @"iPad Pro",
            @"iPad7,2" : @"iPad Pro",
            /* iPad Pro (10.5-inch) */
            @"iPad7,3" : @"iPad Pro",
            @"iPad7,4" : @"iPad Pro",
            /* iPad (6th generation) */
            @"iPad7,5" : @"iPad 6",
            @"iPad7,6" : @"iPad 6",
            /* iPad Pro (11-inch) */
            @"iPad8,1" : @"iPad Pro",
            @"iPad8,2" : @"iPad Pro",
            @"iPad8,3" : @"iPad Pro",
            @"iPad8,4" : @"iPad Pro",
            @"iPad8,5" : @"iPad Pro",
            @"iPad8,6" : @"iPad Pro",
            @"iPad8,7" : @"iPad Pro",
            @"iPad8,8" : @"iPad Pro",
            /* iPad Air (3rd generation) */
            @"iPad11,3" : @"iPad Air 3",
            @"iPad11,4" : @"iPad Air 3",
            
            
            /************ iPad  Mini ************/
            /* iPad Mini */
            @"iPad2,5" : @"iPad Mini",
            @"iPad2,6" : @"iPad Mini",
            @"iPad2,7" : @"iPad Mini",
            /* iPad Mini 2 */
            @"iPad4,4" : @"iPad Mini 2",
            @"iPad4,5" : @"iPad Mini 2",
            @"iPad4,6" : @"iPad Mini 2",
            /* iPad Mini 3 */
            @"iPad4,7" : @"iPad Mini 3",
            @"iPad4,8" : @"iPad Mini 3",
            @"iPad4,9" : @"iPad Mini 3",
            /* iPad Mini 4 */
            @"iPad5,1" : @"iPad Mini 4",
            @"iPad5,2" : @"iPad Mini 4",
            /* iPad mini (5th generation) */
            @"iPad11,1" : @"iPad Mini 5",
            @"iPad11,2" : @"iPad Mini 5",
            
            /************ iPhone ************/
            /* iPhone 4 */
            @"iPhone3,1" : @"iPhone 4",
            @"iPhone3,2" : @"iPhone 4",
            @"iPhone3,3" : @"iPhone 4",
            /* iPhone 4S */
            @"iPhone4,1" : @"iPhone 4S",
            /* iPhone 5 */
            @"iPhone5,1" : @"iPhone 5",
            @"iPhone5,2" : @"iPhone 5",
            /* iPhone 5C */
            @"iPhone5,3" : @"iPhone 5C",
            @"iPhone5,4" : @"iPhone 5C",
            /* iPhone 5S */
            @"iPhone6,1" : @"iPhone 5S",
            @"iPhone6,2" : @"iPhone 5S",
            /* iPhone 6 */
            @"iPhone7,2" : @"iPhone 6",
            /* iPhone 6 Plus */
            @"iPhone7,1" : @"iPhone 6 Plus",
            /* iPhone 6s */
            @"iPhone8,1": @"iPhone 6s",
            /* iPhone 6s Plus */
            @"iPhone8,2": @"iPhone 6s Plus",
            /* iPhone SE */
            @"iPhone8,4" : @"iPhone SE",
            /* iPhone 7 */
            @"iPhone9,1" : @"iPhone 7",
            @"iPhone9,3" : @"iPhone 7",
            /* iPhone 7 Plus */
            @"iPhone9,2" : @"iPhone 7 Plus",
            @"iPhone9,4" : @"iPhone 7 Plus",
            /* iPhone 8 */
            @"iPhone10,1" : @"iPhone 8",
            @"iPhone10,3" : @"iPhone 8",
            /* iPhone 8 Plus */
            @"iPhone10,2" : @"iPhone 8 Plus",
            @"iPhone10,5" : @"iPhone 8 Plus",
            /* iPhone X */
            @"iPhone10,3" : @"iPhone X",
            @"iPhone10,6" : @"iPhone X",
            /* iPhone XR */
            @"iPhone11,8" : @"iPhone XR",
            /* iPhone XS */
            @"iPhone11,2" : @"iPhone XS",
            /* iPhone XS Max */
            @"iPhone11,6" : @"iPhone XS Max",
            @"iPhone11,4" : @"iPhone XS Max",
            
            /************ iPod touch ************/
            /* iPod touch */
            @"iPod4,1" : @"iPod Touch 4G",
            @"iPod5,1" : @"iPod Touch 5G",
            @"iPod7,1" : @"iPod touch 6G",
            @"iPod9,1" : @"iPod touch 7G",
            
            /************ Simulator ************/
            /* Simulator */
            @"x86_64" : @"Simulator",
            @"i386" : @"Simulator"
        };
    });
    
    struct utsname systemInfo;
    uname(&systemInfo);
    
    char *machine = systemInfo.machine;
    NSString *key = [NSString stringWithCString:machine encoding:NSUTF8StringEncoding];
    NSString *model = [dictModels objectForKey:key];
    if (!model) {
        BXLogWarn(@"未获取到该设备类型, 请及时更新!");
        model = [[UIDevice currentDevice] localizedModel];
    }
    return model;
}

+ (NSString *)deviceIFA {
    NSString *ifa = nil;
    ifa = [[[ASIdentifierManager sharedManager] advertisingIdentifier] UUIDString];
    return ifa;
}

+ (NSString *)deviceUniqueId {
    NSMutableDictionary *searchDict = [[NSMutableDictionary alloc]initWithCapacity:4];
    [searchDict setObject:@"com.bxmobilesdk" forKey:(__bridge id)kSecAttrService];
    [searchDict setObject:@"UUID" forKey:(__bridge id)kSecAttrAccount];
    [searchDict setObject:(__bridge id)kSecClassGenericPassword forKey:(__bridge id)kSecClass];
    [searchDict setObject:@YES forKey:(__bridge id)kSecReturnData];
    
    NSString * uuid = NULL;
    CFTypeRef result = NULL;
    OSStatus status = SecItemCopyMatching((__bridge CFDictionaryRef)searchDict, &result);
    if (status == errSecItemNotFound) {
        if ([[UIDevice currentDevice].systemVersion floatValue] >= 7.0) {
            if (![[[[ASIdentifierManager sharedManager] advertisingIdentifier] UUIDString] isEqualToString:@"00000000-0000-0000-0000-000000000000"])
            {
                uuid = [[[ASIdentifierManager sharedManager] advertisingIdentifier] UUIDString];
            }
        }
        
        if (uuid == NULL || [uuid isEqualToString:@""]) {
            uuid =  [[[UIDevice currentDevice] identifierForVendor] UUIDString];
        }
        NSData *uuidData = [uuid dataUsingEncoding:NSUTF8StringEncoding];
        [searchDict setObject:uuidData forKey:(__bridge id)kSecValueData];
        status = SecItemAdd((__bridge CFDictionaryRef)searchDict, NULL);
    }else if (status == errSecSuccess){
        uuid = [[NSString alloc] initWithData:(__bridge_transfer NSData *)result encoding:NSUTF8StringEncoding];
    }
    return uuid;
}

+ (NSString *)telephonyCarrierName {
    static NSString * _carrierName = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        CTTelephonyNetworkInfo *info = [[CTTelephonyNetworkInfo alloc] init];
        CTCarrier *carrier = info.subscriberCellularProvider;
        NSLog(@"运营商: %@", carrier.carrierName);
        _carrierName = carrier.carrierName;
    });
    return _carrierName;
}

@end
