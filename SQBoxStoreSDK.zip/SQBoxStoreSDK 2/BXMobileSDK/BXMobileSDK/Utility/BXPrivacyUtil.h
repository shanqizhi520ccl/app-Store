//
//  BXThreeSelectionController.m
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/8/23.
//  Copyright © 2021 Gavin. All rights reserved.
//

#import <Foundation/Foundation.h>
@class BXProgressHUD;

NS_ASSUME_NONNULL_BEGIN

@interface BXPrivacyUtil : NSObject

+ (BOOL)isStringAndAvail:(NSString *)value ;

+ (NSString *)stringForResValue:(NSString *)value ;

+ (BOOL)stringIsdigit:(NSString *)string ;

+ (void)bx_exitApplication;

+ (UIViewController *)bx_currentController;

+ (UIViewController *)bx_currentPresentestController;

+(void)bx_alertActionWithTitle:(NSString *)title message:(NSString *)message handler:(void (^ __nullable)(UIAlertAction *action))handler cancelHandler:(void (^ __nullable)(UIAlertAction *action))cancelHandler;

/// 是否需要弹出手机设备收集信息弹窗
+(BOOL)bx_isNeedShowbx_devicePrivacy;

/// 允许手机设备收集信息
+(void)bx_allowbx_devicePrivacy;

/// 是否需要弹出手机是否允许发送验证码
+(BOOL)bx_isNeedShowSendMsgCodePrivacy;

/// 允许发送验证码
+(void)bx_allowDeviceSendMsgCode;

/// 允许发送验证码(临时)
+(void)bx_allowDeviceSendMsgCodeTemporary;

/// 重置临时验证码允许
+(void)bx_resetTemporaryMsgAllow;

#pragma mark -- string

+ (NSString *)privacyWebUrl;
+ (NSString *)bx_giftWebUrl;
+ (NSString *)bx_serviceWebUrl;
+ (NSString *)bx_deleteAccountUrl;
+ (NSString *)bx_getSignWithParams:(NSMutableDictionary *)params;
+ (void)bx_getSortUrlParams:(NSDictionary *)params urlEncode:(BOOL)urlEncode block:(void (^)(NSMutableString *params, NSMutableDictionary *willEncodeDic))block;
+ (NSString *)bx_encodeURL:(id)value;
/// 间隙
+ (NSMutableAttributedString *)bx_changeAttributedString:(NSString *)str;


#pragma mark -- layer
+ (CAGradientLayer *)bx_alertBackgroundGradient;


#pragma mark -- BXProgressHUD
+ (BXProgressHUD *)bx_toastMessage:(NSString * _Nullable)message title:(NSString * _Nullable)title view:(UIView *)view confirm:(NSString * _Nullable)confirm confirmBlock:(void (^ _Nullable)(void))confirmBlock;

+ (BXProgressHUD *)bx_toastMessage:(NSString * _Nullable)message title:(NSString * _Nullable)title view:(UIView *)view confirm:(NSString * _Nullable)confirm confirmBlock:(void (^ _Nullable)(void))confirmBlock cancel:(NSString * _Nullable)cancel cancelBLock:(void (^ _Nullable)(void))cancelBlock;

+ (BXProgressHUD *)bx_toastMessage:(NSString * _Nullable)message title:(NSString * _Nullable)title view:(UIView *)view;

+ (BXProgressHUD *)bx_toastMessage:(NSString * _Nullable)message title:(NSString * _Nullable)title view:(UIView *)view showCloseBtn:(BOOL)showCloseBtn hideToolsButtons:(BOOL)hideToolsButtons confirm:(NSString * _Nullable)confirm cancel:(NSString * _Nullable)cancel confirmBlock:( void (^ _Nullable )(void))confirmBlock cancelBLock:(void (^ _Nullable)(void))cancelBlock;


+(void)testMixFuncOne;

+(void)eruweioreuoriueiwofuiosruoiewru;

+(void)sdslkfjsdlkfjsdlfjskdfjskldjflslkdf;


@end

NS_ASSUME_NONNULL_END
