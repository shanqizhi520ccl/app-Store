/**
 * Copyright 2019 Gavin.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to
 * use, copy, modify, and distribute this software in source code or binary
 * form for use in connection with the web services and APIs provided by
 * Accela.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

#import "BXError.h"

static  NSString * const errorDomain = @"BXPalftormSDK";

@implementation BXError

- (NSString *)description {
    return self.localizedDescription;
}

+ (instancetype)errorWithCode:(NSInteger)errorCode{
    NSDictionary * info = nil;
    NSString *description = code2string(errorCode);
    if (description) {
        info = @{ NSLocalizedDescriptionKey:description };
    }
    
    BXError *error = [BXError errorWithDomain:errorDomain
                                         code:errorCode
                                     userInfo:info];
    return error;
}

+ (instancetype)errorWithCode:(NSInteger)code message:(NSString *)message {
    NSDictionary * info = nil;
    if (message) {
        info = @{ NSLocalizedDescriptionKey:message };
    }else {
        NSString *description = code2string(code);
        if (description) {
            info = @{ NSLocalizedDescriptionKey:description };
        }
    }
    
    BXError *error = [BXError errorWithDomain:errorDomain
                                         code:code
                                     userInfo:info];
    return error;
}

NSString *code2string(NSInteger code) {
    static NSMutableDictionary *errorMap = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        errorMap = [NSMutableDictionary dictionary];
        
        //***************************************************************
        // App 自定义错误  1 - 6
        [errorMap setObject:NSLocalizedString(@"网络请求失败", nil) forKey:@(BXErrorMetadataEmpty)];
        [errorMap setObject:NSLocalizedString(@"网络请求失败", nil) forKey:@(BXErrorInputIllegal)];
    });
    return [errorMap objectForKey:@(code)];
}

@end
