//
//  BXThreeSelectionController.m
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/8/23.
//  Copyright © 2021 Gavin. All rights reserved.
//

#import "BXPrivacyUtil.h"
#import <CommonCrypto/CommonDigest.h>
#import "BXConfig.h"
#import "BXMobileManager.h"
#import "BXDevice.h"
#import "BXUser.h"
#import "BXMobileManager+Private.h"
#import "BXPackage.h"
#import "BXProgressHUD.h"
#import "NSString+BXExtern.h"

@implementation BXPrivacyUtil

+ (BOOL)isStringAndAvail:(NSString *)value {
    return [value isKindOfClass:[NSString class]] && value.length > 0;
}

+ (NSString *)stringForResValue:(NSString *)value {
    if (value && [value isKindOfClass:[NSString class]] && value.length > 0) {
        return value;
    }
    return @"";
}

+ (BOOL)stringIsdigit:(NSString *)string {
    if (![self isStringAndAvail:string]) {
        return NO;
    }
    for (int i = 0; i < string.length; i++) {
        unichar s = [string characterAtIndex:i];
        if (!isdigit(s)) {
            return NO;
        }
    }
    return YES;
}


+ (void)bx_exitApplication {
    UIWindow *window = [UIApplication sharedApplication].delegate.window;
    [UIView animateWithDuration:1.0f animations:^{
        window.alpha = 0;
        window.frame = CGRectMake(0, window.bounds.size.width, 0, 0);
    } completion:^(BOOL finished) {
        exit(0);
    }];
}

+(void)bx_alertActionWithTitle:(NSString *)title message:(NSString *)message handler:(void (^ __nullable)(UIAlertAction *action))handler cancelHandler:(void (^ __nullable)(UIAlertAction *action))cancelHandler{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:handler];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:cancelHandler];
    [alertController addAction:cancelAction];
    [alertController addAction:okAction];
    [[self bx_currentPresentestController] presentViewController:alertController animated:NO completion:nil];
}

+ (UIViewController *)bx_currentController {
    UIViewController *result = nil;
    
    UIWindow *window = [[UIApplication sharedApplication] keyWindow];
    if (window.windowLevel != UIWindowLevelNormal) {
        NSArray *windows = [[UIApplication sharedApplication] windows];
        for (UIWindow *temp in windows) {
            if (temp.windowLevel == UIWindowLevelNormal) {
                window = temp;
                break;
            }
        }
    }
    //取当前展示的控制器
    result = window.rootViewController;
    while (result.presentedViewController) {
        result = result.presentedViewController;
    }
    //如果为UITabBarController：取选中控制器
    if ([result isKindOfClass:[UITabBarController class]]) {
        result = [(UITabBarController *)result selectedViewController];
    }
    //如果为UINavigationController：取可视控制器
    if ([result isKindOfClass:[UINavigationController class]]) {
        result = [(UINavigationController *)result visibleViewController];
    }
    return result;
}

+ (UIViewController *)bx_currentPresentestController
{
    UIViewController *result = [self bx_currentController];
    while (result.presentedViewController) {
        result = result.presentedViewController;
    }
    return result;
}

+(BOOL)bx_isNeedShowbx_devicePrivacy{
    
    if (![[NSUserDefaults standardUserDefaults] objectForKey:@"kParambx_devicePrivacy"]){
        return YES;
    }else{
        return NO;
    }
}

+(void)bx_allowbx_devicePrivacy{
    [[NSUserDefaults standardUserDefaults] setObject:@"1" forKey:@"kParambx_devicePrivacy"];
}

+(BOOL)bx_isNeedShowSendMsgCodePrivacy{
    if (![[NSUserDefaults standardUserDefaults] objectForKey:@"kParamSendMsgCodePrivacy"]){
        return YES;
    }else{
        NSString *str = [[NSUserDefaults standardUserDefaults] objectForKey:@"kParamSendMsgCodePrivacy"];
        if([str isEqualToString:@"2"]){
            return YES;
        }
        return NO;
    }
}

+(void)bx_allowDeviceSendMsgCode{
    [[NSUserDefaults standardUserDefaults] setObject:@"1" forKey:@"kParamSendMsgCodePrivacy"];
}


+(void)bx_allowDeviceSendMsgCodeTemporary{
    [[NSUserDefaults standardUserDefaults] setObject:@"2" forKey:@"kParamSendMsgCodePrivacy"];
}

+(void)bx_resetTemporaryMsgAllow{
    if ([[NSUserDefaults standardUserDefaults] objectForKey:@"kParamSendMsgCodePrivacy"]){
        NSString *str = [[NSUserDefaults standardUserDefaults] objectForKey:@"kParamSendMsgCodePrivacy"];
        if([str isEqualToString:@"2"]){
            [[NSUserDefaults standardUserDefaults] setObject:nil forKey:@"kParamSendMsgCodePrivacy"];
        }
    }
}

+ (NSString *)bx_giftWebUrl {
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    [dic addEntriesFromDictionary:[BXPackage publicParameters]];
    [dic addEntriesFromDictionary:[BXPackage proxyInfoDictionary]];
    [dic setValue:@1 forKey:@"antiVersion"];
    __block NSString *rp = @"";
    [self bx_getSortUrlParams:dic urlEncode:YES block:^(NSMutableString *urlParams, NSMutableDictionary *willEncodeDic) {
        rp = urlParams;
        rp = [urlParams substringToIndex:urlParams.length - 1];
    }];
    NSString *ad = [NSString stringWithFormat:@"%@%@?%@",  [BXConfig config].h5SdkUrl,@"gift/index",rp];
    return ad;
}

+ (NSString *)privacyWebUrl {
    NSMutableDictionary *params = [[NSMutableDictionary alloc]initWithDictionary:[BXPackage publicParameters]];
    params[@"userProtocolVersion"] = [BXConfig config].userProtocolVersion;
    params[@"userPrivateVersion"] = [BXConfig config].userPrivateVersion;
    params[@"userProtocolUpdate"] = [NSString stringWithFormat:@"%zd",[BXConfig config].userProtocolUpdate];
    params[@"userPrivateProtocolUpdate"] = [NSString stringWithFormat:@"%zd",[BXConfig config].userPrivateProtocolUpdate];
    params[@"localUserProtocolVersion"] = [BXConfig config].localUserProtocolVersion;
    params[@"localUserPrivateVersion"] = [BXConfig config].localUserPrivateVersion;
//    params[@"cdnServer"] = info.cdnServer;
    __block NSString *rp = @"";
    [self bx_getSortUrlParams:params urlEncode:YES block:^(NSMutableString *urlParams, NSMutableDictionary *willEncodeDic) {
        rp = urlParams;
        rp = [urlParams substringToIndex:urlParams.length - 1];// remove '&'
    }];
    NSString *privacyWebUrl = [NSString stringWithFormat:@"%@%@?%@",
                      [BXConfig config].h5SdkUrl,
                      @"RegistraDialog",
                      rp];
    return privacyWebUrl;
}

+ (NSString *)bx_serviceWebUrl {
    NSDictionary *dic = [BXPackage publicParameters];
    __block NSString *rp = @"";
    [self bx_getSortUrlParams:dic urlEncode:YES block:^(NSMutableString *urlParams, NSMutableDictionary *willEncodeDic) {
        rp = urlParams;
        rp = [urlParams substringToIndex:urlParams.length - 1];// remove '&'
    }];
    NSString *ad = [NSString stringWithFormat:@"%@%@?%@",  [BXConfig config].h5SdkUrl,@"service",rp];
    return ad;
}

+ (NSString *)bx_deleteAccountUrl {
    NSString *ad = [NSString stringWithFormat:@"%@%@", [BXConfig config].h5SdkUrl,@"5uwan/logoutId/index"];
    return ad;
}

+ (NSString *)bx_getSignWithParams:(NSMutableDictionary *)params {
    NSString *sign;
    __block NSMutableString *urlParams = [NSMutableString string];
    __block NSMutableDictionary *encodeDic = [NSMutableDictionary dictionary];
    
    [self bx_getSortUrlParams:params urlEncode:NO block:^(NSMutableString *params, NSMutableDictionary *willEncodeDic) {
        urlParams = params;
        encodeDic = willEncodeDic;
    }];
    
    NSString *tmp = [urlParams substringToIndex:urlParams.length - 1];// remove '&'
    sign = [tmp stringByAppendingString:[BXMobileManager shareManager].appKey];// AppKey
    NSString *md5Str = [self md5EncryptWithString:sign].lowercaseString;
    return md5Str;
}

+ (void)bx_getSortUrlParams:(NSDictionary *)params urlEncode:(BOOL)urlEncode block:(void (^)(NSMutableString *params, NSMutableDictionary *willEncodeDic))block {
    __block NSMutableString *urlParams = [NSMutableString string];
    
    NSArray *sorted = [params.allKeys sortedArrayUsingComparator:^NSComparisonResult(NSString *obj1, NSString *obj2) {
        return [obj1 compare:obj2];
    }];
    
    NSMutableDictionary *encodeDic = [NSMutableDictionary dictionary];
    [sorted enumerateObjectsUsingBlock:^(id  _Nonnull key, NSUInteger idx, BOOL * _Nonnull stop) {
        id value = params[key];
        encodeDic[key] = value;
        
        if([value isKindOfClass:[NSString class]]){
            if ([value length]>0) {
                NSString *encodeValue = [self bx_encodeURL:value];
                [urlParams appendFormat:@"%@=%@&", key, urlEncode ? encodeValue : value];
            }
        }else{
            NSString *encodeValue = [self bx_encodeURL:value];
            [urlParams appendFormat:@"%@=%@&", key, urlEncode ? encodeValue : value];
        }
    }];
    
    if (block) {
        block(urlParams, encodeDic);
    }
}

+ (NSString *)bx_encodeURL:(id)value {
    NSString *newValue = [NSString stringWithFormat:@"%@", value];
    return [newValue bx_urlEncode];
}

+ (NSString *)md5EncryptWithString:(NSString *)string
{
    const char *cStr = [string UTF8String];
    unsigned char digest[CC_MD5_DIGEST_LENGTH];
    
    CC_MD5(cStr, (CC_LONG)strlen(cStr), digest);
    
    NSMutableString *result = [NSMutableString stringWithCapacity:CC_MD5_DIGEST_LENGTH * 2];
    for (int i = 0; i < CC_MD5_DIGEST_LENGTH; i++) {
        [result appendFormat:@"%02X", digest[i]];
    }
    
    return result;
}

+ (NSMutableAttributedString *)bx_changeAttributedString:(NSString *)str{
    if (str == nil || [str isEqualToString:@""]) {
        return [[NSMutableAttributedString alloc]initWithString:@""];
    }
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:str];
    
    [attributedString addAttribute:NSKernAttributeName value:@(1.2) range:NSMakeRange(0, str.length)];
    
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    
    [paragraphStyle setLineSpacing:3];
    
    [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [str length])];
    
    return  attributedString;;
}

#pragma mark -- layer

+ (CAGradientLayer *)bx_alertBackgroundGradient {
    CAGradientLayer *gradient = [CAGradientLayer layer];
    gradient.colors = @[(__bridge id)BXHexAColor(0x24252E, .95).CGColor,
                        (__bridge id)BXHexAColor(0x2E2727, .95).CGColor,
                        ];
    gradient.locations = @[@(0.0), @(1.0)];
    gradient.startPoint = CGPointMake(0, 0);
    gradient.endPoint = CGPointMake(0, 1);
    gradient.cornerRadius = 4;
    gradient.name = @"bxm_alertBackgroundGradient";
    return gradient;
}

#pragma mark -- BXProgressHUD
+ (BXProgressHUD *)bx_toastMessage:(NSString * _Nullable)message title:(NSString * _Nullable)title view:(UIView *)view confirm:(NSString *)confirm confirmBlock:(void (^)(void))confirmBlock
{
    return [self bx_toastMessage:message title:title view:view confirm:confirm confirmBlock:confirmBlock cancel:nil cancelBLock:nil];
}

+ (BXProgressHUD *)bx_toastMessage:(NSString * _Nullable)message title:(NSString * _Nullable)title view:(UIView *)view confirm:(NSString * _Nullable)confirm confirmBlock:(void (^)(void))confirmBlock cancel:(NSString * _Nullable)cancel cancelBLock:(void (^ _Nullable)(void))cancelBlock
{
    return [self bx_toastMessage:message title:title view:view showCloseBtn:NO hideToolsButtons:NO confirm:confirm cancel:cancel confirmBlock:confirmBlock cancelBLock:cancelBlock];
}

+ (BXProgressHUD *)bx_toastMessage:(NSString * _Nullable)message title:(NSString * _Nullable)title view:(UIView *)view
{
    return [self bx_toastMessage:message title:title view:view showCloseBtn:YES hideToolsButtons:YES confirm:nil cancel:nil confirmBlock:nil cancelBLock:nil];
}

+ (BXProgressHUD *)bx_toastMessage:(NSString * _Nullable)message title:(NSString * _Nullable)title view:(UIView *)view showCloseBtn:(BOOL)showCloseBtn hideToolsButtons:(BOOL)hideToolsButtons confirm:(NSString * _Nullable)confirm cancel:(NSString * _Nullable)cancel confirmBlock:(void (^ _Nullable)(void))confirmBlock cancelBLock:(void (^ _Nullable)(void))cancelBlock
{
    BXProgressHUD *hud = [[BXProgressHUD alloc] initWithView:view];
    hud.label.text = title;
    hud.detailsLabel.text = message;
    [hud.confirmBtn setTitle:confirm forState:(UIControlStateNormal)];
    [hud.cancelBtn setTitle:cancel forState:(UIControlStateNormal)];
    hud.confirmBlock = confirmBlock;
    hud.cancelBlock = cancelBlock;
    hud.showCloseBtn = showCloseBtn;
    hud.hideToolsButtons = hideToolsButtons;
    
    [hud showAnimated:YES];
    return hud;
}

+(void)testMixFuncOne{
    NSLog(@"testMixFuncOne");
}

+(void)eruweioreuoriueiwofuiosruoiewru{
    NSLog(@"eruweioreuoriueiwofuiosruoiewru");
}

+(void)sdslkfjsdlkfjsdlfjskdfjskldjflslkdf{
    NSLog(@"sdslkfjsdlkfjsdlfjskdfjskldjflslkdf");
}

@end
