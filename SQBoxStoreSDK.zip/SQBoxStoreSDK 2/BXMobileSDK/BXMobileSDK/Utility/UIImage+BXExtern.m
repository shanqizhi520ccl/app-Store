//
//  UIImage+BXExtern.m
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/24.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "UIImage+BXExtern.h"

@implementation UIImage (BXExtern)

+ (UIImage *)bx_imageWithColor:(UIColor*)color
{
    return [UIImage bx_imageWithColor:color frame:CGRectMake(0, 0, 1, 1)];
}

+ (UIImage *)bx_imageWithColor:(UIColor*)color frame:(CGRect)frame
{
    return [UIImage bx_imageWithColor:color alpha:1 frame:frame];
}

+ (UIImage *)bx_imageWithColor:(UIColor*)color alpha:(CGFloat)alpha frame:(CGRect)frame
{
    CGRect rect = frame;
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetFillColorWithColor(context, color.CGColor);
    CGContextSetAlpha(context, alpha);
    CGContextFillRect(context, rect);
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return image;
}

+ (UIImage *)bx_bundleImageWithName:(NSString *)imageName {
    UIImage *image = [UIImage imageNamed:imageName inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
    return [image imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
}

+(UIImage *)resizableImageWithName:(NSString *)imageName{
    UIImage *image = [UIImage imageNamed:imageName];
    CGFloat left = image.size.width * 0.2;
    UIEdgeInsets edgeInsets = UIEdgeInsetsMake(0, left, 0, 0);
    UIImageResizingMode mode = UIImageResizingModeStretch;
    UIImage *newImage = [image resizableImageWithCapInsets:edgeInsets resizingMode:mode];
    return newImage;
}

@end
