//
//  asdadViewController.h
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/9/1.
//  Copyright © 2021 Gavin. All rights reserved.
//


#import "BXAddHeartbeatManager.h"

NS_ASSUME_NONNULL_BEGIN

@interface BXAddHeartbeatManager (KickOffline)
/// 强踢和普踢逻辑
- (void)bx_processKickOffWithSuccessResponse:(NSDictionary *)response;

/// 实名认证后，但是未成年人且处于限制登录时间，限制进入游戏
- (void)bx_processAntiAuthRealNameResponse:(NSDictionary *)response;
@end

NS_ASSUME_NONNULL_END
