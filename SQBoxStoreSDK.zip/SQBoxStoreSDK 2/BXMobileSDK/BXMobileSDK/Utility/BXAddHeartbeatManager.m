//
//  asdadViewController.h
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/9/1.
//  Copyright © 2021 Gavin. All rights reserved.
//


#import "BXAddHeartbeatManager.h"
#import "BXMobileManager.h"
#import "BXMobileManager+Private.h"
#import "BXConfig.h"
#import "BXEvent.h"
#import "BXPrivacyUtil.h"
#import "BXIdAuthViewController.h"
#import "BXAddHeartbeatManager+KickOffline.h"
#import "BXProgressHUD.h"

@interface BXAddHeartbeatManager ()

@property(strong, nonatomic) NSTimer *timer;

@property(strong, nonatomic) NSTimer *quitTimer;

@property (strong, nonatomic) NSString *quitMsg;

@property (nonatomic, assign) int quitTime;

@property(strong, nonatomic) NSTimer *antiAddictionTimer;

@property (strong, nonatomic) UIAlertAction *okAction;

@property (strong, nonatomic) BXProgressHUD *hud;

@end

@implementation BXAddHeartbeatManager

+ (nonnull instancetype)sharedInstance {
    static BXAddHeartbeatManager *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (instance == nil) {
            instance = [[BXAddHeartbeatManager alloc] init];
        }
    });
    return instance;
}

- (void)start {
    [self stop];
    
    [self adultProcess];
    
    [self heartProcess];
}

- (void)stop {
    if (self.timer) {
        [self.timer invalidate];
        self.timer = nil;
    }
    
    [self bx_stopAntiAddictionTimer];
    [self stopQuitTime];
}

- (void)startAntiAddictionTimer {
    [self bx_stopAntiAddictionTimer];
    
    self.antiAddictionTimer = [NSTimer scheduledTimerWithTimeInterval:5 * 60 target:self selector:@selector(antiAddictionAction) userInfo:nil repeats:NO];
}

- (void)bx_stopAntiAddictionTimer {
    if (self.antiAddictionTimer) {
        [self.antiAddictionTimer invalidate];
        self.antiAddictionTimer = nil;
    }
}

- (void)startQuitTime {
    [self stopQuitTime];
    
    self.quitTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(quitTimerAction) userInfo:nil repeats:YES];
}

- (void)stopQuitTime {
    if (self.quitTimer) {
        [self.quitTimer invalidate];
        self.quitTimer = nil;
    }
}

#pragma mark - Action
- (void)timerAction {
    __weak typeof(self) weakSelf = self;
    [BXEvent doHeartBeatResultComplement:^(id obj, NSError *error) {
        if (!error) {
            NSString *type = [obj[@"antiAddictionType"] description];
            NSString *msg = [obj[@"antiAddictionMsg"] description];
            NSString *must = [obj[@"antiAddictionMust"] description];
            dispatch_async(dispatch_get_main_queue(), ^{
                if ([type isEqualToString:@"1"]) {
                    [BXMBProgressHUD bx_showMessage:msg];
                } else if ([type isEqualToString:@"2"]) {
                    weakSelf.quitTime = 5;
                    weakSelf.quitMsg = msg;
                    [weakSelf stop];
                    [weakSelf showMessage:msg];
                    [weakSelf startQuitTime];
                } else if ([type isEqualToString:@"3"]) {
                    BXIdAuthViewController *bx_idAuthController = [[BXIdAuthViewController alloc] init];
                    bx_idAuthController.isLimit = [must isEqualToString:@"1"];
                    [[BXPrivacyUtil bx_currentController] presentViewController:bx_idAuthController animated:YES completion:nil];
                    bx_idAuthController.dismissBlock = ^(BOOL isAuditLimit, NSDictionary *result) {
                        if (isAuditLimit) {
                            [weakSelf bx_processAntiAuthRealNameResponse:result];
                        }
                    };
                }
            });
            
            [self bx_processKickOffWithSuccessResponse:obj];
        }else{
            
        }
    }];
}

//- (void)quitTimerAction {
//    NSString *msg1 = [NSString stringWithFormat:@"%@(%d)", @"退出", self.quitTime];
//    self.quitTime--;
//
//    if (self.quitTime == 0) {
//        [BXPrivacyUtil bx_exitApplication];
//    }
//
//    NSString *msg = [NSString stringWithFormat:@"%@(%d)", @"退出", self.quitTime];
//    [self.okAction.title setValue:msg1 forKey:msg];
//}
- (void)quitTimerAction {
    self.quitTime--;
    
    if (self.quitTime == 0) {
        [BXPrivacyUtil bx_exitApplication];
    }
    
    NSString *msg = [NSString stringWithFormat:@"%@(%d)", @"退出", self.quitTime];
    [self.hud.confirmBtn setTitle:msg forState:UIControlStateNormal];
}

- (void)antiAddictionAction {
    if (![[BXConfig config].antiAddictionSwitch boolValue]) {
        return;
    }
    if ([BXMobileManager shareManager].currentUser.adultState == 0) {
        return ;
    }
    [BXMBProgressHUD bx_showMessage:@"您的账号尚未实名认证，将会被纳入防沉迷系统，累计在线满一定时间会被强制下线喔，请尽快在悬浮窗中进行实名认证~"];
}

#pragma mark - Private

//- (void)showMessage:(NSString *)message
//{
//    __weak typeof(self) weakSelf = self;
//    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"" message:message preferredStyle:UIAlertControllerStyleAlert];
//    UIAlertAction *okAction = [UIAlertAction actionWithTitle:[NSString stringWithFormat:@"%@(%d)", @"退出", self.quitTime] style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
//        [BXPrivacyUtil bx_exitApplication];
//    }];
//    self.okAction = okAction;
//
//    [alertController addAction:okAction];
//    [[BXPrivacyUtil bx_currentPresentestController] presentViewController:alertController animated:NO completion:nil];
//}

- (void)showMessage:(NSString *)message
{
    UIView *view = [BXPrivacyUtil bx_currentPresentestController].view;
    NSString *msg = [NSString stringWithFormat:@"%@(%d)", @"退出", self.quitTime];
    BXProgressHUD *hud =[BXPrivacyUtil bx_toastMessage:message title:nil view:view confirm:msg confirmBlock:^{
        [BXPrivacyUtil bx_exitApplication];
    }];
    self.hud = hud;
}

/**
 判断是否需要每五分钟弹一次实名认证hud提示
 */
- (void)adultProcess {
    if (![[BXConfig config].antiAddictionSwitch boolValue]) {
        return;
    }
    if ([BXMobileManager shareManager].currentUser.adultState == 0) {
        return ;
    }
    
    [self startAntiAddictionTimer];
}

- (void)heartProcess {
    if ([BXConfig config].heartBeatInterval < 1) {
        return;
    }
    
    [self timerAction];
    self.timer = [NSTimer scheduledTimerWithTimeInterval:[BXConfig config].heartBeatInterval target:self selector:@selector(timerAction) userInfo:nil repeats:YES];
}

@end
