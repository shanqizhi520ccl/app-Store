//
//  BXHelper.m
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/14.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXHelper.h"

@implementation BXHelper

#pragma mark - Check Methods

+ (NSString *)getBundleIdentifier {
    return [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleIdentifier"];
}

+ (NSString *)getBundleVersion {
    return [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleVersion"];
}

+ (NSString *)getBundleShortVersionString {
    return [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
}

+ (NSDictionary *)paltformInfoDictionary {
    static NSDictionary *_bx_platformDictionary = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        NSString *path = [BXMobileSDKBundle pathForResource:@"PlatformConfig" ofType:@"plist"];
        NSDictionary *dict =  [[NSDictionary alloc] initWithContentsOfFile:path];
        _bx_platformDictionary = dict;
        BXLogInfo(@"load platform info: %@", _bx_platformDictionary);
    });
    return _bx_platformDictionary;
}

+ (NSDictionary *)versionInfoDictionary {
    static NSDictionary *_bx_versionInfoDictionary = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        NSString *path = [BXMobileSDKBundle pathForResource:@"version" ofType:@"json"];
        NSData *data = [[NSData alloc] initWithContentsOfFile:path];
        _bx_versionInfoDictionary = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
        BXLogInfo(@"load sdk version: %@", _bx_versionInfoDictionary);
    });
    return _bx_versionInfoDictionary;
}

@end
