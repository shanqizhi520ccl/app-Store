//
//  BXDevice.h
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/2.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BXDevice : NSObject

/**
 *    @brief    获取设备IDFV
 *
 *    @return    idfv uuid string eg: “xxxx-xxxx-xxxx-xxxx”
 *
 *    Created by Jamie on 2017-08-28 10:27
 */
+ (NSString *)deviceIDFV;

/**
 *    @brief    获取设备名称
 *
 *    @return    设备名称 eg: “xxx的iPhone”
 *
 *    Created by Jamie on 2017-08-28 10:28
 */
+ (NSString *)deviceName;

/**
 *    @brief    获取系统名称
 *
 *    @return    系统名称 eg:iOS
 *
 *    Created by Jamie on 2017-08-28 15:42
 */
+ (NSString *)systemName;

/**
 *    @brief    获取系统版本
 *
 *    @return    系统版本 eg:10.3
 *
 *    Created by Jamie on 2017-08-28 15:43
 */
+ (NSString *)systemVerson;

/**
 *    @brief    获取设备类型
 *
 *    @return    设备类型 eg: iPhone
 *
 *    Created by Jamie on 2017-08-28 15:43
 */
+ (NSString *)systemModel;

/**
 *    @brief    获取设备类型 (更新至2019/10/23)
 *
 *    @return    设备类型 eg: "iPhone 7"
 *
 *    Created by Jamie on 2019-10-23 10:30
 */
+ (NSString *)systemInfo;

/**
 *    @brief    获取设备IDFA
 *
 *    @return   idfa uuid string eg: “xxxx-xxxx-xxxx-xxxx”
 *
 *    Created by Jamie on 2018-06-05 11:46
 */
+ (NSString *)deviceIFA;

/**
*    @brief    获取设备UUID
*
*    @return   device uuid string eg: “xxxx-xxxx-xxxx-xxxx”
*
*    Created by Jamie on 2018-06-05 11:46
*/
+ (NSString *)deviceUniqueId;

/**
*    @brief    获取手机运营商
*
*    @return   telephony carrier string eg: “中国电信”
*
*    Created by Jamie on 2018-06-05 11:46
*/
+ (NSString *)telephonyCarrierName ;

@end

