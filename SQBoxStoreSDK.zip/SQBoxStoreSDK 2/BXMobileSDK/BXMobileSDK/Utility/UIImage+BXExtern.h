//
//  UIImage+BXExtern.h
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/24.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIImage (BXExtern)
//image with color
+ (UIImage *)bx_imageWithColor:(UIColor*)color;
//image with color and frame
+ (UIImage *)bx_imageWithColor:(UIColor*)color frame:(CGRect)frame;
//image with color, alpha and frame
+ (UIImage *)bx_imageWithColor:(UIColor*)color alpha:(CGFloat)alpha frame:(CGRect)frame;
//image in bundle with name
+ (UIImage *)bx_bundleImageWithName:(NSString *)imageName;
//拉伸图片
+ (UIImage *)resizableImageWithName:(NSString *)imageName;
@end

NS_ASSUME_NONNULL_END
