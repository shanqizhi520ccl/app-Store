//
//  BXMBProgressHUD+BXExtern.m
//  BXMobileSDK
//
//  Created by Rolata Kasahawa on 2020/1/10.
//  Copyright © 2020 Rolata Kasahawa. All rights reserved.
//

#import "BXMBProgressHUD+BXExtern.h"

#define BXHUDHideAfterInterval       1.5
#define BXHUDBackgroudColor          [UIColor colorWithWhite:0.f alpha:0.6f]
#define BXHUDBezelViewColor          [UIColor colorWithRed:29.0f/255.0f green:32.0f/255.0f blue:35.0f/255.0f alpha:1]
#define BXHUDBezelViewStlye          BXMBProgressHUDBackgroundStyleSolidColor
#define BXHUDContentColor            [UIColor whiteColor]
#define BXHUDLabelTextColor          [UIColor whiteColor]
#define BXHUDLabelTextFont           [UIFont systemFontOfSize:13]
#define BXHUDDetailsLabelTextColor   [UIColor whiteColor]
#define BXHUDDetailsLabelFont        [UIFont systemFontOfSize:12]
#define BXHUDMargin                  15
#define BXHUDBezelViewBottomMargin   88.0f

@implementation BXMBProgressHUD (BXExtern)

#ifdef DEBUG
- (void)dealloc
{
    BXLogDebug(@"dealloc");
}
#endif

+ (instancetype)bx_showHUDAddedTo:(UIView *)view animated:(BOOL)animated {
    if (view == nil) view = [[UIApplication sharedApplication].windows lastObject];
    
    BXMBProgressHUD *hud = [BXMBProgressHUD showHUDAddedTo:view animated:YES];
    hud.contentColor = BXHUDContentColor;
    hud.bezelView.color = BXHUDBezelViewColor;
    hud.bezelView.style = BXHUDBezelViewStlye;
    hud.label.textColor = BXHUDLabelTextColor;
    hud.label.font = BXHUDLabelTextFont;
    hud.detailsLabel.textColor = BXHUDDetailsLabelTextColor;
    hud.detailsLabel.font = BXHUDDetailsLabelFont;
    hud.margin = BXHUDMargin;
    hud.defaultMotionEffectsEnabled = NO;
    hud.removeFromSuperViewOnHide = YES;
    
    return hud;
}

+ (instancetype)bx_showHUDAddedTo:(UIView *)view message:(NSString *)message customView:(UIView *)customView {
    BXMBProgressHUD *hud = [self bx_showHUDAddedTo:view animated:YES];
    
    if (message) {
        hud.label.text = message;
    }
    
    if (customView) {
        hud.contentColor = [UIColor whiteColor];
        hud.bezelView.color = [UIColor whiteColor];
        hud.mode = BXMBProgressHUDModeCustomView;
        hud.customView = customView;
    }
    
    return hud;
}

#pragma mark - 默认风格

+ (instancetype)bx_showIndicator:(NSString *)message inView:(UIView *)inView {
    return [self bx_showHUDAddedTo:inView message:message customView:nil];
}

+ (instancetype)bx_showIndicator:(NSString *)message {
    return [self bx_showIndicator:message inView:nil];
}


+ (instancetype)bx_showMessage:(NSString *)message inView:(UIView *)inView {
    BXMBProgressHUD *hud = [self bx_showHUDAddedTo:inView message:message customView:nil];
    hud.mode = BXMBProgressHUDModeText;
    hud.label.numberOfLines = 0;
    
    /*
     // 设置offset - 自定义边距（离底部88）
     CGFloat labelWidth = hud.frame.size.width - (hud.margin*2) - hud.layoutMargins.left - hud.layoutMargins.right;
     CGRect textRect = [hud.label.text boundingRectWithSize:CGSizeMake(labelWidth, MAXFLOAT)
     options:NSStringDrawingUsesLineFragmentOrigin
     attributes:@{NSFontAttributeName: hud.label.font}
     context:nil];
     CGFloat maxOffset = ( hud.frame.size.height- textRect.size.height ) / 2.0;
     CGFloat targetOffset = maxOffset - BXHUDBezelViewBottomMargin;
     hud.offset = CGPointMake(0.f, targetOffset);
     */
    
    return hud;
}

+ (void)bx_showMessage:(NSString *)message {
    dispatch_async(dispatch_get_main_queue(), ^{
        BXMBProgressHUD *hud = [self bx_showMessage:message inView:nil];
        [hud hideAnimated:YES afterDelay:BXHUDHideAfterInterval];
    });
}

+ (void)bx_showMessage:(NSString *)message delay:(BOOL)delay {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.25 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        BXMBProgressHUD *hud = [self bx_showMessage:message inView:nil];
        [hud hideAnimated:YES afterDelay:BXHUDHideAfterInterval];
    });
}

#pragma mark - Hide Methods

+ (void)bx_hideHUDForView:(UIView *)view
{
    if (view == nil) view = [[UIApplication sharedApplication].windows lastObject];
    dispatch_async(dispatch_get_main_queue(), ^{
        [self hideHUDForView:view animated:YES];
    });
}

+ (void)bx_hideHUD
{
    [self bx_hideHUDForView:nil];
}

- (void)bx_hide {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self hideAnimated:YES];
    });
}

@end
