//
//  NSDictionary+BXMobileSDK.h
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/10.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSDictionary (BXMobileSDK)

//从当前字典获取dictionary，如果不是NSDictionary则返回nil
- (nullable NSDictionary *)dictionaryForKey:(NSString *)key;

//从当前字典获取array，如果不是NSArray则返回nil
- (nullable NSArray *)arrayForKey:(NSString *)key;

//从当前字典获取number，如果不是NSNumber则返回nil
- (nullable NSNumber *)numberForKey:(NSString *)key;

//从当前字典获取string，如果不是NSString则返回nil
- (nullable NSString *)stringForKey:(NSString *)key;

//从当前字典获取number，如果不是NSNumber则尝试转换为NSNumber，若失败则返回nil
- (nullable NSString *)safetyStringForKey:(NSString *)key;

//从当前字典获取number，如果不是NSNumber则尝试转换为NSNumber，若失败则返回nil
- (nullable NSNumber *)safetyNumberForKey:(NSString *)key;

@end

NS_ASSUME_NONNULL_END
