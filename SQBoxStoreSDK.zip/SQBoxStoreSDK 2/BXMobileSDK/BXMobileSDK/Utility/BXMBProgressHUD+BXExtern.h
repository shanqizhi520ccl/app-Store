//
//  BXMBProgressHUD+BXExtern.h
//  BXMobileSDK
//
//  Created by Rolata Kasahawa on 2020/1/10.
//  Copyright © 2020 Rolata Kasahawa. All rights reserved.
//

#import "BXMBProgressHUD.h"

//NS_ASSUME_NONNULL_BEGIN


@interface BXMBProgressHUD (BXExtern)

/// 自定义风格 HUD
+ (instancetype)bx_showHUDAddedTo:(UIView *)view animated:(BOOL)animated;
/// 文本+菊花 HUD
+ (instancetype)bx_showIndicator:(NSString *)message inView:(UIView *)inView;
/// 文本+菊花 HUD
+ (instancetype)bx_showIndicator:(NSString *)message;
/// 文本 HUD
+ (instancetype)bx_showMessage:(NSString *)message inView:(UIView *)inView;
/// 文本 HUD (N秒自动消失)
+ (void)bx_showMessage:(NSString *)message;
+ (void)bx_showMessage:(NSString *)message delay:(BOOL)delay;
/// 隐藏HUD
+ (void)bx_hideHUDForView:(UIView *)view;
/// 隐藏HUD
+ (void)bx_hideHUD;
/// 隐藏HUD
- (void)bx_hide;

@end

//NS_ASSUME_NONNULL_END
