//
//  NSDictionary+BXMobileSDK.m
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/10.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "NSDictionary+BXMobileSDK.h"

@implementation NSDictionary (BXMobileSDK)

- (NSDictionary *)dictionaryForKey:(NSString *)key {
    id dictionary = self[key];
    if ([dictionary isKindOfClass:[NSDictionary class]])
    {
        return dictionary;
    }
    
    return nil;
}

- (NSArray *)arrayForKey:(NSString *)key
{
    id array = self[key];
    if ([array isKindOfClass:[NSArray class]])
    {
        return array;
    }
    
    return nil;
}

- (NSNumber *)numberForKey:(NSString *)key
{
    id number = self[key];
    if ([number isKindOfClass:[NSNumber class]])
    {
        return number;
    }
    
    return nil;
}

- (NSString *)stringForKey:(NSString *)key
{
    id string = self[key];
    if ([string isKindOfClass:[NSString class]])
    {
        return string;
    }
    
    return nil;
}

- (NSString *)safetyStringForKey:(NSString *)key {
    id vaule = [self valueForKey:key];
    if ([vaule isKindOfClass:[NSString class]]) {
        return (NSString*)vaule;
    } else if ([vaule isKindOfClass:[NSNumber class]]) {
        return ((NSNumber*)vaule).description;
    }
    return nil;
}

- (NSNumber *)safetyNumberForKey:(NSString *)key {
    id vaule = [self valueForKey:key];
    if ([vaule isKindOfClass:[NSString class]]) {
        return @([((NSString*)vaule) doubleValue]);
    } else if ([vaule isKindOfClass:[NSNumber class]]) {
        return (NSNumber*)vaule;
    }
    return nil;
}

@end
