//
//  BXBaseViewController.h
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/20.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BXTextField.h"
#import "PureLayout.h"
#import "BXMBProgressHUD+BXExtern.h"
#import "UIImage+BXExtern.h"
#import "NSString+BXExtern.h"
#import "BXHeaderView.h"

//NS_ASSUME_NONNULL_BEGIN

@interface BXBaseViewController : UIViewController

@property(strong, nonatomic) UIImageView *bx_baseframeView;

@property(strong, nonatomic) BXHeaderView *bx_baseHeaderView;

@property(strong, nonatomic) UIImageView *bx_baseBackView;

@property (strong, nonatomic) UIButton *bx_baseNextBtn;

- (void)bx_presentWithViewController:(UIViewController *)presentingViewController;
- (void)bx_hideWithCompletion:(void(^)(void))completion;
- (void)bx_dismissPresentedViewController:(UIViewController *)vc completionBlock:(void(^)(void))completionBlock;

- (BOOL)orientationStatus;
@end

//NS_ASSUME_NONNULL_END
