//
//  YYAccountListView.m
//  YYPalftormSDK
//
//  Created by Rolata Kasahawa on 2019/10/25.
//  Copyright © 2020 YY Tech Inc. All rights reserved.
//

#import "BXSelectorControll.h"
#import "PureLayout.h"
#import "BXUser.h"

@interface BXSelectorCell : UITableViewCell
@property (nonatomic, strong) UIImageView *iconImageView;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *subTitleLabel;
@property (nonatomic, strong) UIButton *accessoryButton;
@property (nonatomic, assign) BOOL bx_didSetupConstraintsCell;
@property (nonatomic) UITableViewCellStyle aCellStyle;
@end

@implementation BXSelectorCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.backgroundColor = BXTextFieldBackgroundColor;
        self.backgroundView = nil;
        self.selectedBackgroundView = nil;
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    
        [self addSubview:self.titleLabel];
        [self addSubview:self.subTitleLabel];
        [self addSubview:self.iconImageView];
        
        self.accessoryView = self.accessoryButton;
        
        [self updateConstraintsIfNeeded];
    }
    return self;
}

- (void)updateConstraints {
    if (!_bx_didSetupConstraintsCell) {
        [self.titleLabel autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
        [self.titleLabel autoPinEdgeToSuperviewMargin:ALEdgeLeading];
        
        [self.subTitleLabel autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
        [self.subTitleLabel autoPinEdge:ALEdgeLeading toEdge:ALEdgeTrailing ofView:self.titleLabel withOffset:5];
        
        [self.iconImageView autoSetDimensionsToSize:CGSizeMake(25, 25)];
        [self.iconImageView autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
        [self.iconImageView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:45];
        
        _bx_didSetupConstraintsCell = YES;
    }
    [super updateConstraints];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (UILabel *)titleLabel {
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc] init];
        _titleLabel.font = BXSystemFont(12);
        _titleLabel.textColor = BXHexColor(0x666666);
    }
    return _titleLabel;
}

- (UILabel *)subTitleLabel {
    if (!_subTitleLabel) {
        _subTitleLabel = [[UILabel alloc] init];
        _subTitleLabel.font = BXSystemFont(10);
        _subTitleLabel.textColor = BXHexColor(0x388EFF);
    }
    return _subTitleLabel;
}

- (UIButton *)accessoryButton {
    if (!_accessoryButton) {
        _accessoryButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _accessoryButton.frame = CGRectMake(0, 0, 21, 21);
        UIImage *image = [UIImage imageNamed:@"cell_delete" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
        [_accessoryButton setImage:image forState:UIControlStateNormal];
    }
    return _accessoryButton;
}

- (UIImageView *)iconImageView{
    if (!_iconImageView) {
        _iconImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"tx-84" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil]];
    }
    return _iconImageView;
}

@end

#define kMaxNumberOfCell 10
#define kMaxCountForDisplayingCell 4

@interface BXSelectorControll ()<UITableViewDelegate, UITableViewDataSource>
@property (nonatomic, strong) NSMutableArray<NSString *> *arrayForTitles;
@property (nonatomic, strong) NSMutableDictionary *usersDict;
@property (nonatomic, strong) UITableView *aTableView;
@property (nonatomic, assign) BOOL bx_didSetupConstraints;
@end

@implementation BXSelectorControll

#ifdef DEBUG
- (void)dealloc
{
    BXLogDebug(@"dealloc");
}
#endif

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self setupViews];
        [self updateConstraintsIfNeeded];
    }
    return self;
}

- (instancetype)initWithDelegate:(id<BXSelectorControllDelegate>)delegate {
    self = [super init];
    if (self) {
        self.delegate = delegate;
        [self setupViews];
        [self updateConstraintsIfNeeded];
    }
    return self;
}

- (void)setDelegate:(id<BXSelectorControllDelegate>)delegate {
    _delegate = delegate;
}

- (void)setupViews {
    self.backgroundColor = BXTextFieldBackgroundColor;
    
    _aTableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
    self.aTableView.backgroundColor = [UIColor clearColor];
    self.aTableView.backgroundView = nil;
    self.aTableView.dataSource= self;
    self.aTableView.delegate = self;
    self.aTableView.estimatedRowHeight = 0;
    self.aTableView.estimatedSectionFooterHeight = 0;
    self.aTableView.estimatedSectionFooterHeight = 0;
    self.aTableView.sectionFooterHeight = 0;
    self.aTableView.sectionHeaderHeight = 0;
    self.aTableView.showsVerticalScrollIndicator = NO;
    self.aTableView.separatorColor = [UIColor whiteColor];
    self.aTableView.delaysContentTouches = NO;
    [self addSubview:self.aTableView];

    [self.aTableView registerClass:[BXSelectorCell class] forCellReuseIdentifier:@"BXSelectorCellIdentifier"];
}

- (void)updateConstraints {
    if (!_bx_didSetupConstraints) {
        [self.aTableView autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero];
        _bx_didSetupConstraints = YES;
    }
    [super updateConstraints];
}

- (void)reloadData {
    self.arrayForTitles = [[self.delegate titlesForRowsInSelectorView] mutableCopy];
    self.usersDict = [NSMutableDictionary dictionary];
    NSArray *allUsers = [[BXUser allUsers] mutableCopy];
    for (NSString *title in self.arrayForTitles) {
        for (BXUser *user in allUsers) {
            if ([user.userName isEqualToString:title]) {
                [self.usersDict setValue:user forKey:title];
            }
        }
    }
    
    [self.aTableView reloadData];
}

- (void)showing {
    [self reloadData];
    self.hidden = NO;
}
    
- (void)dismissing {
    self.hidden = YES;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSInteger number = MIN(self.arrayForTitles.count+1, kMaxNumberOfCell);
    if (self.hightConstraint) {
        [UIView animateWithDuration:0.25 animations:^{
            self.hightConstraint.constant = MIN(number*40, kMaxCountForDisplayingCell*40);
        }];
    }
    return  number;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    BXSelectorCell *cell = [tableView dequeueReusableCellWithIdentifier:@"BXSelectorCellIdentifier" forIndexPath:indexPath];
    cell.backgroundColor = BXTextFieldBackgroundColor;
    cell.titleLabel.font = BXSystemFont(13);
    cell.subTitleLabel.font = BXSystemFont(12);
    
    if (indexPath.row < self.arrayForTitles.count && indexPath.row != kMaxNumberOfCell-1) {
        [(UIControl *)cell.accessoryView addTarget:self action:@selector(accessoryButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
        cell.accessoryView.hidden = NO;
        
        NSString *username = [self.arrayForTitles objectAtIndex:indexPath.row];
        cell.titleLabel.text = username;
    
        NSString *hilightText = @"";
        if (self.delegate && [self.delegate respondsToSelector:@selector(hilightText)]) {
            hilightText = [self.delegate hilightText];
        }
        
//        if ([hilightText isEqualToString:username]) {
//            cell.titleLabel.textColor = BXMainColor;
//        }else{
//            cell.titleLabel.textColor = BXTextFieldTextColor;
//        }
        
        BXUser *user = [self.usersDict objectForKey:username];
        if (user && user.zoneName) {
            cell.subTitleLabel.text = [NSString stringWithFormat:@"(登录区服：%@)", user.zoneName];
        }
        cell.iconImageView.hidden = NO;
    }else{
        cell.iconImageView.hidden = YES;
        cell.titleLabel.text = @"历史账号";
        cell.titleLabel.textColor = BXTextFieldTextColor;
        cell.accessoryView.hidden = YES;
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 40;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 0.0001;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 0.0001;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectRowAtIndexPath:withTitle:)]) {
        BXSelectorCell *cell = [tableView cellForRowAtIndexPath:indexPath];
        [self.delegate didSelectRowAtIndexPath:indexPath withTitle:cell.titleLabel.text];
    }
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (void)accessoryButtonTapped:(id)sender {
    if (self.delegate && [self.delegate respondsToSelector:@selector(selectorView:accessoryButtonTappedForRowWithIndexPath:withTitle:)]) {
        UIView *next = [(UIButton *)sender superview];
        while (next) {
            if ([next isKindOfClass:[UITableViewCell class]]) {
                break;
            }
            next = [next superview];
        }
        if ([next isKindOfClass:[BXSelectorCell class]]) {
            BXSelectorCell *cell = (BXSelectorCell *)next;
            NSIndexPath *indexPath = [self.aTableView indexPathForCell:cell];
            if ([self.arrayForTitles containsObject:cell.titleLabel.text]) {
                [self.arrayForTitles removeObject:cell.titleLabel.text];
                [self.usersDict removeObjectForKey:cell.titleLabel.text];
                [self.aTableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
            }
            [self.delegate selectorView:self accessoryButtonTappedForRowWithIndexPath:indexPath withTitle:cell.titleLabel.text];
        }
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];

    UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:self.bounds byRoundingCorners: UIRectCornerBottomRight | UIRectCornerBottomLeft cornerRadii:CGSizeMake(4, 4)];
    CAShapeLayer *maskLayer = [[CAShapeLayer alloc]init];
    maskLayer.frame = self.bounds;
    maskLayer.path = maskPath.CGPath;
    self.layer.mask = maskLayer;
}

@end
