//
//  BXMyH5Controller.m
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/8/26.
//  Copyright © 2021 Gavin. All rights reserved.
//

#import "BXMyH5Controller.h"
#import <WebKit/WebKit.h>
#import "BXPrivacyUtil.h"
#import "BXHeaderView.h"

@interface BXMyH5Controller ()<WKNavigationDelegate, WKScriptMessageHandler>

@property (strong, nonatomic) WKWebView *wkView;

@property (assign, nonatomic) BOOL isAddObserve;

@property (nonatomic, assign) BOOL bx_didSetupConstraints;
@end

@implementation BXMyH5Controller

- (void)dealloc
{
    [self.wkView removeObserver:self forKeyPath:@"title"];
    BXLogInfo(@"%s",__func__);
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.preferredContentSize = [self orientationStatus] ? CGSizeMake(ScreenWidth, ScreenWidth) : CGSizeMake(ScreenWidth, ScreenHeight);
    }
    return self;
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    if (_isAddObserve) {
        [self.wkView.configuration.userContentController removeScriptMessageHandlerForName:@"getApiParamSign"];
        
        _isAddObserve = NO;
    }
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [self notifitionSatatus];
}

-(void)notifitionSatatus{
    [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(statusBarOrientationChange:) name:UIApplicationDidChangeStatusBarOrientationNotification object:nil];
}
-(void)statusBarOrientationChange:(NSNotification*)notification{
    self.preferredContentSize = [self orientationStatus] ? CGSizeMake(ScreenWidth, ScreenWidth) : CGSizeMake(ScreenWidth, ScreenHeight);
    [self.bx_baseframeView autoSetDimensionsToSize:[self orientationStatus] ? CGSizeMake(ScreenWidth, ScreenWidth) : CGSizeMake(ScreenWidth, ScreenWidth)];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = UIColor.clearColor;
    
    [self.view addSubview:self.bx_baseframeView];
    
    [self.bx_baseframeView addSubview:self.bx_baseHeaderView];
    [self.bx_baseHeaderView bx_baseHeaderViewSetString:@"" rightButtonIs:NO];
    @weakify(self)
    self.bx_baseHeaderView.bx_leftCallback = ^{
        @strongify(self)
        [self backAction:nil];
    };
    self.bx_baseHeaderView.bx_rightCallback = ^{
        @strongify(self)
        [self refreshAction:nil];
    };
    
    WKWebViewConfiguration *config = [[WKWebViewConfiguration alloc] init];
    WKPreferences *preference = [[WKPreferences alloc] init];
    //最小字体大小 当将javaScriptEnabled属性设置为NO时，可以看到明显的效果
    preference.minimumFontSize = 0;
    preference.javaScriptEnabled = YES;
    preference.javaScriptCanOpenWindowsAutomatically = YES;
    config.preferences = preference;
    WKUserContentController * wkUController = [[WKUserContentController alloc] init];
    config.userContentController = wkUController;
    
    _wkView = [[WKWebView alloc] initWithFrame:CGRectZero configuration:config];
    [self.bx_baseframeView addSubview:_wkView];
    _wkView.navigationDelegate = self;
    
    [self.wkView.configuration.userContentController addScriptMessageHandler:self name:@"getApiParamSign"];
    
    [_wkView addObserver:self forKeyPath:@"title" options:NSKeyValueObservingOptionNew context:NULL];
    [self.view updateConstraintsIfNeeded];
    
    [self loadUrl];
    
    self.view.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(screenTap:)];
    tap.cancelsTouchesInView = NO;
    [self.view addGestureRecognizer:tap];
}

-(void)backAction:(UIButton *)sender{
    if (self.wkView.canGoBack) {
        [self.wkView goBack];
        return;
    }
    [self bx_hideWithCompletion:^{
        
    }];
}

- (void)screenTap:(UITapGestureRecognizer *)gesture {
    CGPoint p = [gesture locationInView:self.view];
    if (!CGRectContainsPoint(self.bx_baseframeView.frame, p)) {
        [self dismissToRootViewController];
    }
}

-(void)dismissToRootViewController{
    UIViewController *vc = self;
    while (vc.presentingViewController) {
        vc = vc.presentingViewController;
    }
    [vc dismissViewControllerAnimated:YES completion:nil];
}

-(void)refreshAction:(UIButton *)sender{
    [self loadUrl];
}


- (void)updateViewConstraints {
    if (!_bx_didSetupConstraints) {
        [self.bx_baseframeView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0];
        [self.bx_baseframeView autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:0];
        [self.bx_baseframeView autoSetDimensionsToSize:[self orientationStatus] ? CGSizeMake(ScreenHeight, ScreenHeight) : CGSizeMake(ScreenWidth, ScreenWidth)];
        
        [self.bx_baseHeaderView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0];
        [self.bx_baseHeaderView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:0];
        [self.bx_baseHeaderView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:0];
        [self.bx_baseHeaderView autoSetDimension:ALDimensionHeight toSize:40];
        
        [self.wkView autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_baseHeaderView withOffset:10];
        [self.wkView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:5];
        [self.wkView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:5];
        [self.wkView autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:10];
        
        _bx_didSetupConstraints = YES;
    }
    [super updateViewConstraints];
}

- (void)loadUrl {
    NSURL *url = [NSURL URLWithString:_bx_urlStr];
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
    [self.wkView loadRequest:request];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context{
    if ([keyPath isEqualToString:@"title"]) {
        [self.bx_baseHeaderView bx_baseHeaderViewSetString:change[NSKeyValueChangeNewKey] rightButtonIs:NO];
    }
}

#pragma mark - WKScriptMessageHandler
- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message {
    BXLog(@"收到h5调起 - name - %@, body - %@", message.name, message.body);
    if ([message.name isEqualToString:@"getApiParamSign"] && [message.body isKindOfClass:[NSString class]]) {
        NSDictionary *body = [self parseQuery:message.body];
        if (body.count > 0) {
            NSString *sign = [BXPrivacyUtil bx_getSignWithParams:[NSMutableDictionary dictionaryWithDictionary:body]];
            [self.wkView evaluateJavaScript:[NSString stringWithFormat:@"SignDidChange(\"%@\")", sign] completionHandler:^(id _Nullable result, NSError * _Nullable error) {
            }];
        } else {
            NSString *sign = @"";
            [self.wkView evaluateJavaScript:[NSString stringWithFormat:@"SignDidChange(\"%@\")", sign] completionHandler:^(id _Nullable result, NSError * _Nullable error) {
            }];
        }
    }
}

- (NSDictionary *)parseQuery:(NSString *)query {
    NSArray *params = [query componentsSeparatedByString:@"&"];
    NSMutableDictionary *paramsDic = [NSMutableDictionary dictionary];
    if (params.count > 0) {
        for (NSString *par in params) {
            NSArray *arr = [par componentsSeparatedByString:@"="];
            if (arr.count == 2) {
                NSString *key = [[arr objectAtIndex:0] description];
                NSString *value = [[arr objectAtIndex:1] description];
                [paramsDic setObject:value forKey:key];
            }
        }
    }
    return paramsDic;
}

- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler {
    BXLog(@"发送请求之前，决定是否跳转");
    decisionHandler(WKNavigationActionPolicyAllow);
}

- (void)webView:(WKWebView *)webView decidePolicyForNavigationResponse:(WKNavigationResponse *)navigationResponse decisionHandler:(void (^)(WKNavigationResponsePolicy))decisionHandler {
    BXLog(@"收到响应后，是否跳转");
    decisionHandler(WKNavigationResponsePolicyAllow);
}

- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation {
    BXLog(@"页面开始加载");
}

- (void)webView:(WKWebView *)webView didReceiveServerRedirectForProvisionalNavigation:(WKNavigation *)navigation {
    BXLog(@"接收到服务器跳转请求之后调用");
}

- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(WKNavigation *)navigation withError:(NSError *)error {
    BXLog(@"页面加载失败，注意不要漏掉这部分的处理噢，特别是全屏显示网页，而又没有关闭的原生按钮时");
}

- (void)webView:(WKWebView *)webView didCommitNavigation:(WKNavigation *)navigation {
    BXLog(@"内容开始返回");
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation {
    BXLog(@"页面加载完成后");
}

@end
