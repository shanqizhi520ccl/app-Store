//
//  YYAccountListView.h
//  YYPalftormSDK
//
//  Created by Rolata Kasahawa on 2019/10/25.
//  Copyright © 2020 YY Tech Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BXSelectorControll;

@protocol BXSelectorControllDelegate <NSObject>

@required
- (NSArray<NSString *> *)titlesForRowsInSelectorView;

@optional
- (NSString *)hilightText;

- (void)didSelectRowAtIndexPath:(NSIndexPath *)indexPath
                      withTitle:(NSString *)title;

- (void)selectorView:(BXSelectorControll *)view accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath withTitle:(NSString *)title;
@end

@interface BXSelectorControll : UIView
@property (nonatomic, weak) id<BXSelectorControllDelegate>delegate;
@property (nonatomic, strong)NSLayoutConstraint *hightConstraint;
- (instancetype)initWithDelegate:(id<BXSelectorControllDelegate>)delegate;
- (void)showing;
- (void)dismissing;
@end

