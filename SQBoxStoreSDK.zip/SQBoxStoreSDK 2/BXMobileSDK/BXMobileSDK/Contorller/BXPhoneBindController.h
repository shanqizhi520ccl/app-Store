//
//  BXPhoneBindController.h
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/8/27.
//  Copyright © 2021 Gavin. All rights reserved.
//

#import "BXBaseViewController.h"

typedef NS_ENUM(NSInteger, BXPhoneType) {
    /// 绑定手机
    BXPhoneTypeMobile,
    /// 解绑手机
    BXPhoneTypeReset
};
//NS_ASSUME_NONNULL_BEGIN

typedef void (^BtnActionBlock)(void);

@interface BXPhoneBindController : BXBaseViewController

- (instancetype)initWithType:(NSInteger)bx_registerType;

@property (copy, nonatomic) BtnActionBlock btnBlock;

@end

//NS_ASSUME_NONNULL_END
