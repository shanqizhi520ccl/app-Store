//
//  BXBindMobileTipsViewController.m
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/24.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXBindMobileTipsViewController.h"
#import "BXBindMobileViewController.h"
#import "BXIdAuthViewController.h"
#import "BXNoticeViewController.h"
#import "BXMobileManager+Private.h"
#import "BXEvent.h"
#import "BXConfig.h"
#import "BXUser.h"

@interface BXBindMobileTipsViewController ()
@property (nonatomic, strong) UIView *bx_navgationBar;
@property (nonatomic, strong) UIImageView *bx_navgationBackgroundImgView;
@property (nonatomic, strong) UILabel *bx_titileLabel;
@property (nonatomic, strong) UIButton *bx_closeButton;

@property (nonatomic, strong) UILabel *bx_tipsLabel;
@property (nonatomic, strong) UIButton *bx_nextButton;
@property (nonatomic, strong) UIButton *bx_cancelButton;

@property (nonatomic, assign) BOOL bx_didSetupConstraints;
@end

@implementation BXBindMobileTipsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if (!isSmallScreen) {
        self.preferredContentSize = CGSizeMake(338, 195);
    }else{
        self.preferredContentSize = CGSizeMake(280, 195);
    }
    
    [self setupViews];
}

- (void)setupViews {
    [self.view addSubview:self.bx_navgationBar];
    [self.bx_navgationBar addSubview:self.bx_navgationBackgroundImgView];
    [self.bx_navgationBar addSubview:self.bx_titileLabel];
    [self.bx_navgationBar addSubview:self.bx_closeButton];
    
    [self.view addSubview:self.bx_tipsLabel];
    [self.view addSubview:self.bx_nextButton];
    [self.view addSubview:self.bx_cancelButton];

    [self.view updateConstraintsIfNeeded];
}

- (void)updateViewConstraints {
    if (!_bx_didSetupConstraints) {
        // 导航栏
        [self.bx_navgationBar autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero excludingEdge:ALEdgeBottom];
        [self.bx_navgationBar autoSetDimension:ALDimensionHeight toSize:40];
        
        [self.bx_navgationBackgroundImgView autoPinEdgesToSuperviewEdges];
        
        [self.bx_closeButton autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:20];
        [self.bx_closeButton autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
        
        [self.bx_titileLabel autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:20];
        [self.bx_titileLabel autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
        
        NSArray *views = @[self.bx_tipsLabel, self.bx_nextButton, self.bx_cancelButton];
        [views autoAlignViewsToAxis:ALAxisVertical];
        
        [self.bx_tipsLabel autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_navgationBar withOffset:15];
        [self.bx_tipsLabel autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:20];
        [self.bx_tipsLabel autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:20];
        
        [self.bx_nextButton autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_tipsLabel withOffset:15];
        [self.bx_nextButton autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:20];
        [self.bx_nextButton autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:20];
        [self.bx_nextButton autoSetDimension:ALDimensionHeight toSize:40];
        
        [self.bx_cancelButton autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_nextButton withOffset:5];
        
        _bx_didSetupConstraints = YES;
    }
    [super updateViewConstraints];
}

- (void)closeEvent:(id)sender {
    [self checkAuthorizeCompletionAndDissmiss];
}

- (void)cancelEvent:(id)sender {
    [self checkAuthorizeCompletionAndDissmiss];
}

- (void)bindPhoneNumberEvent:(id)sender {
    BXBindMobileViewController *bx_bindMobileController = [[BXBindMobileViewController alloc] init];
    [self presentViewController:bx_bindMobileController animated:YES completion:^{
    }];
}

//nav
- (UIView *)bx_navgationBar {
    if (!_bx_navgationBar) {
        _bx_navgationBar = [[UIView alloc] init];
    }
    return _bx_navgationBar;
}

- (UIButton *)bx_closeButton {
    if (!_bx_closeButton) {
        _bx_closeButton = [UIButton buttonWithType:UIButtonTypeCustom];
        UIImage *aImage = [UIImage imageNamed:@"nav_close_black" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
        [_bx_closeButton setImage:aImage forState:UIControlStateNormal];
        [_bx_closeButton addTarget:self action:@selector(closeEvent:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _bx_closeButton;
}

- (UILabel *)bx_titileLabel {
    if (!_bx_titileLabel) {
        _bx_titileLabel = [[UILabel alloc] init];
        [_bx_titileLabel setText:@"绑定手机"];
        [_bx_titileLabel setTextColor:BXHexColor(0x333333)];
        [_bx_titileLabel setFont:BXBoldSystemFont(14)];
    }
    return _bx_titileLabel;
}

- (UIImageView *)bx_navgationBackgroundImgView {
    if (!_bx_navgationBackgroundImgView) {
 
        _bx_navgationBackgroundImgView = [[UIImageView alloc] init];
    }
    return _bx_navgationBackgroundImgView;
}

- (UILabel *)bx_tipsLabel {
    if (!_bx_tipsLabel) {
        _bx_tipsLabel = [[UILabel alloc] init];
        [_bx_tipsLabel setText:@"账号关联手机\n忘记密码可用手机找回哦"];
        [_bx_tipsLabel setTextColor:BXHexColor(0x666666)];
        [_bx_tipsLabel setFont:BXSystemFont(14)];
        [_bx_tipsLabel setTextAlignment:NSTextAlignmentCenter];
        [_bx_tipsLabel setNumberOfLines:0];
    }
    return _bx_tipsLabel;
}

- (UIButton *)bx_nextButton {
    if (!_bx_nextButton) {
        UIButton *bx_button = [UIButton buttonWithType:UIButtonTypeCustom];
        [bx_button setTitle:@"立即绑定" forState:UIControlStateNormal];
        [bx_button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        UIImage *aImage = [UIImage imageNamed:@"bxm_Anniu" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
        [bx_button setBackgroundImage:aImage forState:UIControlStateNormal];
        [bx_button addTarget:self action:@selector(bindPhoneNumberEvent:) forControlEvents:UIControlEventTouchUpInside];
        bx_button.titleLabel.font = BXSystemFont(15);
        
        _bx_nextButton = bx_button;
    }
    return _bx_nextButton;
}

- (UIButton *)bx_cancelButton {
    if (!_bx_cancelButton) {
        UIButton *bx_button = [UIButton buttonWithType:UIButtonTypeCustom];
        [bx_button setTitle:@"取消" forState:UIControlStateNormal];
        [bx_button setTitleColor:BXHexColor(0x999999) forState:UIControlStateNormal];
        [bx_button setTitleColor:[UIColor grayColor] forState:UIControlStateHighlighted];
        [bx_button addTarget:self action:@selector(cancelEvent:) forControlEvents:UIControlEventTouchUpInside];
        bx_button.titleLabel.font = BXSystemFont(15);
        _bx_cancelButton = bx_button;
    }
    return _bx_cancelButton;
}

- (void)checkAuthorizeCompletionAndDissmiss {
    BXUser *user = [BXMobileManager shareManager].currentUser;
    if (user.adultState == 1 && [BXConfig config].realNameAuthTip == 1) {
        user.realnameReminderTime = [NSDate date];
        [user save];
        
        BXIdAuthViewController *bx_idAuthController = [[BXIdAuthViewController alloc] init];
        bx_idAuthController.isLimit = user.loginLimit != 2;
        bx_idAuthController.dismissBlock = ^(BOOL isAuditLimit, NSDictionary *result) {
            
        };
        [self presentViewController:bx_idAuthController animated:YES completion:^{
        }];
    }else {
        [[NSNotificationCenter defaultCenter] postNotificationName:BXUserLoginSuccessNotification object:[user proxyLoginResultDictionary]];
        
        [self bx_dismissPresentedViewController:self completionBlock:^{
            [BXEvent bx_doUpdateNotice:^(NSArray *notifies, NSError *error) {
                if (notifies.count > 0) {
                   dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.25 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                        BXNoticeViewController *bx_notifyController = [[BXNoticeViewController alloc] initWithNotifies:notifies];
                        [bx_notifyController bx_presentWithViewController:nil];
                    });
                }
            }];
        }];
    }
}

@end
