//
//  BXSeviceAndPrivacyViewController.h
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/24.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXBaseViewController.h"

//NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, BXPageType) {
    /// 用户协议
    BXPageType_UserProtocol,
    /// 用户隐私政策
    BXPageType_UserPrivate
};

@interface BXSeviceAndPrivacyViewController : BXBaseViewController

@property (nonatomic, strong, readonly) NSURL *aURL;

@property (nonatomic, readonly) BXPageType pageType;

- (instancetype)initWithUrl:(NSURL *)url pageType:(BXPageType)pageType;

@end

//NS_ASSUME_NONNULL_END
