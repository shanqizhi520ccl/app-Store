//
//  BXChangePWDViewController.h
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/9/7.
//  Copyright © 2021 Gavin. All rights reserved.
//

#import "BXBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface BXChangePWDViewController : BXBaseViewController

@end

NS_ASSUME_NONNULL_END
