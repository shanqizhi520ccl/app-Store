//
//  BXSeviceAndPrivacyViewController.m
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/24.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXSeviceAndPrivacyViewController.h"
#import <WebKit/WebKit.h>
#import "BXConfig.h"

@interface BXSeviceAndPrivacyViewController ()<WKUIDelegate, WKNavigationDelegate>
@property (nonatomic, readwrite) BXPageType pageType;
@property (nonatomic, strong, readwrite) NSURL *aURL;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UIButton *closeButton;
@property (nonatomic, strong) UIView *navgationBar;
@property (nonatomic, strong) UIView *webBackgroundView;
@property (nonatomic, strong) WKWebView *webView;
@property (nonatomic, strong) UIButton *agreeButton;
@property (nonatomic, assign) BOOL bx_didSetupConstraints;
@end

@implementation BXSeviceAndPrivacyViewController

#ifdef DEBUG
- (void)dealloc
{
    BXLogDebug(@"%@ dealloc", self.class);
    [self.webView removeObserver:self forKeyPath:@"title"];
}
#else
- (void)dealloc
{
    [self.webView removeObserver:self forKeyPath:@"title"];
}
#endif

- (instancetype)initWithUrl:(NSURL *)url pageType:(BXPageType)pageType
{
    self = [super init];
    if (self) {
        self.pageType = pageType;
        self.aURL = url;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self.view addSubview:self.navgationBar];
    [self.navgationBar addSubview:self.titleLabel];
    [self.navgationBar addSubview:self.closeButton];
    
    [self.view addSubview:self.webBackgroundView];
    [self.webBackgroundView addSubview:self.webView];
    [self.view addSubview:self.agreeButton];
    
    [self.view updateConstraintsIfNeeded];
    
    [self.webView addObserver:self forKeyPath:@"title" options:NSKeyValueObservingOptionNew context:NULL];
    
//    if (self.pageType == BXPageType_UserProtocol && [BXConfig config].userProtocolRefuseBtn) {
//        self.closeButton.hidden = YES;
//    }
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    if (self.aURL) {
        [self.webView loadRequest:[NSURLRequest requestWithURL:self.aURL]];
    }
}

- (void)updateViewConstraints {
    if (!_bx_didSetupConstraints) {
        [self.navgationBar autoPinEdgesToSuperviewMarginsExcludingEdge:ALEdgeBottom];
        [self.navgationBar autoSetDimension:ALDimensionHeight toSize:48];
        
        [self.titleLabel autoAlignAxisToSuperviewAxis:ALAxisVertical];
        [self.titleLabel autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
        
        [self.closeButton autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
        [self.closeButton autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:0];
        
        [self.webBackgroundView autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.navgationBar];
        [self.webBackgroundView autoPinEdge:ALEdgeLeading toEdge:ALEdgeLeading ofView:self.navgationBar];
        [self.webBackgroundView autoPinEdge:ALEdgeTrailing toEdge:ALEdgeTrailing ofView:self.navgationBar];
    
        [self.webView autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero];
        
        [self.agreeButton autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.webBackgroundView withOffset:10];
        [self.agreeButton autoSetDimension:ALDimensionHeight toSize:40];
        [self.agreeButton autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:10];
        [self.agreeButton autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:7];
        [self.agreeButton autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:7];
        
        _bx_didSetupConstraints = YES;
    }
    [super updateViewConstraints];
}

- (void)viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];
    
    UIInterfaceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation;
    if (UIInterfaceOrientationIsLandscape(orientation)) {
        self.preferredContentSize =  CGSizeMake(360, 320);
    }else{
        self.preferredContentSize =  CGSizeMake(ScreenWidth, ScreenHeight);
    }
}

#pragma mark - Property Getter

- (UIView *)navgationBar {
    if (!_navgationBar) {
        _navgationBar = [[UIView alloc] init];
        [_navgationBar  setBackgroundColor:[UIColor whiteColor]];
    }
    return _navgationBar;
}

- (UILabel *)titleLabel {
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc] init];
        [_titleLabel setText:@"加载中..."];
        [_titleLabel setTextColor:BXHexColor(0x333333)];
        [_titleLabel setFont:BXBoldSystemFont(17)];
        [_titleLabel setTextAlignment:NSTextAlignmentCenter];
    }
    return _titleLabel;
}

- (UIButton *)closeButton {
    if (!_closeButton) {
        _closeButton = [[UIButton alloc] init];
        UIImage *aImage = [UIImage imageNamed:@"nav_close_black" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
        _closeButton.hidden = YES;
        [_closeButton setImage:aImage forState:UIControlStateNormal];
        [_closeButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_closeButton addTarget:self action:@selector(closeEvent:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _closeButton;
}

- (UIView *)webBackgroundView {
    if (!_webBackgroundView) {
        _webBackgroundView = [[UIView alloc] init];
        [_webBackgroundView  setBackgroundColor:BXSectionBackgroundColor];
        _webBackgroundView.layer.cornerRadius = BXCornerRadius;
    }
    return _webBackgroundView;
}

- (WKWebView *)webView{
    if(_webView == nil){
        //创建网页配置对象
        WKWebViewConfiguration *config = [[WKWebViewConfiguration alloc] init];
        
        // 创建设置对象
        WKPreferences *preference = [[WKPreferences alloc] init];
        //最小字体大小 当将javaScriptEnabled属性设置为NO时，可以看到明显的效果
        preference.minimumFontSize = 0;
        //设置是否支持javaScript,默认支持
        preference.javaScriptEnabled = YES;
        // 在iOS上默认为NO，表示是否允许不经过用户交互由javaScript自动打开窗口
        preference.javaScriptCanOpenWindowsAutomatically = YES;
        
        config.preferences = preference;

        WKUserContentController * wkUController = [[WKUserContentController alloc] init];
        config.userContentController = wkUController;
        
        _webView = [[WKWebView alloc] initWithFrame:CGRectZero configuration:config];
        _webView.backgroundColor = [UIColor clearColor];
        _webView.opaque = NO;
        _webView.UIDelegate = self;
        _webView.navigationDelegate = self;
    }
    return _webView;
}

- (UIButton *)agreeButton {
    if (!_agreeButton) {
        UIButton *bx_button = [UIButton buttonWithType:UIButtonTypeCustom];
        [bx_button setTitle:@"我已阅读并同意" forState:UIControlStateNormal];
        [bx_button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        bx_button.titleLabel.font = BXSystemFont(14);
        UIImage *aImage = [UIImage bx_bundleImageWithName:@"bxm_Anniu"];
        [bx_button setBackgroundImage:aImage forState:UIControlStateNormal];
        [bx_button addTarget:self action:@selector(agreementEvent:) forControlEvents:UIControlEventTouchUpInside];
        bx_button.clipsToBounds  = YES;
        _agreeButton = bx_button;
    }
    return _agreeButton;
}

#pragma mark - User Response

- (void)closeEvent:(id)sender {
    [self bx_hideWithCompletion:^{
        
    }];
}

- (void)agreementEvent:(id)sender {
    [self closeEvent:nil];
}

#pragma mark - WKNavigationDelegate

- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error {
    //[self hideWithCompletion:nil];
    BXLogError(@"load url error: %@", error.localizedDescription);
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(null_unspecified WKNavigation *)navigation {
    BXLogError(@"finish load url");
}

- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler {
    if (![navigationAction.request.URL.scheme isEqualToString:@"http"] &&
        ![navigationAction.request.URL.scheme isEqualToString:@"https"]) {
        [[UIApplication sharedApplication] openURL:navigationAction.request.URL];
        decisionHandler(WKNavigationActionPolicyCancel);
    }else{
        decisionHandler(WKNavigationActionPolicyAllow);
    }
}

#pragma mark - Web KVO

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
    if ([keyPath isEqualToString:@"title"]) {
        if (object == self.webView){
            self.titleLabel.text = self.webView.title;
        }else{
            [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
        }
    }else{
        [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
    }
}

@end
