//
//  BXThreeSelectionController.h
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/8/23.
//  Copyright © 2021 Gavin. All rights reserved.
//

#import "BXBaseViewController.h"
#import "BXThreeSelectionView.h"

NS_ASSUME_NONNULL_BEGIN

@interface BXThreeSelectionController : BXBaseViewController

typedef void (^DeviceCallback)(void);
@property (copy, nonatomic) DeviceCallback bx_DeviceCallback;
typedef void (^Callback)(BOOL); // 同意回调
@property (copy, nonatomic) Callback bx_MsgCallback;
@property (assign, nonatomic) BXVVThreeSelectionPrivacyStatus bx_Status;

@end

NS_ASSUME_NONNULL_END
