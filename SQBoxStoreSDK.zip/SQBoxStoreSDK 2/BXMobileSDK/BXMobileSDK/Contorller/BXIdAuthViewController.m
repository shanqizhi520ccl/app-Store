//
//  BXIdAuthViewController.m
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/24.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXIdAuthViewController.h"
#import "TPKeyboardAvoidingScrollView.h"
#import "BXNoticeViewController.h"
#import "BXMobileManager+Private.h"
#import "BXEvent.h"
#import "BXUser.h"
#import "BXConfig.h"
#import "BXAddHeartbeatManager.h"

@interface BXIdAuthViewController ()
@property (nonatomic, strong) UIView *bx_navgationBar;
@property (nonatomic, strong) UIImageView *bx_navgationBackgroundImgView;
@property (nonatomic, strong) UILabel *bx_titileLabel;
@property (nonatomic, strong) UIButton *bx_closeButton;

@property (nonatomic, strong) TPKeyboardAvoidingScrollView *bx_scrollView;

@property (nonatomic, strong) UILabel *topTipsLabel;
@property (nonatomic, strong) UILabel *bottomTipsLabel;

@property (nonatomic, strong) UIView *bx_textFieldBackgroundView;
@property (nonatomic, strong) BXTextField *bx_realnameTextField;
@property (nonatomic, strong) BXTextField *bx_idcardTextField;

@property (nonatomic, strong) UIButton *bx_nextButton;

@property (nonatomic, assign) BOOL bx_didSetupConstraints;
@end

@implementation BXIdAuthViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    if (!isSmallScreen) {
        self.preferredContentSize = CGSizeMake(338, 290);
    }else{
        self.preferredContentSize = CGSizeMake(280, 290);
    }
    [self setupViews];
}

- (void)setupViews {
    [self.view addSubview:self.bx_navgationBar];
    [self.bx_navgationBar addSubview:self.bx_navgationBackgroundImgView];
    [self.bx_navgationBar addSubview:self.bx_titileLabel];
    [self.bx_navgationBar addSubview:self.bx_closeButton];
    self.bx_closeButton.hidden = self.isLimit;
    
    [self.view addSubview:self.bx_scrollView];
    
    [self.bx_scrollView addSubview:self.topTipsLabel];
    
    [self.bx_scrollView addSubview:self.bx_textFieldBackgroundView];
    [self.bx_textFieldBackgroundView addSubview:self.bx_realnameTextField];
    [self.bx_textFieldBackgroundView addSubview:self.bx_idcardTextField];
    
    UIView *lineView = [[UIView alloc] init];
    [lineView setBackgroundColor:BXHexColor(0xFFFFFF)];
    [self.bx_textFieldBackgroundView addSubview:lineView];
    
    [lineView autoCenterInSuperview];
    [lineView autoSetDimension:ALDimensionHeight toSize:1];
    [lineView autoMatchDimension:ALDimensionWidth toDimension:ALDimensionWidth ofView:self.bx_textFieldBackgroundView];

    [self.bx_scrollView addSubview:self.bx_nextButton];
    
    [self.bx_scrollView addSubview:self.bottomTipsLabel];
    
    [self.view updateConstraintsIfNeeded];
}

- (void)updateViewConstraints {
    if (!_bx_didSetupConstraints) {
        // 导航栏
        [self.bx_navgationBar autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero excludingEdge:ALEdgeBottom];
        [self.bx_navgationBar autoSetDimension:ALDimensionHeight toSize:40];
        
        [self.bx_navgationBackgroundImgView autoPinEdgesToSuperviewEdges];
        
        [self.bx_closeButton autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:20];
        [self.bx_closeButton autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
        
        [self.bx_titileLabel autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:20];
        [self.bx_titileLabel autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
        
        // content
        [self.bx_scrollView autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero excludingEdge:ALEdgeTop];
        [self.bx_scrollView autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_navgationBar];
        
        [self.topTipsLabel autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:10];
        [self.topTipsLabel autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:20];
        [self.topTipsLabel autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:20];
        
        // 输入框
        [self.bx_textFieldBackgroundView autoPinEdge:ALEdgeLeading toEdge:ALEdgeLeading ofView:self.view withOffset:20];
        [self.bx_textFieldBackgroundView autoPinEdge:ALEdgeTrailing toEdge:ALEdgeTrailing ofView:self.view withOffset:-20];
        
        [self.bx_textFieldBackgroundView autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.topTipsLabel withOffset:10];
        [self.bx_textFieldBackgroundView autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:20];
        [self.bx_textFieldBackgroundView autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:20];
        [self.bx_textFieldBackgroundView autoSetDimension:ALDimensionHeight toSize:40*2];
    
        NSArray *tfs = @[self.bx_realnameTextField, self.bx_idcardTextField];
        [tfs.firstObject autoPinEdgeToSuperviewEdge:ALEdgeLeading];
        [tfs.firstObject autoPinEdgeToSuperviewEdge:ALEdgeTrailing];
        [tfs autoMatchViewsDimension:ALDimensionWidth];
        [tfs autoDistributeViewsAlongAxis:ALAxisVertical alignedTo:ALAttributeVertical withFixedSpacing:0];
        
        [self.bottomTipsLabel autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_textFieldBackgroundView withOffset:10];
        [self.bottomTipsLabel autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:20];
        [self.bottomTipsLabel autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:20];
        [self.bottomTipsLabel autoPinEdgeToSuperviewEdge:ALEdgeBottom];
        
        [self.bx_nextButton autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bottomTipsLabel withOffset:10];
        [self.bx_nextButton autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:20];
        [self.bx_nextButton autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:20];
        [self.bx_nextButton autoSetDimension:ALDimensionHeight toSize:40];
        
        _bx_didSetupConstraints = YES;
    }
    [super updateViewConstraints];
}

- (void)closeEvent:(id)sender {
    [self checkAuthorizeCompletionAndDissmiss];
}

- (void)realnameAuthEvent:(id)sender {
    if (self.bx_realnameTextField.text.length == 0) {
        [BXMBProgressHUD bx_showMessage:@"请输入您的姓名"];
        return;
    }
    
    if (self.bx_realnameTextField.text.length < 2) {
        [BXMBProgressHUD bx_showMessage:@"请检查输入的姓名是否正确"];
        return;
    }
    
    if (self.bx_idcardTextField.text.length == 0) {
        [BXMBProgressHUD bx_showMessage:@"请输入身份证号"];
        return;
    }
    
    if (![NSString bx_checkValidityForIDCard:self.bx_idcardTextField.text]) {
        [BXMBProgressHUD bx_showMessage:@"身份证输入格式错误，请输入正确的身份证号码"];
        return;
    }
    
    [self.view endEditing:YES];
    
    [BXEvent bx_doRealnameAuth:self.bx_idcardTextField.text realName:self.bx_realnameTextField.text phone:nil complement:^(id obj, NSError *error) {
        if (!error) {
            if (self.dismissBlock) {
                self.dismissBlock(true, obj);
            }
            [BXMobileManager shareManager].currentUser.idcard = self.bx_idcardTextField.text;
            [BXMobileManager shareManager].currentUser.realName = self.bx_realnameTextField.text;
            [[BXAddHeartbeatManager sharedInstance] bx_stopAntiAddictionTimer];
            [self checkAuthorizeCompletionAndDissmiss];
        }else{
            if (self.dismissBlock) {
                self.dismissBlock(false, @{});
            }
            [BXMBProgressHUD bx_showMessage:error.localizedDescription delay:YES];
        }
    }];
}

//nav
- (UIView *)bx_navgationBar {
    if (!_bx_navgationBar) {
        _bx_navgationBar = [[UIView alloc] init];
    }
    return _bx_navgationBar;
}

- (UIButton *)bx_closeButton {
    if (!_bx_closeButton) {
        _bx_closeButton = [UIButton buttonWithType:UIButtonTypeCustom];
        UIImage *aImage = [UIImage imageNamed:@"nav_close_black" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
        [_bx_closeButton setImage:aImage forState:UIControlStateNormal];
        [_bx_closeButton addTarget:self action:@selector(closeEvent:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _bx_closeButton;
}

- (UILabel *)bx_titileLabel {
    if (!_bx_titileLabel) {
        _bx_titileLabel = [[UILabel alloc] init];
        [_bx_titileLabel setText:@"实名认证"];
        [_bx_titileLabel setTextColor:BXHexColor(0x333333)];
        [_bx_titileLabel setFont:BXBoldSystemFont(14)];
    }
    return _bx_titileLabel;
}

- (UIImageView *)bx_navgationBackgroundImgView {
    if (!_bx_navgationBackgroundImgView) {
        _bx_navgationBackgroundImgView = [[UIImageView alloc] init];
    }
    return _bx_navgationBackgroundImgView;
}

- (TPKeyboardAvoidingScrollView *)bx_scrollView {
    if (!_bx_scrollView) {
        _bx_scrollView = [[TPKeyboardAvoidingScrollView alloc] init];
        _bx_scrollView.delaysContentTouches = NO;
        _bx_scrollView.backgroundColor  = [UIColor clearColor];
    }
    return _bx_scrollView;
}

- (UIView *)bx_textFieldBackgroundView {
    if (!_bx_textFieldBackgroundView) {
        _bx_textFieldBackgroundView = [[UIView alloc] init];
        _bx_textFieldBackgroundView.backgroundColor  = BXTextFieldBackgroundColor;
        _bx_textFieldBackgroundView.layer.cornerRadius = 4;
    }
    return _bx_textFieldBackgroundView;
}

- (BXTextField *)bx_realnameTextField {
    if (!_bx_realnameTextField) {
        _bx_realnameTextField = [BXTextField textFieldWithTitle:nil placeHolder:@"姓名"];
        _bx_realnameTextField.backgroundColor = [UIColor clearColor];
        _bx_realnameTextField.borderStyle = UITextBorderStyleNone;
        _bx_realnameTextField.font = BXSystemFont(14);
        _bx_realnameTextField.textColor = BXTextFieldTextColor;
        _bx_realnameTextField.keyboardType = UIKeyboardTypeNamePhonePad;
        _bx_realnameTextField.autocorrectionType = UITextAutocorrectionTypeNo;
        _bx_realnameTextField.autocapitalizationType = UITextAutocapitalizationTypeNone;
                
        @weakify(self)
        BXTextFieldAction *rightAction = [BXTextFieldAction actionWithImage:@"tf_clear" handler:^(BXTextFieldAction * _Nonnull action) {
            @strongify(self)
            self.bx_realnameTextField.text = nil;
        }];
        [_bx_realnameTextField setTrillingActions:@[rightAction]];
    }
    return _bx_realnameTextField;
}

- (UITextField *)bx_idcardTextField {
    if (!_bx_idcardTextField) {
        _bx_idcardTextField = [BXTextField textFieldWithTitle:nil placeHolder:@"身份证"];
        _bx_idcardTextField.backgroundColor = [UIColor clearColor];
        _bx_idcardTextField.borderStyle = UITextBorderStyleNone;
        _bx_idcardTextField.font = BXSystemFont(14);
        _bx_idcardTextField.textColor = BXTextFieldTextColor;
        _bx_idcardTextField.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
        _bx_idcardTextField.autocorrectionType = UITextAutocorrectionTypeNo;
        _bx_idcardTextField.autocapitalizationType = UITextAutocapitalizationTypeNone;
        
        @weakify(self)
        BXTextFieldAction *rightAction = [BXTextFieldAction actionWithImage:@"tf_clear" handler:^(BXTextFieldAction * _Nonnull action) {
            @strongify(self)
            self.bx_idcardTextField.text = nil;
        }];
        [_bx_idcardTextField setTrillingActions:@[rightAction]];
    }
    return _bx_idcardTextField;
}

- (UILabel *)topTipsLabel {
    if (!_topTipsLabel) {
        _topTipsLabel = [[UILabel alloc] init];
        [_topTipsLabel setText:@"根据相关法律，进行网络游戏、网络交易等行为时需要实名认证"];
        [_topTipsLabel setTextColor:BXHexColor(0x333333)];
        [_topTipsLabel setFont:BXSystemFont(12)];
        [_topTipsLabel setTextAlignment:NSTextAlignmentLeft];
        [_topTipsLabel setNumberOfLines:0];
    }
    return _topTipsLabel;
}

- (UILabel *)bottomTipsLabel {
    if (!_bottomTipsLabel) {
        _bottomTipsLabel = [[UILabel alloc] init];
        [_bottomTipsLabel setText:@"注意:\n1、姓名、身份证须属于同一人\n2、实名认证通过之后，不可更改"];
        [_bottomTipsLabel setTextColor:BXHexColor(0x333333)];
        [_bottomTipsLabel setFont:BXSystemFont(12)];
        [_bottomTipsLabel setTextAlignment:NSTextAlignmentLeft];
        [_bottomTipsLabel setNumberOfLines:0];
    }
    return _bottomTipsLabel;
}

- (UIButton *)bx_nextButton {
    if (!_bx_nextButton) {
        UIButton *bx_button = [UIButton buttonWithType:UIButtonTypeCustom];
        [bx_button setTitle:@"确定" forState:UIControlStateNormal];
        [bx_button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        UIImage *aImage = [UIImage imageNamed:@"bxm_Anniu" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
        [bx_button setBackgroundImage:aImage forState:UIControlStateNormal];
        [bx_button addTarget:self action:@selector(realnameAuthEvent:) forControlEvents:UIControlEventTouchUpInside];

        _bx_nextButton = bx_button;
    }
    return _bx_nextButton;
}

- (void)checkAuthorizeCompletionAndDissmiss {
    BXUser *user = [BXMobileManager shareManager].currentUser;
    [[NSNotificationCenter defaultCenter] postNotificationName:BXUserLoginSuccessNotification object:[user proxyLoginResultDictionary]];
    
    [self bx_dismissPresentedViewController:self completionBlock:^{
        [BXEvent bx_doUpdateNotice:^(NSArray *notifies, NSError *error) {
            if (notifies.count > 0) {
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.25 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    BXNoticeViewController *bx_notifyController = [[BXNoticeViewController alloc] initWithNotifies:notifies];
                    [bx_notifyController bx_presentWithViewController:nil];
                });
            }
        }];
    }];
}

@end
