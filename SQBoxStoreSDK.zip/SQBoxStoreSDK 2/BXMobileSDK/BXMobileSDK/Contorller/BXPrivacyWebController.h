//
//  BXPrivacyWebController.h
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/9/2.
//  Copyright © 2021 Gavin. All rights reserved.
//

#import "BXBaseViewController.h"

static NSString * _Nonnull const kAgreedMethod = @"agreeUserOrPrivacyProtocol";
static NSString * _Nonnull const kRefuseMethod = @"refuseUserOrPrivacyProtocol";
static NSString * _Nonnull const kOpenUserProtocol = @"openUserProtocol"; // 展示用户协议
static NSString * _Nonnull const kOpenPrivacyProtocol = @"openPrivacyProtocol"; // 展示隐私协议


NS_ASSUME_NONNULL_BEGIN
typedef void (^WebBtnCallback)(BOOL agreed);

@interface BXPrivacyWebController : BXBaseViewController

@property (strong, nonatomic) NSString *urlStr;

@property (copy, nonatomic) WebBtnCallback WebBtnCallback;

@end

NS_ASSUME_NONNULL_END
