//
//  BXUserDataManagerController.m
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/8/27.
//  Copyright © 2021 Gavin. All rights reserved.
//

#import "BXUserDataManagerController.h"
#import "BXMyH5Controller.h"
#import "BXPrivacyUtil.h"

@interface BXUserDataManagerController ()

@property(strong, nonatomic) UILabel *bx_leftLabel;

@property(strong, nonatomic) UIImageView *bx_rightImageView;

@property (nonatomic, assign) BOOL bx_didSetupConstraints;
@end

@implementation BXUserDataManagerController

- (void)dealloc
{
    BXLogInfo(@"%s",__func__);
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.preferredContentSize = [self orientationStatus] ? CGSizeMake(ScreenWidth, ScreenWidth) : CGSizeMake(ScreenWidth, ScreenHeight);
    }
    return self;
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [self notifitionSatatus];
}

-(void)notifitionSatatus{
    [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(statusBarOrientationChange:) name:UIApplicationDidChangeStatusBarOrientationNotification object:nil];
}
-(void)statusBarOrientationChange:(NSNotification*)notification{
    self.preferredContentSize = [self orientationStatus] ? CGSizeMake(ScreenWidth, ScreenWidth) : CGSizeMake(ScreenWidth, ScreenHeight);
    [self.bx_baseframeView autoSetDimensionsToSize:[self orientationStatus] ? CGSizeMake(ScreenWidth, ScreenWidth) : CGSizeMake(ScreenWidth, ScreenWidth)];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setupViews];
    
    self.view.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(screenTap:)];
    tap.cancelsTouchesInView = NO;
    [self.view addGestureRecognizer:tap];
}

- (void)setupViews {
    self.view.backgroundColor = UIColor.clearColor;
    
    
    [self.view addSubview:self.bx_baseframeView];
    
    [self.bx_baseframeView addSubview:self.bx_baseHeaderView];
    [self.bx_baseHeaderView bx_baseHeaderViewSetString:@"个人信息管理"];
    @weakify(self)
    self.bx_baseHeaderView.bx_leftCallback = ^{
        @strongify(self)
        [self backAction:nil];
    };
    
    [self.bx_baseframeView addSubview:self.bx_baseBackView];
    
    _bx_leftLabel = [[UILabel alloc] init];
    _bx_leftLabel.text = @"删除个人信息";
    _bx_leftLabel.textColor = BXHexColor(0x333333);
    _bx_leftLabel.font = BXSystemFont(14);
    [self.bx_baseBackView addSubview:_bx_leftLabel];
    
    _bx_rightImageView = [[UIImageView alloc]init];
    _bx_rightImageView.image = [UIImage imageNamed:@"info_left" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
    [self.bx_baseBackView addSubview:_bx_rightImageView];
    
    self.bx_baseBackView.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(bx_rightImageViewTap:)];
    tap.cancelsTouchesInView = NO;
    [self.bx_baseBackView addGestureRecognizer:tap];
    
    [self.view updateConstraintsIfNeeded];
}


- (void)updateViewConstraints {
    if (!_bx_didSetupConstraints) {
        [self.bx_baseframeView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0];
        [self.bx_baseframeView autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:0];
        [self.bx_baseframeView autoSetDimensionsToSize:[self orientationStatus] ? CGSizeMake(ScreenHeight, ScreenHeight) : CGSizeMake(ScreenWidth, ScreenWidth)];
        
        [self.bx_baseHeaderView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0];
        [self.bx_baseHeaderView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:0];
        [self.bx_baseHeaderView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:0];
        [self.bx_baseHeaderView autoSetDimension:ALDimensionHeight toSize:40];
        
        [self.bx_baseBackView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:14];
        [self.bx_baseBackView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:14];
        [self.bx_baseBackView autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_baseHeaderView withOffset:14];
        [self.bx_baseBackView autoSetDimension:ALDimensionHeight toSize:40];
        
        [self.bx_leftLabel autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:0];
        [self.bx_leftLabel autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:10];
        [self.bx_leftLabel autoSetDimension:ALDimensionHeight toSize:40];
        
        [self.bx_rightImageView sizeToFit];
        [self.bx_rightImageView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:10];
        [self.bx_rightImageView autoAlignAxis:ALAxisHorizontal toSameAxisOfView:self.bx_leftLabel withOffset:0];
        
        
        _bx_didSetupConstraints = YES;
    }
    [super updateViewConstraints];
}

-(void)backAction:(UIButton *)sender{
    
    [self bx_hideWithCompletion:^{
        
    }];
}

- (void)screenTap:(UITapGestureRecognizer *)gesture {
    CGPoint p = [gesture locationInView:self.view];
    if (!CGRectContainsPoint(self.bx_baseframeView.frame, p)) {
        [self dismissToRootViewController];
    }
}

-(void)dismissToRootViewController{
    UIViewController *vc = self;
    while (vc.presentingViewController) {
        vc = vc.presentingViewController;
    }
    [vc dismissViewControllerAnimated:YES completion:nil];
}

- (void)bx_rightImageViewTap:(UITapGestureRecognizer *)gesture {
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"帐号注销" message:@"游戏账号注销功能需要在您当前游戏角色离线时进行，点击确定后将退出登录并前往账号注销，您确定要退出登录前往注销么?" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        BXMyH5Controller *vc = [[BXMyH5Controller alloc]init];
        vc.bx_urlStr = [BXPrivacyUtil bx_deleteAccountUrl];
        [self presentViewController:vc animated:YES completion:^{
        }];
    }];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
    }];
    [alertController addAction:cancelAction];
    [alertController addAction:okAction];
    [self presentViewController:alertController animated:NO completion:nil];
}

@end
