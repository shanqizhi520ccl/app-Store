//
//  BXRegisterViewController.h
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/21.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXBaseViewController.h"

//NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, BXRegisterType) {
    /// 手机注册
    BXRegisterTypeMobile,
    /// 一键注册
    BXRegisterTypeFast
};


@interface BXRegisterViewController : BXBaseViewController

/// 注册方式
@property (nonatomic, readonly)BXRegisterType registerType;

- (instancetype)initWithRegisterType:(NSInteger)registerType;

@end

//NS_ASSUME_NONNULL_END
