//
//  BXPhoneBindController.m
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/8/27.
//  Copyright © 2021 Gavin. All rights reserved.
//

#import "BXPhoneBindController.h"
#import "BXPrivacyUtil.h"
#import "BXThreeSelectionController.h"
#import "BXConfig.h"
#import "BXEvent.h"
#import "BXMobileManager.h"
#import "BXMobileManager+Private.h"
#import "BXUser.h"

@interface BXPhoneBindController ()
@property (nonatomic, readwrite)BXPhoneType bx_registerType;

@property (nonatomic, strong) BXTextField *bx_phoneTextField;

@property (nonatomic, strong) BXTextField *bx_smscodeTextField;

@property (nonatomic, strong) NSTimer * bx_smscodeTimer;

@property (nonatomic, assign) NSInteger bx_smsCodeCount;

@property (nonatomic, assign) BOOL bx_didSetupConstraints;
@end

@implementation BXPhoneBindController

- (instancetype)initWithType:(NSInteger)bx_registerType {
    self = [super init];
    if (self) {
        self.bx_registerType = bx_registerType;
        
        self.preferredContentSize = [self orientationStatus] ? CGSizeMake(ScreenWidth, ScreenWidth) : CGSizeMake(ScreenWidth, ScreenHeight);
    }
    return self;
}

- (instancetype)init{
    NSException * exp = [NSException exceptionWithName:@"BXMobileSDK" reason:@"call -initWithBindType instead of -init" userInfo:nil];
    @throw exp;
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [self notifitionSatatus];
}

-(void)notifitionSatatus{
    [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(statusBarOrientationChange:) name:UIApplicationDidChangeStatusBarOrientationNotification object:nil];
}
-(void)statusBarOrientationChange:(NSNotification*)notification{
    self.preferredContentSize = [self orientationStatus] ? CGSizeMake(ScreenWidth, ScreenWidth) : CGSizeMake(ScreenWidth, ScreenHeight);
    [self.bx_baseframeView autoSetDimensionsToSize:[self orientationStatus] ? CGSizeMake(ScreenWidth, ScreenWidth) : CGSizeMake(ScreenWidth, ScreenWidth)];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setupViews];
    
    self.view.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(screenTap:)];
    tap.cancelsTouchesInView = NO;
    [self.view addGestureRecognizer:tap];
}

- (void)setupViews {
    self.view.backgroundColor = UIColor.clearColor;
    
    [self.view addSubview:self.bx_baseframeView];
    
    [self.bx_baseframeView addSubview:self.bx_baseHeaderView];
    [self.bx_baseHeaderView bx_baseHeaderViewSetString:self.bx_registerType == BXPhoneTypeMobile ? @"绑定手机" : @"解绑手机"];
    @weakify(self)
    self.bx_baseHeaderView.bx_leftCallback = ^{
        @strongify(self)
        [self backAction:nil];
    };
    
    [self.bx_baseframeView addSubview:self.bx_baseBackView];
    
    [self.bx_baseBackView addSubview:self.bx_phoneTextField];
    [self.bx_baseBackView addSubview:self.bx_smscodeTextField];
    
    [self.bx_baseNextBtn setTitle:self.bx_registerType == BXPhoneTypeMobile ? @"绑定" : @"解除绑定" forState:UIControlStateNormal];
    [self.bx_baseNextBtn addTarget:self action:@selector(bx_baseNextBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.bx_baseframeView addSubview:self.bx_baseNextBtn];
    
    [self.view updateConstraintsIfNeeded];
}

- (void)updateViewConstraints {
    if (!_bx_didSetupConstraints) {
        [self.bx_baseframeView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0];
        [self.bx_baseframeView autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:0];
        [self.bx_baseframeView autoSetDimensionsToSize:[self orientationStatus] ? CGSizeMake(ScreenHeight, ScreenHeight) : CGSizeMake(ScreenWidth, ScreenWidth)];
        
        [self.bx_baseHeaderView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0];
        [self.bx_baseHeaderView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:0];
        [self.bx_baseHeaderView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:0];
        [self.bx_baseHeaderView autoSetDimension:ALDimensionHeight toSize:40];
        
        [self.bx_baseBackView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:14];
        [self.bx_baseBackView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:14];
        [self.bx_baseBackView autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_baseHeaderView withOffset:14];
        [self.bx_baseBackView autoSetDimension:ALDimensionHeight toSize:80];
        
        NSArray *tfs = @[self.bx_phoneTextField, self.bx_smscodeTextField];
        [tfs.firstObject autoPinEdgeToSuperviewEdge:ALEdgeLeading];
        [tfs.firstObject autoPinEdgeToSuperviewEdge:ALEdgeTrailing];
        [tfs autoMatchViewsDimension:ALDimensionWidth];
        [tfs autoDistributeViewsAlongAxis:ALAxisVertical alignedTo:ALAttributeVertical withFixedSpacing:0];
        
        UIView *bx_line = [[UIView alloc] init];
        [bx_line setBackgroundColor:BXHexColor(0xDEDEDE)];
        [self.bx_baseBackView addSubview:bx_line];
        
        [bx_line autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0];
        [bx_line autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:0];
        [bx_line autoPinEdge:ALEdgeBottom toEdge:ALEdgeBottom ofView:self.bx_phoneTextField withOffset:0];
        [bx_line autoSetDimension:ALDimensionHeight toSize:0.5];
        
        [self.bx_baseNextBtn autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:14];
        [self.bx_baseNextBtn autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:14];
        [self.bx_baseNextBtn autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_baseBackView withOffset:14];
        [self.bx_baseNextBtn autoSetDimension:ALDimensionHeight toSize:40];
        
        _bx_didSetupConstraints = YES;
    }
    [super updateViewConstraints];
}

-(void)backAction:(UIButton *)sender{
    [self bx_hideWithCompletion:^{
        
    }];
}

-(void)bx_baseNextBtnAction:(UIButton *)sender{
    [self bingMobileEvent:nil];
}

- (void)bingMobileEvent:(id)sender {
    if (self.bx_phoneTextField.text.length == 0) {
        [BXMBProgressHUD bx_showMessage:@"请输入手机号码"];
        return;
    }
    
    if (![NSString bx_checkValidityForPhoneNumber:self.bx_phoneTextField.text]) {
        [BXMBProgressHUD bx_showMessage:@"请输入正确的11位手机号码"];
        return;
    }
    
    if (self.bx_smscodeTextField.text.length == 0) {
        [BXMBProgressHUD bx_showMessage:@"请输入验证码"];
        return;
    }
    
    if (self.bx_smscodeTextField.text.length <= 3) {
        [BXMBProgressHUD bx_showMessage:@"验证码输入不正确"];
        return;
    }
    
    [self.view endEditing:YES];
    @weakify(self)
    if (self.bx_registerType == BXPhoneTypeMobile) {
        [BXEvent doBindMobile:self.bx_phoneTextField.text msgCode:self.bx_smscodeTextField.text complement:^(id obj, NSError *error) {
            @strongify(self)
            if (!error) {
                [BXMobileManager shareManager].currentUser.phoneNumber = self.bx_phoneTextField.text;
                if (self.btnBlock) {
                    self.btnBlock();
                }
                [self bx_hideWithCompletion:nil];
            }else{
                [BXMBProgressHUD bx_showMessage:error.localizedDescription delay:YES];
            }
        }];
    }else{
        [BXEvent doUnBindPhoneMobile:self.bx_phoneTextField.text msgCode:self.bx_smscodeTextField.text complement:^(id obj, NSError *error) {
            @strongify(self)
            if (!error) {
                [BXMobileManager shareManager].currentUser.phoneNumber = @"";
                if (self.btnBlock) {
                    self.btnBlock();
                }
                [self bx_hideWithCompletion:nil];
            }else{
                [BXMBProgressHUD bx_showMessage:error.localizedDescription delay:YES];
            }
        }];
    }
}

- (void)screenTap:(UITapGestureRecognizer *)gesture {
    if ([self.bx_phoneTextField isFirstResponder] || [self.bx_smscodeTextField isFirstResponder]) {
        [self.view endEditing:YES];
        return;
    }
    
    CGPoint p = [gesture locationInView:self.view];
    if (!CGRectContainsPoint(self.bx_baseframeView.frame, p)) {
        [self dismissToRootViewController];
    }
}

-(void)dismissToRootViewController{
    UIViewController *vc = self;
    while (vc.presentingViewController) {
        vc = vc.presentingViewController;
    }
    [vc dismissViewControllerAnimated:YES completion:nil];
}

- (UITextField *)bx_smscodeTextField {
    if (!_bx_smscodeTextField) {
        _bx_smscodeTextField = [BXTextField textFieldWithTitle:nil placeHolder:@"验证码"];
        _bx_smscodeTextField.backgroundColor = [UIColor whiteColor];
        _bx_smscodeTextField.borderStyle = UITextBorderStyleNone;
        _bx_smscodeTextField.font = BXSystemFont(14);
        _bx_smscodeTextField.textColor = BXHexColor(0x333333);
        _bx_smscodeTextField.keyboardType = UIKeyboardTypeASCIICapable;
        _bx_smscodeTextField.autocorrectionType = UITextAutocorrectionTypeNo;
        _bx_smscodeTextField.autocapitalizationType = UITextAutocapitalizationTypeNone;
        
        @weakify(self)
        BXTextFieldAction *rightAction = [BXTextFieldAction actionWithTitle:@"发送验证码" handler:^(BXTextFieldAction *action) {
            @strongify(self)
            if ([BXPrivacyUtil bx_isNeedShowSendMsgCodePrivacy] == YES && [BXConfig config].grcAuthorityDerail == 1){
                BXThreeSelectionController *selectionVC = [[BXThreeSelectionController alloc] init];
                selectionVC.bx_Status = 1;
                selectionVC.bx_MsgCallback = ^(BOOL flag) {
                    [self sendSmsCodeEvent:action];
                };
                [self presentViewController:selectionVC animated:YES completion:nil];
            }else{
                [self sendSmsCodeEvent:action];
            }
        }];
        
        UIImage *image = [UIImage bx_imageWithColor:BXHexColor(0x388EFF) frame:CGRectMake(0, 0, 72, 24)];
        UIEdgeInsets edgeInsets = UIEdgeInsetsMake(image.size.height * 0.5, image.size.width * 0.5, image.size.height * 0.5, image.size.width * 0.5);
        UIImageResizingMode mode = UIImageResizingModeStretch;
        UIImage *newImage = [image resizableImageWithCapInsets:edgeInsets resizingMode:mode];
        [rightAction.actionButton setBackgroundImage:newImage forState:UIControlStateNormal];
        
        UIImage *disableImage = [UIImage bx_imageWithColor:BXHexColor( 0xDDDDDD) frame:CGRectMake(0, 0, 72, 24)];
        [rightAction.actionButton setBackgroundImage:disableImage forState:UIControlStateDisabled];
         
        [rightAction setEnabled:NO];
        [_bx_smscodeTextField setTrillingActions:@[rightAction]];
        _bx_smscodeTextField.rightViewMode = UITextFieldViewModeAlways;
        
        [[[_bx_smscodeTextField trillingActions] firstObject] setEnabled:self.bx_registerType == BXPhoneTypeReset];
    }
    return _bx_smscodeTextField;
}

- (BXTextField *)bx_phoneTextField {
    if (!_bx_phoneTextField) {
        _bx_phoneTextField = [BXTextField textFieldWithTitle:self.bx_registerType == BXPhoneTypeReset ? [BXMobileManager shareManager].currentUser.phoneNumber : nil placeHolder:@"手机号"];
        _bx_phoneTextField.backgroundColor = [UIColor whiteColor];
        _bx_phoneTextField.borderStyle = UITextBorderStyleNone;
        _bx_phoneTextField.font = BXSystemFont(14);
        _bx_phoneTextField.textColor = BXHexColor(0x333333);
        _bx_phoneTextField.keyboardType = UIKeyboardTypeNumberPad;
        _bx_phoneTextField.autocorrectionType = UITextAutocorrectionTypeNo;
        _bx_phoneTextField.autocapitalizationType = UITextAutocapitalizationTypeNone;
        
        [_bx_phoneTextField addTarget:self action:@selector(accountTextFieldValueChange:) forControlEvents:UIControlEventEditingChanged];
                
    }
    return _bx_phoneTextField;
}

- (void)accountTextFieldValueChange:(UITextField *)tf {
    BOOL result = [NSString bx_checkValidityForPhoneNumber:tf.text];
    [[[self.bx_smscodeTextField trillingActions] firstObject] setEnabled:result];
}

- (void)sendSmsCodeEvent:(id)sender {
    [self.bx_smscodeTextField becomeFirstResponder];
    
    [self clearTimer:sender];
    [self onStartTimer:sender];
    
    [BXEvent bx_doGetSmsCode:self.bx_phoneTextField.text smsType:self.bx_registerType == BXPhoneTypeMobile ? 5 : 13 complement:^(id obj, NSError *error) {
        if (!error) {
            [BXMBProgressHUD bx_showMessage:@"验证码发送成功,请注意查收短信!"];
        }else{
            [BXMBProgressHUD bx_showMessage:error.localizedDescription];
            [self clearTimer:sender];
        }
    }];
}

#pragma mark - Smscode Timer

- (void)clearTimer:(BXTextFieldAction *)action {
    dispatch_async(dispatch_get_main_queue(), ^{
        [action setEnabled:YES];
        [action setActionTitle:@"发送验证码" forState:UIControlStateDisabled];
        if (nil != self.bx_smscodeTimer) {
            [self.bx_smscodeTimer invalidate];
            self.bx_smscodeTimer = nil;
        }
    });
}

- (void)onStartTimer:(BXTextFieldAction *)action {
    dispatch_async(dispatch_get_main_queue(), ^{
        self.bx_smsCodeCount = 60;
        [action setEnabled:NO];
        self.bx_smscodeTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(onTimer:) userInfo:@{@"sender":action} repeats:YES];
        [self.bx_smscodeTimer fire];
    });
}

- (void)onTimer:(NSTimer *)timer {
    self.bx_smsCodeCount--;
    id action = timer.userInfo[@"sender"];
    if (self.bx_smsCodeCount <= 0) {
        [self clearTimer:action];
    } else {
        NSString *message = [NSString stringWithFormat:@"%ld秒后重发", (long)self.bx_smsCodeCount];
        [action setActionTitle:message forState:UIControlStateDisabled];
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
