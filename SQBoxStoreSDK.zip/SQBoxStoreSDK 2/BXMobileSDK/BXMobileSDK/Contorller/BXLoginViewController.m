//
//  BXLoginViewController.m
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/20.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXLoginViewController.h"
#import "BXEvent.h"
#import "BXConfig.h"
#import "TPKeyboardAvoidingScrollView.h"
#import "BXRegisterViewController.h"
#import "BXResetPWDViewController.h"
#import "BXSeviceAndPrivacyViewController.h"
#import "BXNoticeViewController.h"
#import "BXExecuteLoginViewController.h"

#import "BXBindMobileViewController.h"

#import "BXUser.h"
#import "BXSelectorControll.h"
#import "BXAccountHistoryViewController.h"
#import "BXMobileManager+Private.h"

@interface BXLoginViewController ()<BXSelectorControllDelegate, BXAccountHistoryViewControllerDelegate, UITextFieldDelegate>
@property (nonatomic, strong) UIView *bx_navgationBar;
@property (nonatomic, strong) UIImageView *bx_navgationBackgroundImgView;
@property (nonatomic, strong) UILabel *bx_titileLabel;
@property (nonatomic, strong) UIButton *bx_forgotPasswordButton;

@property (nonatomic, strong) BXSelectorControll *aSelectorControll;

@property (nonatomic, strong) TPKeyboardAvoidingScrollView *bx_scrollView;
@property (nonatomic, strong) UIView *bx_textFieldBackgroundView;
@property (nonatomic, strong) BXTextField *bx_accountTextField;
@property (nonatomic, strong) BXTextField *bx_passwordTextField;

@property (nonatomic, strong) UIButton *bx_checkBoxButton;
@property (nonatomic, strong) UILabel *bx_serviceAndPrivacyHeadLabel;
@property (nonatomic, strong) UIButton *bx_serviceButton;
@property (nonatomic, strong) UILabel *bx_serviceAndPrivacyEndLabel;
@property (nonatomic, strong) UIButton *bx_privacyButton;

@property (nonatomic, strong) UIButton *bx_nextButton;
@property (nonatomic, strong) UIButton *bx_registerByPhoneNumberButton;
@property (nonatomic, strong) UIButton *bx_fastRegisterButton;

@property (nonatomic, assign) BOOL bx_didSetupConstraints;
@end

@implementation BXLoginViewController

- (void)dealloc
{
    BXLogInfo(@"%s",__func__);
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        if (!isSmallScreen) {
            self.preferredContentSize = CGSizeMake(BXPreferredContentSize.width, BXPreferredContentSize.height-30);
        }else{
            self.preferredContentSize = CGSizeMake(BXPreferredContentSmallSize.width, BXPreferredContentSmallSize.height-30);
        }
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self setupViews];
    
    // 设置默认登录账号
    NSString *username = [BXUser recordedAccounts].firstObject;
    NSString *password = [BXUser recordedPassword:username];
    
    self.bx_accountTextField.text = username;
    self.bx_passwordTextField.text = password;
    
    //点击背景的时候隐藏掉弹出框
    [[NSNotificationCenter defaultCenter] addObserver:self
                                                selector:@selector(maskViewTappedNotification:)
                                                    name:@"FYLDialogPresentationControllerTapMaskNotification"
                                                  object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
    selector:@selector(registerAppNotification:)
        name:BXRegisterAppSuccessNotification
      object:nil];
    
    [self updateRigisterAccountEnable];
    
    if ([BXUser getAutoLogin]) {
        dispatch_time_t delay = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC));
        dispatch_after(delay, dispatch_get_main_queue(), ^{
            BXExecuteLoginViewController *bx_loginResultController = [[BXExecuteLoginViewController alloc] initWithAccount:self.bx_accountTextField.text password:self.bx_passwordTextField.text fromRegister:NO];
            [self presentViewController:bx_loginResultController animated:YES completion:^{
            }];
        });
    }
}

- (void)registerAppNotification:(NSNotification *)noti {
    [self updateRigisterAccountEnable];
}

- (void)updateRigisterAccountEnable {
    if ([BXConfig config].configState == BXConfigStateSUC) {
        if ([BXConfig config].fastRegister) {
            self.bx_fastRegisterButton.hidden = NO;
        }

        if ([BXConfig config].phoneRegister) {
            self.bx_registerByPhoneNumberButton.hidden = NO;
        }

        if (!(self.bx_fastRegisterButton.hidden) || !(self.bx_registerByPhoneNumberButton.hidden)) {
            if (!isSmallScreen) {
                self.preferredContentSize = CGSizeMake(BXPreferredContentSize.width, BXPreferredContentSize.height);
            }else{
                self.preferredContentSize = CGSizeMake(BXPreferredContentSmallSize.width, BXPreferredContentSmallSize.height);
            }
        }
        
        [[NSNotificationCenter defaultCenter] removeObserver:self name:BXRegisterAppSuccessNotification object:nil];
    }
}

- (void)setupViews {
    // 导航栏
    [self.view addSubview:self.bx_navgationBar];
    [self.bx_navgationBar addSubview:self.bx_navgationBackgroundImgView];
    [self.bx_navgationBar addSubview:self.bx_titileLabel];
    [self.bx_navgationBar addSubview:self.bx_forgotPasswordButton];
    
    [self.view addSubview:self.bx_scrollView];
    [self.bx_scrollView addSubview:self.bx_textFieldBackgroundView];
    [self.bx_textFieldBackgroundView addSubview:self.bx_accountTextField];
    [self.bx_textFieldBackgroundView addSubview:self.bx_passwordTextField];
    
    UIView *lineView = [[UIView alloc] init];
    [lineView setBackgroundColor:BXHexColor(0xDEDEDE)];
    [self.bx_textFieldBackgroundView addSubview:lineView];
    
    [lineView autoCenterInSuperview];
    [lineView autoSetDimension:ALDimensionHeight toSize:0.5];
    [lineView autoMatchDimension:ALDimensionWidth toDimension:ALDimensionWidth ofView:self.bx_textFieldBackgroundView];
    
    [self.bx_scrollView addSubview:self.bx_checkBoxButton];
    [self.bx_scrollView addSubview:self.bx_serviceAndPrivacyHeadLabel];
    [self.bx_scrollView addSubview:self.bx_serviceButton];
    [self.bx_scrollView addSubview:self.bx_serviceAndPrivacyEndLabel];
    [self.bx_scrollView addSubview:self.bx_privacyButton];
    
    [self.bx_scrollView addSubview:self.bx_nextButton];
    [self.bx_scrollView addSubview:self.bx_fastRegisterButton];
    [self.bx_scrollView addSubview:self.bx_registerByPhoneNumberButton];
    
    [self.view addSubview:self.aSelectorControll];
    
    [self.view updateConstraintsIfNeeded];
}

- (void)updateViewConstraints {
    if (!_bx_didSetupConstraints) {
        // 导航栏
        [self.bx_navgationBar autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero excludingEdge:ALEdgeBottom];
        [self.bx_navgationBar autoSetDimension:ALDimensionHeight toSize:40];
        
        [self.bx_navgationBackgroundImgView autoPinEdgesToSuperviewEdges];
        
        [self.bx_titileLabel autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:20];
        [self.bx_titileLabel autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
        
        [self.bx_forgotPasswordButton autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
        [self.bx_forgotPasswordButton autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:20];
        
        // 视图内容
        [self.bx_scrollView  autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero excludingEdge:ALEdgeTop];
        [self.bx_scrollView autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_navgationBar];
        
        // 输入框
        [self.bx_textFieldBackgroundView autoPinEdge:ALEdgeLeading toEdge:ALEdgeLeading ofView:self.view withOffset:20];
        [self.bx_textFieldBackgroundView autoPinEdge:ALEdgeTrailing toEdge:ALEdgeTrailing ofView:self.view withOffset:-20];
        
        [self.bx_textFieldBackgroundView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:5];
        [self.bx_textFieldBackgroundView autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:20];
        [self.bx_textFieldBackgroundView autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:20];
        [self.bx_textFieldBackgroundView autoSetDimension:ALDimensionHeight toSize:40*2];
        
        [self.bx_accountTextField autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero excludingEdge:ALEdgeBottom];
        [self.bx_accountTextField autoSetDimension:ALDimensionHeight toSize:40];
        [self.bx_passwordTextField autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero excludingEdge:ALEdgeTop];
        [self.bx_passwordTextField autoSetDimension:ALDimensionHeight toSize:40];
        [self.bx_passwordTextField autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_accountTextField];
        
        // 服务与协议
        [self.bx_checkBoxButton autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_textFieldBackgroundView withOffset:10];
        [self.bx_checkBoxButton autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:20];
        [self.bx_checkBoxButton autoSetDimensionsToSize:CGSizeMake(14, 14)];
        
        [@[self.bx_checkBoxButton, self.bx_serviceAndPrivacyHeadLabel, self.bx_serviceButton, self.bx_serviceAndPrivacyEndLabel, self.bx_privacyButton] autoAlignViewsToAxis:ALAxisHorizontal];
        [self.bx_serviceAndPrivacyHeadLabel autoPinEdge:ALEdgeLeading toEdge:ALEdgeTrailing ofView:self.bx_checkBoxButton withOffset:5];
        [self.bx_serviceButton autoPinEdge:ALEdgeLeading toEdge:ALEdgeTrailing ofView:self.bx_serviceAndPrivacyHeadLabel withOffset:1];
        [self.bx_serviceAndPrivacyEndLabel autoPinEdge:ALEdgeLeading toEdge:ALEdgeTrailing ofView:self.bx_serviceButton withOffset:1];
        [self.bx_privacyButton autoPinEdge:ALEdgeLeading toEdge:ALEdgeTrailing ofView:self.bx_serviceAndPrivacyEndLabel withOffset:1];
        
        // 登录
        [self.bx_nextButton autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_checkBoxButton withOffset:10];
        [self.bx_nextButton autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:20];
        [self.bx_nextButton autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:20];
        [self.bx_nextButton autoSetDimension:ALDimensionHeight toSize:40];
        
        [self.bx_fastRegisterButton autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_nextButton withOffset:7];
//        [self.bx_fastRegisterButton autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:20];
        [self.bx_fastRegisterButton autoPinEdge:ALEdgeLeading toEdge:ALEdgeLeading ofView:self.bx_nextButton withOffset:0];
//        [self.bx_fastRegisterButton autoPinEdge:ALEdgeTrailing toEdge:ALEdgeTrailing ofView:self.bx_nextButton withOffset:-100];
        
        [self.bx_registerByPhoneNumberButton autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_nextButton withOffset:7];
        [self.bx_registerByPhoneNumberButton autoPinEdgeToSuperviewEdge:ALEdgeBottom];
//        [self.bx_registerByPhoneNumberButton autoPinEdgeToSuperviewEdge:(ALEdgeTrailing) withInset:10];
        [@[self.bx_fastRegisterButton,self.bx_registerByPhoneNumberButton] autoDistributeViewsAlongAxis:ALAxisHorizontal alignedTo:ALAttributeHorizontal withFixedSpacing:20.0 insetSpacing:YES matchedSizes:YES];
        
        [self.aSelectorControll autoPinEdge:ALEdgeTop toEdge:ALEdgeTop ofView:self.bx_passwordTextField];
        [self.aSelectorControll autoPinEdge:ALEdgeLeading toEdge:ALEdgeLeading ofView:self.bx_passwordTextField withOffset:0]; //-MarginLeft+5
        [self.aSelectorControll autoPinEdge:ALEdgeTrailing toEdge:ALEdgeTrailing ofView:self.bx_passwordTextField withOffset:0]; //MarginRight-5
        [self.aSelectorControll autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:10 relation:NSLayoutRelationGreaterThanOrEqual]; //MarginRight-5
        
        [NSLayoutConstraint autoSetPriority:UILayoutPriorityDefaultHigh forConstraints:^{
            self.aSelectorControll.hightConstraint = [self.aSelectorControll autoSetDimension:ALDimensionHeight toSize:0];
        }];
        
        _bx_didSetupConstraints = YES;
    }
    [super updateViewConstraints];
}


#pragma mark - User Response

- (void)loginEvent:(id)sender {
    if (self.bx_accountTextField.text.length == 0) {
        [BXMBProgressHUD bx_showMessage:@"请输入账号或手机号"];
        [self.bx_accountTextField becomeFirstResponder];
        return;
    }
    
    if (![NSString bx_checkValidityForUsername:self.bx_accountTextField.text]) {
        [BXMBProgressHUD bx_showMessage:@"账号格式不正确，请重新输入"];
        [self.bx_accountTextField becomeFirstResponder];
        return;
    }
    
    if (self.bx_passwordTextField.text.length == 0) {
        [BXMBProgressHUD bx_showMessage:@"请输入密码，密码为6-20位字符"];
        [self.bx_passwordTextField becomeFirstResponder];
        return;
    }
    
    if (![NSString bx_checkValidityForPassword:self.bx_passwordTextField.text]) {
        [BXMBProgressHUD bx_showMessage:@"密码输入不正确，请输入6-20位"];
        [self.bx_passwordTextField becomeFirstResponder];
        return;
    }
    
    if (!self.bx_checkBoxButton.selected) {
        [BXMBProgressHUD bx_showMessage:@"请先仔细阅读并同意《用户注册服务协议》与《隐私政策》"];
        return;
    }
    
    [self.view endEditing:YES];

    BXExecuteLoginViewController *bx_loginResultController = [[BXExecuteLoginViewController alloc] initWithAccount:self.bx_accountTextField.text password:self.bx_passwordTextField.text fromRegister:NO];
    [self presentViewController:bx_loginResultController animated:YES completion:^{
    }];
}

- (void)registerEvent:(id)sender {
    UIButton *btn = (UIButton *)sender;
    NSInteger registerType = BXRegisterTypeMobile;
    switch (btn.tag) {
        case 100001:
            registerType = BXRegisterTypeMobile;
            break;
        case 100002:
            registerType = BXRegisterTypeFast;
            break;
    }
    BXRegisterViewController *registerController = [[BXRegisterViewController alloc]  initWithRegisterType:registerType];
    [self presentViewController:registerController animated:YES completion:^{
    }];
}

- (void)forgotPasswordEvent:(id)sender  {
    BXResetPWDViewController *resetPasswordController = [[BXResetPWDViewController alloc] init];
    [self presentViewController:resetPasswordController animated:YES completion:^{
    }];
}

- (void)agreementEvent:(id)sender {
    UIButton *button = (UIButton *)sender;
    button.selected = !button.selected;
}

- (void)showServiceAgreementEvent:(id)sender {
    if ([BXConfig config].configState != BXConfigStateSUC) {
        return;
    }
    NSString *bx_serviceAgreementUrl = [NSString stringWithFormat:@"%@agree/%@_appstore/user_protocol.html", [BXConfig config].cdnImgServer, [BXConfig config].platformId];
    BXLogInfo(@"bxm_serviceAgreementUrl = %@", bx_serviceAgreementUrl);
    BXSeviceAndPrivacyViewController *bx_seviceAndPrivacyController = [[BXSeviceAndPrivacyViewController alloc] initWithUrl:[NSURL URLWithString:bx_serviceAgreementUrl] pageType:BXPageType_UserPrivate];
    [self presentViewController:bx_seviceAndPrivacyController animated:YES completion:^{
    }];
}

- (void)showPrivacyPolicyEvent:(id)sender {
    if ([BXConfig config].configState != BXConfigStateSUC) {
        return;
    }
    NSString *bx_privacyPolicyUrl = [NSString stringWithFormat:@"%@agree/%@_appstore/privacy_policy_transparent_black_text.html", [BXConfig config].cdnImgServer, [BXConfig config].platformId];
    BXLogInfo(@"bxm_serviceAgreementUrl = %@", bx_privacyPolicyUrl);
    BXSeviceAndPrivacyViewController *bx_seviceAndPrivacyController = [[BXSeviceAndPrivacyViewController alloc] initWithUrl:[NSURL URLWithString:bx_privacyPolicyUrl] pageType:BXPageType_UserPrivate];
    [self presentViewController:bx_seviceAndPrivacyController animated:YES completion:^{
    }];
}

- (void)maskViewTappedNotification:(id)noti {
    BXTextFieldAction *action = self.bx_accountTextField.trillingActions.lastObject;
    if (action.actionButton.selected) {
        [action.actionButton sendActionsForControlEvents:UIControlEventTouchUpInside];
    }
}

- (void)showAccountList:(BOOL)isShowing {
    if (isShowing) {
        [self.aSelectorControll showing];
    }else{
        [self.aSelectorControll dismissing];
    }
    [self hiddenViewForAccountList:isShowing];
}

- (void)hiddenViewForAccountList:(BOOL)isShowing {
    self.bx_forgotPasswordButton.hidden = isShowing;
//    self.bx_textFieldBackgroundView.hidden = isShowing;
    self.bx_checkBoxButton.hidden = isShowing;
    self.bx_serviceAndPrivacyHeadLabel.hidden = isShowing;
    self.bx_serviceAndPrivacyEndLabel.hidden = isShowing;
    self.bx_serviceButton.hidden = isShowing;
    self.bx_privacyButton.hidden = isShowing;
    self.bx_nextButton.hidden = isShowing;
    self.bx_registerByPhoneNumberButton.hidden = isShowing;
    self.bx_fastRegisterButton.hidden = isShowing;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    BXTextFieldAction *action = self.bx_accountTextField.trillingActions.lastObject;
    if (action.actionButton.selected) {
        [action.actionButton sendActionsForControlEvents:UIControlEventTouchUpInside];
    }
    return YES;
}

#pragma mark - Property

//nav
- (UIView *)bx_navgationBar {
    if (!_bx_navgationBar) {
        _bx_navgationBar = [[UIView alloc] init];
    }
    return _bx_navgationBar;
}

- (UILabel *)bx_titileLabel {
    if (!_bx_titileLabel) {
        _bx_titileLabel = [[UILabel alloc] init];
        [_bx_titileLabel setText:@"用户登录"];
        [_bx_titileLabel setTextColor:BXHexColor(0x333333)];
        [_bx_titileLabel setFont:BXBoldSystemFont(14)];
    }
    return _bx_titileLabel;
}

- (UIImageView *)bx_navgationBackgroundImgView {
    if (!_bx_navgationBackgroundImgView) {
 
        _bx_navgationBackgroundImgView = [[UIImageView alloc] init];
        _bx_navgationBackgroundImgView.backgroundColor = [UIColor whiteColor];
    }
    return _bx_navgationBackgroundImgView;
}

- (TPKeyboardAvoidingScrollView *)bx_scrollView {
    if (!_bx_scrollView) {
        _bx_scrollView = [[TPKeyboardAvoidingScrollView alloc] init];
        _bx_scrollView.delaysContentTouches = NO;
        _bx_scrollView.backgroundColor  = [UIColor clearColor];
    }
    return _bx_scrollView;
}

- (UIView *)bx_textFieldBackgroundView {
    if (!_bx_textFieldBackgroundView) {
        _bx_textFieldBackgroundView = [[UIView alloc] init];
        _bx_textFieldBackgroundView.backgroundColor  = BXTextFieldBackgroundColor;
        _bx_textFieldBackgroundView.layer.cornerRadius = 4;
        _bx_textFieldBackgroundView.clipsToBounds = YES;
    }
    return _bx_textFieldBackgroundView;
}

- (UIButton *)bx_forgotPasswordButton {
    if (!_bx_forgotPasswordButton) {
        _bx_forgotPasswordButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_bx_forgotPasswordButton setTitle:@"忘记密码?" forState:UIControlStateNormal];
        [_bx_forgotPasswordButton setTitleColor:BXHexColor(0x333333 ) forState:UIControlStateNormal];
        _bx_forgotPasswordButton.titleLabel.font = BXSystemFont(12);
        [_bx_forgotPasswordButton addTarget:self action:@selector(forgotPasswordEvent:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _bx_forgotPasswordButton;
}

- (BXTextField *)bx_accountTextField {
    if (!_bx_accountTextField) {
        _bx_accountTextField = [BXTextField textFieldWithTitle:nil placeHolder:@"账号/手机号"];
        _bx_accountTextField.backgroundColor = [UIColor clearColor];
        _bx_accountTextField.borderStyle = UITextBorderStyleNone;
        _bx_accountTextField.font = BXSystemFont(14);
        _bx_accountTextField.textColor = BXTextFieldTextColor;
        _bx_accountTextField.keyboardType = UIKeyboardTypeASCIICapable;
        _bx_accountTextField.autocorrectionType = UITextAutocorrectionTypeNo;
        _bx_accountTextField.autocapitalizationType = UITextAutocapitalizationTypeNone;

//        BXTextFieldAction *leftAction = [BXTextFieldAction actionWithImage:@"tf_account" handler:NULL];
//        [_bx_accountTextField setLeddingActions:@[leftAction]];
        
        @weakify(self)
        BXTextFieldAction *rightAction = [BXTextFieldAction actionWithImage:@"tf_arrow_down" selectedImage:@"tf_arrow_up" handler:^(BXTextFieldAction * _Nonnull action) {
            @strongify(self)
            [self.view endEditing:YES];
            
            action.actionButton.selected = !action.actionButton.selected;
            [self showAccountList:action.actionButton.selected];
        }];
        [_bx_accountTextField setTrillingActions:@[rightAction]];
        _bx_accountTextField.rightViewMode = UITextFieldViewModeAlways;
    }
    return _bx_accountTextField;
}

- (UITextField *)bx_passwordTextField {
    if (!_bx_passwordTextField) {
        _bx_passwordTextField = [BXTextField textFieldWithTitle:nil placeHolder:@"密码"];
        _bx_passwordTextField.backgroundColor = [UIColor clearColor];
        _bx_passwordTextField.borderStyle = UITextBorderStyleNone;
        _bx_passwordTextField.font = BXSystemFont(14);
        _bx_passwordTextField.textColor = BXTextFieldTextColor;
        _bx_passwordTextField.keyboardType = UIKeyboardTypeASCIICapable;
        _bx_passwordTextField.autocorrectionType = UITextAutocorrectionTypeNo;
        _bx_passwordTextField.autocapitalizationType = UITextAutocapitalizationTypeNone;
        _bx_passwordTextField.clearsOnBeginEditing = YES;
        _bx_passwordTextField.secureTextEntry = YES;
                
        @weakify(self)
        BXTextFieldAction *rightAction = [BXTextFieldAction actionWithImage:@"tf_unsecrity" selectedImage:@"tf_secrity" handler:^(BXTextFieldAction * _Nonnull action) {
            @strongify(self)
            self.bx_passwordTextField.secureTextEntry = !self.bx_passwordTextField.secureTextEntry;
            action.actionButton.selected = !action.actionButton.selected;
        }];
        [_bx_passwordTextField setTrillingActions:@[rightAction]];
        _bx_passwordTextField.rightViewMode = UITextFieldViewModeAlways;
    }
    return _bx_passwordTextField;
}

- (UIButton  *)bx_checkBoxButton {
    if (!_bx_checkBoxButton) {
        UIButton *bx_button = [UIButton buttonWithType:UIButtonTypeCustom];
        UIImage *slectedImage = [UIImage imageNamed:@"btn_check_box_selected" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
        UIImage *normalImage = [UIImage imageNamed:@"btn_check_box_unselected" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
        [bx_button setImage:normalImage forState:UIControlStateNormal];
        [bx_button setImage:slectedImage forState:UIControlStateSelected];
        [bx_button addTarget:self action:@selector(agreementEvent:) forControlEvents:UIControlEventTouchUpInside];
        bx_button.selected = YES;
        _bx_checkBoxButton = bx_button;
    }
    return _bx_checkBoxButton;
}

- (UILabel *)bx_serviceAndPrivacyHeadLabel {
    if (!_bx_serviceAndPrivacyHeadLabel) {
        _bx_serviceAndPrivacyHeadLabel = [[UILabel alloc] init];
        [_bx_serviceAndPrivacyHeadLabel setText:isSmallScreen ? @"阅读并同意" : @"您已阅读并同意"];
        [_bx_serviceAndPrivacyHeadLabel setTextColor:BXHexColor(0x333333)];
        [_bx_serviceAndPrivacyHeadLabel setFont:BXSystemFont(12)];
    }
    return _bx_serviceAndPrivacyHeadLabel;
}

- (UIButton *)bx_serviceButton {
    if (!_bx_serviceButton) {
        _bx_serviceButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_bx_serviceButton setTitle:@"用户注册服务协议" forState:UIControlStateNormal];
        [_bx_serviceButton setTitleColor:BXHexColor(0x388EFF) forState:UIControlStateNormal];
        _bx_serviceButton.titleLabel.font = BXSystemFont(12);
        [_bx_serviceButton addTarget:self action:@selector(showServiceAgreementEvent:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _bx_serviceButton;
}

- (UILabel *)bx_serviceAndPrivacyEndLabel {
    if (!_bx_serviceAndPrivacyEndLabel) {
        _bx_serviceAndPrivacyEndLabel = [[UILabel alloc] init];
        [_bx_serviceAndPrivacyEndLabel setText:@"和"];
        [_bx_serviceAndPrivacyEndLabel setTextColor:BXHexColor(0x333333)];
        [_bx_serviceAndPrivacyEndLabel setFont:BXSystemFont(12)];
    }
    return _bx_serviceAndPrivacyEndLabel;
}

- (UIButton *)bx_privacyButton {
    if (!_bx_privacyButton) {
        _bx_privacyButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_bx_privacyButton setTitle:@"隐私政策" forState:UIControlStateNormal];
        [_bx_privacyButton setTitleColor:BXHexColor(0x388EFF) forState:UIControlStateNormal];
        _bx_privacyButton.titleLabel.font = BXSystemFont(12);
        [_bx_privacyButton addTarget:self action:@selector(showPrivacyPolicyEvent:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _bx_privacyButton;
}

- (UIButton *)bx_nextButton {
    if (!_bx_nextButton) {
        UIButton *bx_button = [UIButton buttonWithType:UIButtonTypeCustom];
        [bx_button setTitle:@"进入游戏" forState:UIControlStateNormal];
        [bx_button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        UIImage *aImage = [UIImage imageNamed:@"bxm_Anniu" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
        [bx_button setBackgroundImage:aImage forState:UIControlStateNormal];
        [bx_button addTarget:self action:@selector(loginEvent:) forControlEvents:UIControlEventTouchUpInside];

        
        _bx_nextButton = bx_button;
    }
    return _bx_nextButton;
}

- (UIButton *)bx_registerByPhoneNumberButton {
    if (!_bx_registerByPhoneNumberButton) {
        UIButton *bx_button = [UIButton buttonWithType:UIButtonTypeCustom];
        [bx_button setTitle:@"手机注册" forState:UIControlStateNormal];
        [bx_button setTitleColor:BXHexColor(0x388EFF) forState:UIControlStateNormal];
        [bx_button addTarget:self action:@selector(registerEvent:) forControlEvents:UIControlEventTouchUpInside];
        [bx_button.titleLabel setFont:BXSystemFont(15)];
        bx_button.tag = 100001;
        bx_button.layer.borderColor = BXHexColor(0x388EFF).CGColor;
        bx_button.layer.borderWidth = 0.5;
        bx_button.layer.cornerRadius = 4;
        bx_button.layer.masksToBounds =YES;
        _bx_registerByPhoneNumberButton = bx_button;
        _bx_registerByPhoneNumberButton.hidden = YES;
    }
    return _bx_registerByPhoneNumberButton;
}

- (UIButton *)bx_fastRegisterButton {
    if (!_bx_fastRegisterButton) {
        UIButton *bx_button = [UIButton buttonWithType:UIButtonTypeCustom];
        [bx_button setTitle:@"一键注册" forState:UIControlStateNormal];
        [bx_button setTitleColor:BXHexColor(0x388EFF) forState:UIControlStateNormal];
        [bx_button addTarget:self action:@selector(registerEvent:) forControlEvents:UIControlEventTouchUpInside];
        [bx_button.titleLabel setFont:BXSystemFont(15)];
        bx_button.tag = 100002;
        bx_button.layer.borderColor = BXHexColor(0x388EFF).CGColor;
        bx_button.layer.borderWidth = 0.5;
        bx_button.layer.cornerRadius = 4;
        bx_button.layer.masksToBounds =YES;
        _bx_fastRegisterButton = bx_button;
        _bx_fastRegisterButton.hidden = YES;
    }
    return _bx_fastRegisterButton;
}

- (BXSelectorControll *)aSelectorControll {
    if (!_aSelectorControll) {
        _aSelectorControll = [[BXSelectorControll alloc] initWithDelegate:self];
        _aSelectorControll.hidden = YES;
    }
    return _aSelectorControll;
}

#pragma mark -

- (NSArray<NSString *> *)titlesForRowsInSelectorView {
    return [BXUser recordedAccounts];
}

- (NSString *)hilightText {
    return self.bx_accountTextField.text;
}

- (void)didSelectRowAtIndexPath:(NSIndexPath *)indexPath withTitle:(NSString *)title {
    if ([title isEqualToString:@"历史账号"]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            BXAccountHistoryViewController *vc = [[BXAccountHistoryViewController alloc] init];
            vc.delegate = self;
            [self presentViewController:vc animated:YES completion:^{
            }];
        });
    }else{
        // 设置登录账号和密码
        self.bx_accountTextField.text = title;
        self.bx_passwordTextField.text = [BXUser recordedPassword:title];
        
        // 同步列表显示按钮的选中状态
        BXTextFieldAction *action = self.bx_accountTextField.trillingActions.lastObject;
        [action.actionButton sendActionsForControlEvents:UIControlEventTouchUpInside];
    }
}

- (void)selectorView:(BXSelectorControll *)view accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath withTitle:(NSString *)title {
    // 移除列表中记录密码
    if ([title isEqualToString:self.bx_accountTextField.text]) {
        self.bx_accountTextField.text = nil;
        self.bx_passwordTextField.text = nil;
    }

    [BXUser removeRecordedAccountAndPassword:title];

    // 同步列表显示按钮的选中状态
    if (view.hightConstraint.constant == 0) {
        BXTextFieldAction *action = self.bx_accountTextField.trillingActions.lastObject;
        [action.actionButton sendActionsForControlEvents:UIControlEventTouchUpInside];
    }
}

- (void)didSelectItem:(BXUser *)item {
    // 设置登录账号和密码
    self.bx_accountTextField.text = item.userName;
    self.bx_passwordTextField.text = [BXUser recordedPassword:item.userName];
    
    // 同步列表显示按钮的选中状态
    BXTextFieldAction *action = self.bx_accountTextField.trillingActions.lastObject;
    [action.actionButton sendActionsForControlEvents:UIControlEventTouchUpInside];
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
     BXTextFieldAction *action = self.bx_accountTextField.trillingActions.lastObject;
     if (action.actionButton.selected) {
         [action.actionButton sendActionsForControlEvents:UIControlEventTouchUpInside];
     }
    [super touchesEnded:touches withEvent:event];
}

@end
