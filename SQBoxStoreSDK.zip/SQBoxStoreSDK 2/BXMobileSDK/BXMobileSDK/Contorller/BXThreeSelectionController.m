//
//  BXThreeSelectionController.m
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/8/23.
//  Copyright © 2021 Gavin. All rights reserved.
//

#import "BXThreeSelectionController.h"
#import "BXConfig.h"
#import "BXPrivacyUtil.h"

@interface BXThreeSelectionController ()

@property (nonatomic, strong) BXThreeSelectionView *bx_selectionView;

@property (nonatomic, assign) BOOL bx_didSetupConstraints;

@end

@implementation BXThreeSelectionController

- (void)dealloc
{
    BXLogInfo(@"%s",__func__);
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

- (void)viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];
    
    if (self.bx_Status == bx_msgCodePrivacy) {
        self.preferredContentSize = CGSizeMake(338, 210);
    }else{
        self.preferredContentSize = CGSizeMake(338, 250);
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setupViews];
}

- (void)setupViews {
    [self.view addSubview:self.bx_selectionView];
    
    @weakify(self)
    self.bx_selectionView.bx_eventCallback = ^(BOOL flag) {
        @strongify(self)
        if (self.bx_Status == bx_msgCodePrivacy) {
            if (flag == false) {
                [BXMBProgressHUD bx_showMessage:@"请同意短信授权"];
            }else{
                self.bx_MsgCallback(true);
            }
            [self backEvent:nil];
            return;
        }
        [self bx_hideWithCompletion:^{
            if (self.bx_DeviceCallback) {
                self.bx_DeviceCallback();
            }
        }];
    };
    
    [self.view updateConstraintsIfNeeded];
}

- (void)updateViewConstraints {
    if (!_bx_didSetupConstraints) {
        
        [self.bx_selectionView autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero];
        
        _bx_didSetupConstraints = YES;
    }
    [super updateViewConstraints];
}

- (void)backEvent:(id)sender {
    [self bx_hideWithCompletion:^{
    }];
}

- (BXThreeSelectionView *)bx_selectionView {
    if (!_bx_selectionView) {
        _bx_selectionView = [[BXThreeSelectionView alloc] init];
        _bx_selectionView.bx_Status = _bx_Status;
        if (_bx_Status == bx_devicePrivacy){
            _bx_selectionView.bx_titleLabel.attributedText = [BXPrivacyUtil bx_changeAttributedString:[BXConfig config].grcDeviceInfo];
        }else{
            _bx_selectionView.bx_titleLabel.attributedText = [BXPrivacyUtil bx_changeAttributedString:[BXConfig config].grcDevicePermissions];
        }
    }
    return _bx_selectionView;
}

@end
