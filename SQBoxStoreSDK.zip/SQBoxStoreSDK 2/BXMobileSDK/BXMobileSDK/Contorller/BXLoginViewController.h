//
//  BXLoginViewController.h
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/20.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXBaseViewController.h"

//NS_ASSUME_NONNULL_BEGIN

@interface BXLoginViewController : BXBaseViewController

@end

//NS_ASSUME_NONNULL_END
