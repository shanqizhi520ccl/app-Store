//
//  BXNoticeViewController.h
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/24.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface BXNoticeViewController : BXBaseViewController

- (instancetype)initWithNotifies:(NSArray *)notifies;

@end

NS_ASSUME_NONNULL_END
