//
//  BXBindMobileViewController.m
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/24.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXBindMobileViewController.h"
#import "TPKeyboardAvoidingScrollView.h"
#import "BXIdAuthViewController.h"
#import "BXNoticeViewController.h"
#import "BXMobileManager+Private.h"
#import "BXEvent.h"
#import "BXUser.h"
#import "BXConfig.h"

#import "BXThreeSelectionController.h"
#import "BXPrivacyUtil.h"

@interface BXBindMobileViewController ()
@property (nonatomic, strong) UIView *bx_navgationBar;
@property (nonatomic, strong) UIImageView *bx_navgationBackgroundImgView;
@property (nonatomic, strong) UILabel *bx_titileLabel;
@property (nonatomic, strong) UIButton *bx_closeButton;

@property (nonatomic, strong) TPKeyboardAvoidingScrollView *bx_scrollView;

@property (nonatomic, strong) UIView *bx_textFieldBackgroundView;
@property (nonatomic, strong) BXTextField *bx_accountTextField;
@property (nonatomic, strong) BXTextField *bx_smscodeTextField;

@property (nonatomic, strong) UIButton *bx_nextButton;

@property (nonatomic, strong) NSTimer * smscodeTimer;
@property (nonatomic, assign) NSInteger smsCodeCount;

@property (nonatomic, assign) BOOL bx_didSetupConstraints;
@end

@implementation BXBindMobileViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    if (!isSmallScreen) {
        self.preferredContentSize = CGSizeMake(338, 195);
    }else{
        self.preferredContentSize = CGSizeMake(280, 195);
    }
    
    [self setupViews];
}

- (void)setupViews {
    [self.view addSubview:self.bx_navgationBar];
    [self.bx_navgationBar addSubview:self.bx_navgationBackgroundImgView];
    [self.bx_navgationBar addSubview:self.bx_titileLabel];
    [self.bx_navgationBar addSubview:self.bx_closeButton];
    
    [self.view addSubview:self.bx_scrollView];
    [self.bx_scrollView addSubview:self.bx_textFieldBackgroundView];
    [self.bx_textFieldBackgroundView addSubview:self.bx_accountTextField];
    [self.bx_textFieldBackgroundView addSubview:self.bx_smscodeTextField];
    
    UIView *lineView = [[UIView alloc] init];
    [lineView setBackgroundColor:BXHexColor(0xFFFFFF)];
    [self.bx_textFieldBackgroundView addSubview:lineView];
    
    [lineView autoCenterInSuperview];
    [lineView autoSetDimension:ALDimensionHeight toSize:1];
    [lineView autoMatchDimension:ALDimensionWidth toDimension:ALDimensionWidth ofView:self.bx_textFieldBackgroundView];

    [self.bx_scrollView addSubview:self.bx_nextButton];
    
    [self.view updateConstraintsIfNeeded];
}

- (void)updateViewConstraints {
    if (!_bx_didSetupConstraints) {
        // 导航栏
        [self.bx_navgationBar autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero excludingEdge:ALEdgeBottom];
        [self.bx_navgationBar autoSetDimension:ALDimensionHeight toSize:40];
        
        [self.bx_navgationBackgroundImgView autoPinEdgesToSuperviewEdges];
        
        [self.bx_closeButton autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:20];
        [self.bx_closeButton autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
        
        [self.bx_titileLabel autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:20];
        [self.bx_titileLabel autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
        
        // content
        [self.bx_scrollView autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero excludingEdge:ALEdgeTop];
        [self.bx_scrollView autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_navgationBar];
        
        // 输入框
        [self.bx_textFieldBackgroundView autoPinEdge:ALEdgeLeading toEdge:ALEdgeLeading ofView:self.view withOffset:20];
        [self.bx_textFieldBackgroundView autoPinEdge:ALEdgeTrailing toEdge:ALEdgeTrailing ofView:self.view withOffset:-20];
        
        [self.bx_textFieldBackgroundView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:10];
        [self.bx_textFieldBackgroundView autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:20];
        [self.bx_textFieldBackgroundView autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:20];
        [self.bx_textFieldBackgroundView autoSetDimension:ALDimensionHeight toSize:40*2];
    
        NSArray *tfs = @[self.bx_accountTextField, self.bx_smscodeTextField];
        [tfs.firstObject autoPinEdgeToSuperviewEdge:ALEdgeLeading];
        [tfs.firstObject autoPinEdgeToSuperviewEdge:ALEdgeTrailing];
        [tfs autoMatchViewsDimension:ALDimensionWidth];
        [tfs autoDistributeViewsAlongAxis:ALAxisVertical alignedTo:ALAttributeVertical withFixedSpacing:0];
        
        [self.bx_nextButton autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_textFieldBackgroundView withOffset:10];
        [self.bx_nextButton autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:20];
        [self.bx_nextButton autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:20];
        [self.bx_nextButton autoSetDimension:ALDimensionHeight toSize:40];
        [self.bx_nextButton autoPinEdgeToSuperviewEdge:ALEdgeBottom];
        
        _bx_didSetupConstraints = YES;
    }
    [super updateViewConstraints];
}

- (void)closeEvent:(id)sender {
    [self checkAuthorizeCompletionAndDissmiss];
}

- (void)sendSmsCodeEvent:(id)sender {
    [self.bx_smscodeTextField becomeFirstResponder];
    
    [self clearTimer:sender];
    [self onStartTimer:sender];
    
    [BXEvent bx_doGetSmsCode:self.bx_accountTextField.text smsType:5 complement:^(id obj, NSError *error) {
        if (!error) {
            [BXMBProgressHUD bx_showMessage:@"验证码发送成功,请注意查收短信!"];
        }else{
            [BXMBProgressHUD bx_showMessage:error.localizedDescription];
            [self clearTimer:sender];
        }
    }];
}

- (void)bingMobileEvent:(id)sender {
    if (self.bx_accountTextField.text.length == 0) {
        [BXMBProgressHUD bx_showMessage:@"请输入手机号码"];
        return;
    }
    
    if (![NSString bx_checkValidityForPhoneNumber:self.bx_accountTextField.text]) {
        [BXMBProgressHUD bx_showMessage:@"请输入正确的11位手机号码"];
        return;
    }
    
    if (self.bx_smscodeTextField.text.length == 0) {
        [BXMBProgressHUD bx_showMessage:@"请输入验证码"];
        return;
    }
    
    if (self.bx_smscodeTextField.text.length <= 3) {
        [BXMBProgressHUD bx_showMessage:@"验证码输入不正确"];
        return;
    }
    
    [self.view endEditing:YES];
    
    [BXEvent doBindMobile:self.bx_accountTextField.text msgCode:self.bx_smscodeTextField.text complement:^(id obj, NSError *error) {
        if (!error) {
            [self checkAuthorizeCompletionAndDissmiss];
        }else{
            [BXMBProgressHUD bx_showMessage:error.localizedDescription delay:YES];
        }
    }];
}

- (void)accountTextFieldValueChange:(UITextField *)tf {
    BOOL result = [NSString bx_checkValidityForPhoneNumber:tf.text];
    [[[self.bx_accountTextField trillingActions] firstObject] setEnabled:result];
}

#pragma mark - Smscode Timer

- (void)clearTimer:(BXTextFieldAction *)action {
    dispatch_async(dispatch_get_main_queue(), ^{
        [action setEnabled:YES];
        [action setActionTitle:@"发送验证码" forState:UIControlStateDisabled];
        if (nil != self.smscodeTimer) {
            [self.smscodeTimer invalidate];
            self.smscodeTimer = nil;
        }
    });
}

- (void)onStartTimer:(BXTextFieldAction *)action {
    dispatch_async(dispatch_get_main_queue(), ^{
        self.smsCodeCount = 60;
        [action setEnabled:NO];
        self.smscodeTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(onTimer:) userInfo:@{@"sender":action} repeats:YES];
        [self.smscodeTimer fire];
    });
}

- (void)onTimer:(NSTimer *)timer {
    self.smsCodeCount--;
    id action = timer.userInfo[@"sender"];
    if (self.smsCodeCount <= 0) {
        [self clearTimer:action];
    } else {
        NSString *message = [NSString stringWithFormat:@"%ld秒后重发", (long)self.smsCodeCount];
        [action setActionTitle:message forState:UIControlStateDisabled];
    }
}

#pragma mark - Property

//nav
- (UIView *)bx_navgationBar {
    if (!_bx_navgationBar) {
        _bx_navgationBar = [[UIView alloc] init];
    }
    return _bx_navgationBar;
}

- (UIButton *)bx_closeButton {
    if (!_bx_closeButton) {
        _bx_closeButton = [UIButton buttonWithType:UIButtonTypeCustom];
        UIImage *aImage = [UIImage imageNamed:@"nav_close_black" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
        [_bx_closeButton setImage:aImage forState:UIControlStateNormal];
        [_bx_closeButton addTarget:self action:@selector(closeEvent:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _bx_closeButton;
}

- (UILabel *)bx_titileLabel {
    if (!_bx_titileLabel) {
        _bx_titileLabel = [[UILabel alloc] init];
        [_bx_titileLabel setText:@"绑定手机"];
        [_bx_titileLabel setTextColor:BXHexColor(0x333333)];
        [_bx_titileLabel setFont:BXBoldSystemFont(14)];
    }
    return _bx_titileLabel;
}

- (UIImageView *)bx_navgationBackgroundImgView {
    if (!_bx_navgationBackgroundImgView) {
        _bx_navgationBackgroundImgView = [[UIImageView alloc] init];
    }
    return _bx_navgationBackgroundImgView;
}

- (TPKeyboardAvoidingScrollView *)bx_scrollView {
    if (!_bx_scrollView) {
        _bx_scrollView = [[TPKeyboardAvoidingScrollView alloc] init];
        _bx_scrollView.delaysContentTouches = NO;
        _bx_scrollView.backgroundColor  = [UIColor clearColor];
    }
    return _bx_scrollView;
}

- (UIView *)bx_textFieldBackgroundView {
    if (!_bx_textFieldBackgroundView) {
        _bx_textFieldBackgroundView = [[UIView alloc] init];
        _bx_textFieldBackgroundView.backgroundColor  = BXTextFieldBackgroundColor;
        _bx_textFieldBackgroundView.layer.cornerRadius = 4;
    }
    return _bx_textFieldBackgroundView;
}

- (BXTextField *)bx_accountTextField {
    if (!_bx_accountTextField) {
        _bx_accountTextField = [BXTextField textFieldWithTitle:nil placeHolder:@"手机号"];
        _bx_accountTextField.backgroundColor = [UIColor clearColor];
        _bx_accountTextField.borderStyle = UITextBorderStyleNone;
        _bx_accountTextField.font = BXSystemFont(14);
        _bx_accountTextField.textColor = BXTextFieldTextColor;
        _bx_accountTextField.keyboardType = UIKeyboardTypeASCIICapable;
        _bx_accountTextField.autocorrectionType = UITextAutocorrectionTypeNo;
        _bx_accountTextField.autocapitalizationType = UITextAutocapitalizationTypeNone;
                
        @weakify(self)
        BXTextFieldAction *rightAction = [BXTextFieldAction actionWithTitle:@"发送验证码" handler:^(BXTextFieldAction *action) {
            @strongify(self)
            if ([BXPrivacyUtil bx_isNeedShowSendMsgCodePrivacy] == YES && [BXConfig config].grcAuthorityDerail == 1){
                BXThreeSelectionController *selectionVC = [[BXThreeSelectionController alloc] init];
                selectionVC.bx_Status = 1;
                selectionVC.bx_MsgCallback = ^(BOOL flag) {
                    [self sendSmsCodeEvent:action];
                };
                [self presentViewController:selectionVC animated:YES completion:nil];
            }else{
                [self sendSmsCodeEvent:action];
            }
        }];
        
        UIImage *image = [UIImage bx_imageWithColor:BXHexColor(0x388EFF) frame:CGRectMake(0, 0, 72, 24)];
        UIEdgeInsets edgeInsets = UIEdgeInsetsMake(image.size.height * 0.5, image.size.width * 0.5, image.size.height * 0.5, image.size.width * 0.5);
        UIImageResizingMode mode = UIImageResizingModeStretch;
        UIImage *newImage = [image resizableImageWithCapInsets:edgeInsets resizingMode:mode];
        [rightAction.actionButton setBackgroundImage:newImage forState:UIControlStateNormal];
        
        UIImage *disableImage = [UIImage bx_imageWithColor:BXHexColor( 0xDDDDDD) frame:CGRectMake(0, 0, 72, 24)];
        [rightAction.actionButton setBackgroundImage:disableImage forState:UIControlStateDisabled];
         
        [rightAction setEnabled:NO];
        [_bx_accountTextField setTrillingActions:@[rightAction]];
        
        _bx_accountTextField.keyboardType = UIKeyboardTypeNumberPad;
        _bx_accountTextField.rightViewMode = UITextFieldViewModeAlways;
        [_bx_accountTextField addTarget:self action:@selector(accountTextFieldValueChange:) forControlEvents:UIControlEventEditingChanged];;
    }
    return _bx_accountTextField;
}

- (UITextField *)bx_smscodeTextField {
    if (!_bx_smscodeTextField) {
        _bx_smscodeTextField = [BXTextField textFieldWithTitle:nil placeHolder:@"验证码"];
        _bx_smscodeTextField.backgroundColor = [UIColor clearColor];
        _bx_smscodeTextField.borderStyle = UITextBorderStyleNone;
        _bx_smscodeTextField.font = BXSystemFont(14);
        _bx_smscodeTextField.textColor = BXTextFieldTextColor;
        _bx_smscodeTextField.keyboardType = UIKeyboardTypeASCIICapable;
        _bx_smscodeTextField.autocorrectionType = UITextAutocorrectionTypeNo;
        _bx_smscodeTextField.autocapitalizationType = UITextAutocapitalizationTypeNone;
                
        @weakify(self)
        BXTextFieldAction *rightAction = [BXTextFieldAction actionWithImage:@"tf_clear" handler:^(BXTextFieldAction * _Nonnull action) {
            @strongify(self)
            self.bx_smscodeTextField.text = nil;
        }];
        [_bx_smscodeTextField setTrillingActions:@[rightAction]];
                
        _bx_smscodeTextField.keyboardType = UIKeyboardTypeASCIICapable;
        
    }
    return _bx_smscodeTextField;
}

- (UIButton *)bx_nextButton {
    if (!_bx_nextButton) {
        UIButton *bx_button = [UIButton buttonWithType:UIButtonTypeCustom];
        [bx_button setTitle:@"绑定" forState:UIControlStateNormal];
        [bx_button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        UIImage *aImage = [UIImage imageNamed:@"bxm_Anniu" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
        [bx_button setBackgroundImage:aImage forState:UIControlStateNormal];
        [bx_button addTarget:self action:@selector(bingMobileEvent:) forControlEvents:UIControlEventTouchUpInside];

        
        _bx_nextButton = bx_button;
    }
    return _bx_nextButton;
}

- (void)checkAuthorizeCompletionAndDissmiss {
    BXUser *user = [BXMobileManager shareManager].currentUser;
    if (user.adultState == 1 && [BXConfig config].realNameAuthTip == 1) {
        user.realnameReminderTime = [NSDate date];
        [user save];
        
        BXIdAuthViewController *bx_idAuthController = [[BXIdAuthViewController alloc] init];
        bx_idAuthController.isLimit = user.loginLimit != 2;
        bx_idAuthController.dismissBlock = ^(BOOL isAuditLimit, NSDictionary *result) {
            
        };
        [self presentViewController:bx_idAuthController animated:YES completion:^{
        }];
    }else {
        [[NSNotificationCenter defaultCenter] postNotificationName:BXUserLoginSuccessNotification object:[user proxyLoginResultDictionary]];
        
        [self bx_dismissPresentedViewController:self completionBlock:^{
            [BXEvent bx_doUpdateNotice:^(NSArray *notifies, NSError *error) {
                if (notifies.count > 0) {
                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.25 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                        BXNoticeViewController *bx_notifyController = [[BXNoticeViewController alloc] initWithNotifies:notifies];
                        [bx_notifyController bx_presentWithViewController:nil];
                    });
                }
            }];
        }];
    }
}

@end
