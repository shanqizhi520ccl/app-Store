//
//  BXMyInfoController.m
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/8/25.
//  Copyright © 2021 Gavin. All rights reserved.
//

#import "BXMyInfoController.h"
#import "BXMobileManager.h"
#import "BXMobileManager+Private.h"
#import "BXUser.h"
#import "BXMyH5Controller.h"
#import "BXConfig.h"
#import "BXPrivacyUtil.h"
#import "BXSeviceAndPrivacyViewController.h"
#import "BXPrivacyController.h"
#import "BXUserDataManagerController.h"
#import "BXBindedPhoneController.h"
#import "BXPhoneBindController.h"
#import "BXVerifyedController.h"
#import "BXVerifyController.h"
#import "BXEvent.h"
#import "BXIdAuthViewController.h"
#import "BXResetPWDViewController.h"
#import "BXChangePWDViewController.h"

typedef NS_ENUM(NSInteger,BXMycellType) {
    BXMycellArrow = 0,
    BXMycellText = 1,
    BXMycellAuth = 2,
    BXMycellArrowOrText = 3,
};

@interface BXMyInfoController ()<UITableViewDelegate, UITableViewDataSource>

@property(strong, nonatomic) UIButton *bx_giftBtn;
@property(strong, nonatomic) UIButton *bx_serviceBtn;
@property(strong, nonatomic) UIButton *bx_changeBtn;

@property(strong, nonatomic) UITableView *tableView;

@property(strong, nonatomic) UIImageView *bx_topImageView;
@property(strong, nonatomic) UIImageView *bx_userHeadImageView;

@property(strong, nonatomic) UILabel *bx_child_descLabel;
@property(strong, nonatomic) UILabel *bx_childUserIDLabel;

@property(strong, nonatomic) NSMutableArray *bx_menuArray;
@property(strong, nonatomic) NSMutableArray *bx_cellTypeArray;

@property (nonatomic, assign) BOOL bx_didSetupConstraints;
@end

@implementation BXMyInfoController

- (void)dealloc
{
    BXLogInfo(@"%s",__func__);
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.preferredContentSize = [self orientationStatus] ? CGSizeMake(ScreenWidth, ScreenWidth) : CGSizeMake(ScreenWidth, ScreenHeight);
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setupViews];
    
    [self updateUserInfo];
    
    self.view.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(screenTap:)];
    tap.cancelsTouchesInView = NO;
    [self.view addGestureRecognizer:tap];
}

- (void)updateUserInfo {
    [BXEvent bx_doUserInfoComplement:^(id obj, NSError *error) {
        if (!error) {
            [self.tableView reloadData];
        }else{
            [BXMBProgressHUD bx_showMessage:error.localizedDescription delay:YES];
        }
    }];
}

- (void) screenTap:(UITapGestureRecognizer *)gesture {
    CGPoint p = [gesture locationInView:self.view];
    if (!CGRectContainsPoint(self.bx_baseframeView.frame, p)) {
        [self dismissToRootViewController];
    }
}

-(void)dismissToRootViewController
{
    UIViewController *vc = self;
    while (vc.presentingViewController) {
        vc = vc.presentingViewController;
    }
    [vc dismissViewControllerAnimated:YES completion:nil];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self initMenuDatas];
    
    [self notifitionSatatus];
}

-(void)notifitionSatatus{
    [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(statusBarOrientationChange:) name:UIApplicationDidChangeStatusBarOrientationNotification object:nil];
}
-(void)statusBarOrientationChange:(NSNotification*)notification{
    self.preferredContentSize = [self orientationStatus] ? CGSizeMake(ScreenWidth, ScreenWidth) : CGSizeMake(ScreenWidth, ScreenHeight);
    [self.bx_baseframeView autoSetDimensionsToSize:[self orientationStatus] ? CGSizeMake(ScreenWidth, ScreenWidth) : CGSizeMake(ScreenWidth, ScreenWidth)];
}

- (void)setupViews {
    self.view.backgroundColor = UIColor.clearColor;
    
    [self.view addSubview:self.bx_baseframeView];
    
    _bx_topImageView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"bxm_beijing" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil]];
    _bx_topImageView.contentMode = UIViewContentModeScaleAspectFill;
    _bx_topImageView.alpha = 1;
//    _bx_topImageView.clipsToBounds = true;
    [self.bx_baseframeView addSubview:_bx_topImageView];
    
    BXUser *user = [BXMobileManager shareManager].currentUser;
    _bx_userHeadImageView = [[UIImageView alloc]init];
    
    [_bx_userHeadImageView setImage: user.userLogoUrl.length ? [UIImage imageWithData:[[NSData alloc]initWithContentsOfURL:[NSURL URLWithString:user.userLogoUrl]]] :[UIImage imageNamed:@"bxm_txBack" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil]];
    [self.bx_baseframeView addSubview:_bx_userHeadImageView];
    
    _bx_child_descLabel = [[UILabel alloc]init];
    _bx_child_descLabel.text = user.phoneNumber;
    _bx_child_descLabel.textColor = BXHexColor(0xFFFFFF);
    _bx_child_descLabel.font = BXBoldSystemFont(14);
    [self.bx_baseframeView addSubview:_bx_child_descLabel];
    
    _bx_childUserIDLabel = [[UILabel alloc]init];
    _bx_childUserIDLabel.text = user.userId;
    _bx_childUserIDLabel.textColor = BXHexColor(0xFFFFFF);
    _bx_childUserIDLabel.font = BXSystemFont(12);
    [self.bx_baseframeView addSubview:_bx_childUserIDLabel];
    
    [self.bx_baseframeView addSubview:self.bx_baseBackView];
    
    self.bx_giftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.bx_giftBtn setTitleColor:BXHexColor(0x333333) forState:UIControlStateNormal];
    [self.bx_giftBtn.titleLabel setFont:BXSystemFont(10)];
    [self.bx_giftBtn setImage:[UIImage imageNamed:@"bxm_libao" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
    self.bx_giftBtn.tag = 0;
    [self.bx_giftBtn setTitle:@"礼包" forState:UIControlStateNormal];
    [self.bx_giftBtn addTarget:self action:@selector(clickBtn:) forControlEvents:UIControlEventTouchUpInside];
    [self.bx_baseBackView addSubview:self.bx_giftBtn];
    
    self.bx_serviceBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.bx_serviceBtn setTitleColor:BXHexColor(0x333333) forState:UIControlStateNormal];
    [self.bx_serviceBtn.titleLabel setFont:BXSystemFont(10)];
    [self.bx_serviceBtn setImage:[UIImage imageNamed:@"bxm_kefu" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
    self.bx_serviceBtn.tag = 1;
    [self.bx_serviceBtn setTitle:@"客服" forState:UIControlStateNormal];
    [self.bx_serviceBtn addTarget:self action:@selector(clickBtn:) forControlEvents:UIControlEventTouchUpInside];
    [self.bx_baseBackView addSubview:self.bx_serviceBtn];
    
    self.bx_changeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.bx_changeBtn setTitleColor:BXHexColor(0x333333) forState:UIControlStateNormal];
    [self.bx_changeBtn.titleLabel setFont:BXSystemFont(10)];
    [self.bx_changeBtn setImage:[UIImage imageNamed:@"bxm_mima" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
    self.bx_changeBtn.tag = 2;
    [self.bx_changeBtn setTitle:@"修改密码" forState:UIControlStateNormal];
    [self.bx_changeBtn addTarget:self action:@selector(clickBtn:) forControlEvents:UIControlEventTouchUpInside];
    [self.bx_baseBackView addSubview:self.bx_changeBtn];
    
    _tableView = [[UITableView alloc]init];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.layer.cornerRadius = 5;
    _tableView.layer.masksToBounds = YES;
    _tableView.tableFooterView = UIView.new;
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    [self.bx_baseframeView addSubview:_tableView];
    
    [self.view updateConstraintsIfNeeded];
}

-(void)clickBtn:(UIButton *)sender{
    BXLog(@"clickBtn --- %ld",(long)sender.tag);
    if (sender.tag == 2) {
        BXChangePWDViewController *resetPasswordController = [[BXChangePWDViewController alloc] init];
        [self presentViewController:resetPasswordController animated:YES completion:^{
        }];
    }else{
        BXMyH5Controller *vc = [[BXMyH5Controller alloc]init];
        vc.bx_urlStr = sender.tag == 1 ? [BXPrivacyUtil bx_serviceWebUrl] : [BXPrivacyUtil bx_giftWebUrl];
        [self presentViewController:vc animated:YES completion:^{
        }];
    }
}

- (void)updateViewConstraints {
    if (!_bx_didSetupConstraints) {
        [self.bx_baseframeView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0];
        [self.bx_baseframeView autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:0];
        [self.bx_baseframeView autoSetDimensionsToSize:[self orientationStatus] ? CGSizeMake(ScreenHeight, ScreenHeight) : CGSizeMake(ScreenWidth, ScreenWidth)];
        
        [self.bx_topImageView sizeToFit];
        [self.bx_topImageView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0];
        [self.bx_topImageView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:0];
        [self.bx_topImageView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:0];
        [self.bx_topImageView autoSetDimension:ALDimensionHeight toSize:self.bx_topImageView.frame.size.height];
        
        self.bx_userHeadImageView.layer.cornerRadius = 40 / 2;
        self.bx_userHeadImageView.layer.masksToBounds = YES;
        [self.bx_userHeadImageView autoSetDimensionsToSize:CGSizeMake(40, 40)];
        [self.bx_userHeadImageView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:24];
        [self.bx_userHeadImageView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:14];
        
        [self.bx_child_descLabel sizeToFit];
        [self.bx_child_descLabel autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:24];
        [self.bx_child_descLabel autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:18];
        
        [self.bx_childUserIDLabel sizeToFit];
        [self.bx_childUserIDLabel autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:24];
        [self.bx_childUserIDLabel autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_child_descLabel withOffset:5];
        
        [self.bx_baseBackView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:14];
        [self.bx_baseBackView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:14];
        [self.bx_baseBackView autoSetDimension:ALDimensionHeight toSize:55];
        [self.bx_baseBackView autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_topImageView withOffset:-55 / 2];
        
        [self.bx_giftBtn autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0];
        [self.bx_giftBtn autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:0];
        [self.bx_giftBtn autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:0];
        [self.bx_giftBtn autoSetDimension:ALDimensionWidth toSize:100];
        [self statusBtn:self.bx_giftBtn];
        
        [self.bx_serviceBtn autoPinEdge:ALEdgeBottom toEdge:ALEdgeBottom ofView:self.bx_giftBtn];
        [self.bx_serviceBtn autoAlignAxis:ALAxisVertical toSameAxisOfView:self.bx_baseBackView withOffset:0];
        [self.bx_serviceBtn autoPinEdge:ALEdgeTop toEdge:ALEdgeTop ofView:self.bx_giftBtn];
        [self.bx_serviceBtn autoMatchDimension:ALDimensionWidth toDimension:ALDimensionWidth ofView:self.bx_giftBtn];
        [self statusBtn:self.bx_serviceBtn];
        
        [self.bx_changeBtn autoPinEdge:ALEdgeTop toEdge:ALEdgeTop ofView:self.bx_serviceBtn];
        [self.bx_changeBtn autoPinEdge:ALEdgeBottom toEdge:ALEdgeBottom ofView:self.bx_serviceBtn];
        [self.bx_changeBtn autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:0];
        [self.bx_changeBtn autoMatchDimension:ALDimensionWidth toDimension:ALDimensionWidth ofView:self.bx_giftBtn];
        [self statusBtn:self.bx_changeBtn];
        
        [self.tableView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:7.5];
        [self.tableView autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:15];
        [self.tableView autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_baseBackView withOffset:8];
        [self.tableView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:7.5];
        
        self.bx_baseBackView.layer.shadowRadius = 4;
        self.bx_baseBackView.layer.cornerRadius = 4;
        
        _bx_didSetupConstraints = YES;
    }
    [super updateViewConstraints];
}

-(void)statusBtn:(UIButton *)btn{
    CGFloat imgW = btn.imageView.image.size.width;
    CGFloat imgH = btn.imageView.image.size.height;
    CGFloat lblW = [btn.titleLabel sizeThatFits:CGSizeMake(200, 200)].width;
    CGFloat lblH = [btn.titleLabel sizeThatFits:CGSizeMake(200, 200)].height;
    CGFloat margin = 5;
    btn.imageEdgeInsets = UIEdgeInsetsMake(-lblH-margin/2, 0, 0, -lblW);
    btn.titleEdgeInsets = UIEdgeInsetsMake(imgH+margin/2, -imgW, 0, 0);
}

- (void) initMenuDatas {
    
    self.bx_menuArray = [[NSMutableArray alloc]init];
    self.bx_cellTypeArray = [[NSMutableArray alloc]init];
    
    [self.bx_menuArray addObject: [[BXMobileManager shareManager].currentUser.phoneNumber bx_isEmpty] ? @"绑定手机" : @"解绑手机"];
    [self.bx_cellTypeArray addObject:[NSNumber numberWithInteger:BXMycellArrow]];
    
    [self.bx_menuArray addObject:@"实名认证"];
    [self.bx_cellTypeArray addObject:[NSNumber numberWithInteger:BXMycellArrowOrText]];
    
    [self.bx_menuArray addObject:@"自动登录"];
    [self.bx_cellTypeArray addObject:[NSNumber numberWithInteger:BXMycellAuth]];
    
    [self.bx_menuArray addObject:@"版本号"];
    [self.bx_cellTypeArray addObject:[NSNumber numberWithInteger:BXMycellText]];
    
    [self.bx_menuArray addObject:@"用户注册服务协议"];
    [self.bx_cellTypeArray addObject:[NSNumber numberWithInteger:BXMycellArrow]];
    
    [self.bx_menuArray addObject:@"游戏隐私保护指引"];
    [self.bx_cellTypeArray addObject:[NSNumber numberWithInteger:BXMycellArrow]];
    
    [self.bx_menuArray addObject:@"隐私权限设置"];
    [self.bx_cellTypeArray addObject:[NSNumber numberWithInteger:BXMycellArrow]];
    
    [self.bx_menuArray addObject:@"个人信息管理"];
    [self.bx_cellTypeArray addObject:[NSNumber numberWithInteger:BXMycellArrow]];
    
    if ([BXMobileManager shareManager].currentUser.roleId.length) {
        [self.bx_menuArray addObject:@"退出账号"];
        [self.bx_cellTypeArray addObject:[NSNumber numberWithInteger:BXMycellArrow]];
    }
}


- (void)showServiceAgreementEvent:(id)sender {
    NSString *bx_serviceAgreementUrl = [NSString stringWithFormat:@"%@agree/%@_appstore/user_protocol.html", [BXConfig config].cdnImgServer, [BXConfig config].platformId];
    BXLogInfo(@"bxm_serviceAgreementUrl = %@", bx_serviceAgreementUrl);
    BXMyH5Controller *vc = [[BXMyH5Controller alloc]init];
    vc.bx_urlStr = bx_serviceAgreementUrl;
    [self presentViewController:vc animated:YES completion:^{
    }];
}

- (void)showPrivacyPolicyEvent:(id)sender {
    NSString *bx_privacyPolicyUrl = [NSString stringWithFormat:@"%@agree/%@_appstore/privacy_policy_transparent_black_text.html", [BXConfig config].cdnImgServer, [BXConfig config].platformId];
    BXMyH5Controller *vc = [[BXMyH5Controller alloc]init];
    vc.bx_urlStr = bx_privacyPolicyUrl;
    [self presentViewController:vc animated:YES completion:^{
    }];
}

- (void)showBXPrivacyControllerEvent:(id)sender {
    BXPrivacyController *vc = [[BXPrivacyController alloc]init];
    [self presentViewController:vc animated:YES completion:^{
    }];
}

- (void)showBXUserDataManagerControllerEvent:(id)sender {
    BXUserDataManagerController *vc = [[BXUserDataManagerController alloc]init];
    [self presentViewController:vc animated:YES completion:^{
    }];
}

- (void)showBXBindedPhoneControllerEvent:(id)sender {
    @weakify(self)
    BXUser *user = [BXMobileManager shareManager].currentUser;
    if ([user.phoneNumber bx_isEmpty]){
        BXPhoneBindController *vc = [[BXPhoneBindController alloc]initWithType:0];
        vc.btnBlock = ^{
            @strongify(self)
            [self initMenuDatas];
            [self.tableView reloadData];
        };
        [self presentViewController:vc animated:YES completion:^{
        }];
    }else{
        BXBindedPhoneController *vc = [[BXBindedPhoneController alloc]init];
        vc.actionDisBlock = ^{
            @strongify(self)
            [self initMenuDatas];
            [self.tableView reloadData];
        };
        [self presentViewController:vc animated:YES completion:^{
        }];
    }
}

- (void)showBXVerifyedControllerEvent:(id)sender {
    if ([BXMobileManager shareManager].currentUser.idcard.length == 0) {
        BXVerifyController *bx_idAuthController = [[BXVerifyController alloc] init];
        bx_idAuthController.verifyCallback = ^{
            [self.tableView reloadData];
        };
        [self presentViewController:bx_idAuthController animated:YES completion:^{
        }];
    }else{
        BXVerifyedController *vc = [[BXVerifyedController alloc]init];
        [self presentViewController:vc animated:YES completion:^{
        }];
    }
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSString *title = [self.bx_menuArray objectAtIndex:indexPath.row];
    if ([title isEqualToString:@"解绑手机"] || [title isEqualToString:@"绑定手机"]){
        [self showBXBindedPhoneControllerEvent:nil];
    }else if ([title isEqualToString:@"实名认证"]){
        [self showBXVerifyedControllerEvent:nil];
    }else if ([title isEqualToString:@"用户注册服务协议"]){
        [self showServiceAgreementEvent:nil];
    }else if ([title isEqualToString:@"游戏隐私保护指引"]){
        [self showPrivacyPolicyEvent:nil];
    }else if ([title isEqualToString:@"隐私权限设置"]){
        [self showBXPrivacyControllerEvent:nil];
    }else if ([title isEqualToString:@"个人信息管理"]){
        [self showBXUserDataManagerControllerEvent:nil];
    }else if ([title isEqualToString:@"退出账号"]){
        [self logoutWithAction];
    }else{
        
    }
    BXLog(@"didSelectRowAtIndexPath");
}

-(void)logoutWithAction{
    [BXPrivacyUtil bx_alertActionWithTitle:@"" message:@"确定退出游戏吗?" handler:^(UIAlertAction * _Nonnull action) {
        [[BXMobileManager shareManager] logout];
        [self bx_hideWithCompletion:nil];
    } cancelHandler:^(UIAlertAction * _Nonnull action) {
        
    }];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.bx_menuArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    BXMyControllerCell *cell = [tableView dequeueReusableCellWithIdentifier:@"BXMyControllerCell"];
    if (cell == nil) {
        cell = [[BXMyControllerCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"BXMyControllerCell"];
    }
    [cell bx_setCellDataWithTitle:[self.bx_menuArray objectAtIndex:indexPath.row] type:[self.bx_cellTypeArray objectAtIndex:indexPath.row]];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 36;
}

@end


@implementation BXMyControllerCell

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self initView];
    }
    return self;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initView];
    }
    return self;
}

- (void)initView {
    self.backgroundColor = UIColor.whiteColor;
    
    self.bx_arrow = [[UIImageView alloc] init];
    self.bx_arrow.image = [UIImage imageNamed:@"info_left" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
    [self.contentView addSubview:self.bx_arrow];
    
    self.bx_line = [[UIView alloc]init];
    self.bx_line.backgroundColor = BXHexColor(0xDEDEDE);
    [self.contentView addSubview:self.bx_line];
    
    self.bx_titleLabel = [[UILabel alloc] init];
    self.bx_titleLabel.font = BXSystemFont(12);
    self.bx_titleLabel.textColor = BXHexColor(0x333333);
    self.bx_titleLabel.textAlignment = NSTextAlignmentLeft;
    [self.contentView addSubview:self.bx_titleLabel];
    
    self.bx_descLabel = [[UILabel alloc] init];
    self.bx_descLabel.font = BXSystemFont(12);
    self.bx_descLabel.textColor = BXHexColor(0x999999);
    self.bx_descLabel.textAlignment = NSTextAlignmentRight;
    [self.contentView addSubview:self.bx_descLabel];
    
    self.bx_autoSwitch = [[UISwitch alloc] init];
    [self.bx_autoSwitch setOn:[BXUser getAutoLogin] animated:NO];
    self.bx_autoSwitch.onTintColor = BXHexColor(0xFDBE00);
    [self.bx_autoSwitch addTarget:self action:@selector(switchAutoLogin) forControlEvents:UIControlEventTouchUpInside];
    [self.contentView addSubview:self.bx_autoSwitch];
    
    self.bx_chargeButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.bx_chargeButton setTitleColor:BXHexColor(0xDEDEDE) forState:UIControlStateNormal];
    self.bx_chargeButton.backgroundColor = BXHexColor(0x999999);
    [self.bx_chargeButton.titleLabel setFont:BXSystemFont(10)];
    [self.contentView addSubview:self.bx_chargeButton];
}

-(void)switchAutoLogin{
    
    [BXUser setAutoLogin:self.bx_autoSwitch.isOn];
}

- (BOOL)orientationStatus{
    UIInterfaceOrientation orientation = [[UIApplication sharedApplication] statusBarOrientation];
    if (orientation == UIInterfaceOrientationLandscapeRight || orientation == UIInterfaceOrientationLandscapeLeft) // home键靠右
    {
        return YES;
    }
    if (orientation == UIInterfaceOrientationPortrait)//home在下
    {
        return  NO;
    }
    return  NO;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    if (self.contentView.frame.origin.x > 0 || self.contentView.frame.size.width < ([self orientationStatus] ? ScreenHeight - 15 : ScreenWidth - 15)) {
        self.contentView.frame = CGRectMake(0, self.contentView.frame.origin.y, ([self orientationStatus] ? ScreenHeight - 15 : ScreenWidth - 15), self.contentView.frame.size.height);
    }
    
    [self.bx_arrow sizeToFit];
    [self.bx_arrow autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:10];
    [self.bx_arrow autoAlignAxis:ALAxisHorizontal toSameAxisOfView:self.contentView withOffset:0];
    
    [self.bx_line autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:10];
    [self.bx_line autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:0];
    [self.bx_line autoSetDimensionsToSize:CGSizeMake(CGRectGetWidth(self.contentView.frame) - 20, 0.5)];
    
    [self.bx_autoSwitch autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:10];
    [self.bx_autoSwitch autoAlignAxis:ALAxisHorizontal toSameAxisOfView:self.contentView withOffset:0];
    
    [self.bx_titleLabel sizeToFit];
    [self.bx_titleLabel autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:10];
    [self.bx_titleLabel autoAlignAxis:ALAxisHorizontal toSameAxisOfView:self.contentView withOffset:0];
    
    [self.bx_descLabel autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.bx_titleLabel withOffset:10];
    [self.bx_descLabel autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:10];
    [self.bx_descLabel autoAlignAxis:ALAxisHorizontal toSameAxisOfView:self.contentView withOffset:0];
    
    [self.bx_chargeButton autoPinEdge:ALEdgeRight toEdge:ALEdgeLeft ofView:self.bx_arrow withOffset:-10];
    [self.bx_chargeButton autoAlignAxis:ALAxisHorizontal toSameAxisOfView:self.contentView withOffset:0];
    [self.bx_chargeButton autoSetDimensionsToSize:CGSizeMake(40, 20)];
    self.bx_chargeButton.layer.cornerRadius = 2;
    self.bx_chargeButton.layer.masksToBounds = YES;
}

-(void)bx_setCellDataWithTitle:(NSString *)title type:(NSNumber *)type{
    
    [self.bx_autoSwitch setHidden:YES];
    [self.bx_arrow setHidden:YES];
    [self.bx_chargeButton setHidden:YES];
    [self.bx_descLabel setHidden:YES];
    self.bx_descLabel.text = @"";
    
    self.bx_titleLabel.text = title;
    if (type.integerValue == BXMycellText){
        self.bx_descLabel.text = [NSString stringWithFormat:@"v%@",[BXMobileManager currentSDKVersion]];
        [self.bx_descLabel setHidden:NO];
        
    }else if(type.integerValue == BXMycellArrow){
        [self.bx_arrow setHidden:NO];
        
    }else if(type.integerValue == BXMycellAuth){
        [self.bx_autoSwitch setHidden:NO];
    }else{
        if ([BXMobileManager shareManager].currentUser.idcard.length == 0) {
            [self.bx_chargeButton setTitleColor:BXHexColor(0x999999) forState:UIControlStateNormal];
            self.bx_chargeButton.backgroundColor = BXHexColor(0xDEDEDE);
            [self.bx_chargeButton setTitle:@"未认证" forState:UIControlStateNormal];
        }else{
            [self.bx_chargeButton setTitleColor:BXHexColor(0x388EFF) forState:UIControlStateNormal];
            self.bx_chargeButton.backgroundColor = BXHexColor(0xE9F2FF);
            [self.bx_chargeButton setTitle:@"已认证" forState:UIControlStateNormal];
        }
        [self.bx_chargeButton setHidden:NO];
        [self.bx_arrow setHidden:NO];
    }
}

@end
