//
//  BXCaptureRegisterResultViewController.h
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/31.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXBaseViewController.h"

//NS_ASSUME_NONNULL_BEGIN

@class BXUser;

@interface BXCaptureRegisterResultViewController : BXBaseViewController

@property (nonatomic, readonly) NSString *account;
@property (nonatomic, readonly) NSString *password;

- (instancetype)initWithAccount:(NSString *)account
                    password:(NSString *)password;
@end

//NS_ASSUME_NONNULL_END
