//
//  BXExecuteLoginViewController.h
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/8/1.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface BXExecuteLoginViewController : BXBaseViewController

@property (nonatomic) BOOL isFromRegister; //default NO.

@property (nonatomic, readonly) NSString *account;
@property (nonatomic, readonly) NSString *password;

- (instancetype)initWithAccount:(NSString *)account
                       password:(NSString *)password
                   fromRegister:(BOOL)fromRegister;

@end

NS_ASSUME_NONNULL_END
