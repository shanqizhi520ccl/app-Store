//
//  BXMyInfoController.h
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/8/25.
//  Copyright © 2021 Gavin. All rights reserved.
//

#import "BXBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface BXMyInfoController : BXBaseViewController

@end

NS_ASSUME_NONNULL_END

@interface BXMyControllerCell: UITableViewCell

@property (strong, nonatomic) UILabel *bx_titleLabel;
@property (strong, nonatomic) UILabel *bx_descLabel;

@property (strong, nonatomic) UIImageView *bx_arrow;
@property (strong, nonatomic) UISwitch *bx_autoSwitch;
@property (strong, nonatomic) UIButton *bx_chargeButton;
@property (strong, nonatomic) UIView *bx_line;

-(void)bx_setCellDataWithTitle:(NSString *)title type:(NSNumber *)type;
@end
