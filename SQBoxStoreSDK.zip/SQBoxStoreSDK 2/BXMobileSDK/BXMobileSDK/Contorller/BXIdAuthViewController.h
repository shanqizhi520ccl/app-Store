//
//  BXIdAuthViewController.h
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/24.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXBaseViewController.h"

//NS_ASSUME_NONNULL_BEGIN

@interface BXIdAuthViewController : BXBaseViewController

@property (assign, nonatomic) BOOL isLimit;

/// isAuditLimit登录受限则跳回登录窗口, message受限则提示用户, result后台应答数据
@property(nonatomic, copy) void(^dismissBlock)(BOOL isAuditLimit, NSDictionary *result);

@end

//NS_ASSUME_NONNULL_END
