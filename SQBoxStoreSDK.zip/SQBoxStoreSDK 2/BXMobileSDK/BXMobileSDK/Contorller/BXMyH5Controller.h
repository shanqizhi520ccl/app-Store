//
//  BXMyH5Controller.h
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/8/26.
//  Copyright © 2021 Gavin. All rights reserved.
//

#import "BXBaseViewController.h"

//NS_ASSUME_NONNULL_BEGIN

@interface BXMyH5Controller : BXBaseViewController

@property (strong, nonatomic) NSString *bx_urlStr;

@end

//NS_ASSUME_NONNULL_END
