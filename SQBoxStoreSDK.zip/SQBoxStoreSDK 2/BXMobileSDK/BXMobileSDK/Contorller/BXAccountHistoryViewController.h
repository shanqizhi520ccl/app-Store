//
//  BXAccountHistoryViewController.h
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/8/3.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXBaseViewController.h"

//NS_ASSUME_NONNULL_BEGIN

@protocol BXAccountHistoryViewControllerDelegate <NSObject>
- (void)didSelectItem:(id)item;
@end


@interface BXAccountHistoryViewController : BXBaseViewController

@property (nonatomic, weak) id<BXAccountHistoryViewControllerDelegate>delegate;

@end

//NS_ASSUME_NONNULL_END
