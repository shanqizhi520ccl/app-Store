//
//  BXBindedPhoneController.h
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/8/27.
//  Copyright © 2021 Gavin. All rights reserved.
//

#import "BXBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN
typedef void (^BindedDisActionBlock)(void);

@interface BXBindedPhoneController : BXBaseViewController

@property (copy, nonatomic) BindedDisActionBlock actionDisBlock;

@end

NS_ASSUME_NONNULL_END
