//
//  BXExecuteLoginViewController.m
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/8/1.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXExecuteLoginViewController.h"
#import "BXActivityView.h"
#import "BXEvent.h"
#import "BXUser.h"
#import "BXConfig.h"
#import "BXMobileManager+Private.h"
#import "BXBindMobileTipsViewController.h"
#import "BXIdAuthViewController.h"
#import "BXNoticeViewController.h"
#import "BXAddHeartbeatManager.h"

#import "BXThreeSelectionController.h"
#import "BXPrivacyWebController.h"
#import "BXPrivacyUtil.h"

@interface BXExecuteLoginViewController ()
@property (nonatomic, strong, readwrite) NSString *account;
@property (nonatomic, strong, readwrite) NSString *password;

@property (nonatomic, strong) UIView *backgroundView;
@property (nonatomic, strong) BXActivityView *activityView;
@property (nonatomic, strong) UILabel *tipsLabel;
@property (nonatomic, assign) BOOL bx_didSetupConstraints;
@end

@implementation BXExecuteLoginViewController

- (instancetype)init{
    NSException * exp = [NSException exceptionWithName:@"BXMobileSDK" reason:@"call -initWithAccount:password:fromRegister: instead of -init" userInfo:nil];
    @throw exp;
}

- (instancetype)initWithAccount:(NSString *)account password:(NSString *)password fromRegister:(BOOL)fromRegister{
    self = [super init];
    if (self) {
        self.modalPresentationStyle = UIModalPresentationFullScreen;
        self.account = account;
        self.password = password;
        self.isFromRegister = fromRegister;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor clearColor];
    
    [self.view addSubview:self.backgroundView];
    [self.backgroundView addSubview:self.activityView];
    [self.backgroundView addSubview:self.tipsLabel];
    
    [self.tipsLabel setText:[NSString stringWithFormat:@"%@, 登录中...", self.account]];
    
    [self.view updateConstraintsIfNeeded];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self loginAccount];
}

- (void)updateViewConstraints {
    if (!_bx_didSetupConstraints) {
        [self.backgroundView autoCenterInSuperview];
        [self.backgroundView autoSetDimension:ALDimensionHeight toSize:48];
        
        [@[self.activityView, self.tipsLabel] autoAlignViewsToAxis:ALAxisHorizontal];
        
        [self.activityView autoSetDimensionsToSize:CGSizeMake(40, 40)];
        [self.activityView autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:29];
        [self.activityView autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
        
        [self.tipsLabel autoPinEdge:ALEdgeLeading toEdge:ALEdgeTrailing ofView:self.activityView withOffset:10];
        [self.tipsLabel autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:29];
        
        _bx_didSetupConstraints = YES;
    }
    [super updateViewConstraints];
}

- (UIView *)backgroundView {
    if (!_backgroundView) {
        _backgroundView = [[UIView alloc] init];
        _backgroundView.backgroundColor = [UIColor whiteColor];
        _backgroundView.layer.cornerRadius = 4;
    }
    return _backgroundView;
}

- (BXActivityView *)activityView {
    if (!_activityView) {
        _activityView = [[BXActivityView alloc] init];
    }
    return _activityView;
}

- (UILabel *)tipsLabel {
    if (!_tipsLabel) {
        _tipsLabel = [[UILabel alloc] init];
        [_tipsLabel setTextColor:BXHexColor(0x767B82)];
    }
    return _tipsLabel;
}

- (void)loginAccount {
    [BXEvent bx_doLogin:self.account password:self.password complement:^(BXUser *user, NSError *error) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            if (!error) {
                //                [[BXAddHeartbeatManager sharedInstance] start];
                if (([BXConfig config].isSeries)) {
                    [self showBXPrivacyWebControllerWithAction:^{
                        [self checkAuthorizeCompletionAndDissmiss];
                    }];
                }else{
                    [self checkAuthorizeCompletionAndDissmiss];
                }
            }else{
                // 返回
                [self bx_hideWithCompletion:^{
                    BXLogInfo(@"SDK登录失败 { error: %@ }", error);
                    [BXMBProgressHUD bx_showMessage:error.localizedDescription delay:YES];
                }];
            }
        });
    }];
}

- (void)checkAuthorizeCompletionAndDissmiss {
    BXUser *user = [BXMobileManager shareManager].currentUser;
    if ([user.phoneNumber bx_isEmpty] && [[user.bindMobileReminderTime dateByAddingTimeInterval:60*60*24] compare:[NSDate date]] <= NSOrderedSame  ) {
        user.bindMobileReminderTime = [NSDate date];
        [user save];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.25 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            BXBindMobileTipsViewController *tipsController = [[BXBindMobileTipsViewController alloc] init];
            [self presentViewController:tipsController animated:YES completion:^{
            }];
        });
    }else if (user.adultState == 1 && [BXConfig config].realNameAuthTip == 1) {
        user.realnameReminderTime = [NSDate date];
        [user save];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.25 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            BXIdAuthViewController *bx_idAuthController = [[BXIdAuthViewController alloc] init];
            bx_idAuthController.isLimit = user.loginLimit != 2;
            bx_idAuthController.dismissBlock = ^(BOOL isAuditLimit, NSDictionary *result) {
                
            };
            [self presentViewController:bx_idAuthController animated:YES completion:^{
            }];
        });
    }else {
        [[NSNotificationCenter defaultCenter] postNotificationName:BXUserLoginSuccessNotification object:[user proxyLoginResultDictionary]];
        
        [self bx_dismissPresentedViewController:self completionBlock:^{
            [BXEvent bx_doUpdateNotice:^(NSArray *notifies, NSError *error) {
                if (notifies.count > 0) {
                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.25 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                        BXNoticeViewController *bx_notifyController = [[BXNoticeViewController alloc] initWithNotifies:notifies];
                        [bx_notifyController bx_presentWithViewController:nil];
                    });
                }
            }];
        }];
    }
}

- (void)showBXPrivacyWebControllerWithAction:(void(^)(void))completion{
    //判断是否弹出协议
    BOOL isNeedShowPrivacy = [[BXConfig config] isNeedShowProtocol];
    if (isNeedShowPrivacy) {
        BXPrivacyWebController *vc = [[BXPrivacyWebController alloc] init];
        vc.urlStr = [BXPrivacyUtil privacyWebUrl];
        vc.modalPresentationStyle = UIModalPresentationCustom;
        vc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        vc.WebBtnCallback = ^(BOOL agreed) {
            if (!agreed) {
                [BXPrivacyUtil bx_exitApplication];
                return;
            }
            [[BXConfig config] agreedSync];
            [self showDevicePrivacyViewWithAction:completion];
        };
        [self presentViewController:vc animated:NO completion:nil];
        return;
    }else{
        [self showDevicePrivacyViewWithAction:completion];
    }
}

- (void)showDevicePrivacyViewWithAction:(void(^)(void))completion{
    if ([BXPrivacyUtil bx_isNeedShowbx_devicePrivacy] == YES && [BXConfig config].grcAuthorityDerail == 1){
        BXThreeSelectionController *selectionVC = [[BXThreeSelectionController alloc] init];
        selectionVC.bx_Status = 0;
        [self presentViewController:selectionVC animated:NO completion:nil];
        selectionVC.bx_DeviceCallback = ^{
            completion();
        };
    }else{
        completion();
    }
}

@end
