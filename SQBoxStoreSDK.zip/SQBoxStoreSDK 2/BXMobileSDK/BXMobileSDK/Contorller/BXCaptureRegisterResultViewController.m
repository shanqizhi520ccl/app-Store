//
//  BXCaptureRegisterResultViewController.m
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/31.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXCaptureRegisterResultViewController.h"
#import "BXExecuteLoginViewController.h"
#import "BXUser.h"

@interface BXCaptureRegisterResultViewController ()

@property (nonatomic, strong, readwrite) NSString *account;
@property (nonatomic, strong, readwrite) NSString *password;

@property (nonatomic, strong) UIView *contentView;
@property (nonatomic, strong) UIView *bx_navgationBar;
@property (nonatomic, strong) UIImageView *bx_navgationBackgroundImgView;
@property (nonatomic, strong) UILabel *bx_titileLabel;
@property (nonatomic, strong) UIButton *bx_closeButton;

@property (nonatomic, strong) UILabel *bx_nameTitleLabel;
@property (nonatomic, strong) UILabel *bx_nameValueLabel;
@property (nonatomic, strong) UILabel *bx_accountTitleLabel;
@property (nonatomic, strong) UILabel *bx_accountValueLabel;
@property (nonatomic, strong) UILabel *bx_passwordTitleLabel;
@property (nonatomic, strong) UILabel *bx_passwordValueLabel;

@property (nonatomic, strong) UIView *captureBgView;
@property (nonatomic, strong) UIImageView *captureImgView;

@property (nonatomic, strong) UIView *captureTipsBottomView;
@property (nonatomic, strong) UIImageView *captureTipsImgView;
@property (nonatomic, strong) UILabel *captureTipsLabel;

@property (nonatomic, strong) NSLayoutConstraint *constraint;
@property (nonatomic) BOOL savedAccount;

@property (nonatomic, assign) BOOL bx_didSetupConstraints;
@end

@implementation BXCaptureRegisterResultViewController

- (instancetype)init{
    NSException * exp = [NSException exceptionWithName:@"BXMobileSDK" reason:@"call -initWithAccount:password: instead of -init" userInfo:nil];
    @throw exp;
}

- (instancetype)initWithAccount:(NSString *)account password:(NSString *)password {
    self = [super init];
    if (self) {
        self.modalPresentationStyle = UIModalPresentationFullScreen;
        self.account = account;
        self.password = password;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor clearColor];
    [self setupViews];
    
    self.bx_accountValueLabel.text = self.account;
    self.bx_passwordValueLabel.text = self.password;
    NSString *displayname = BX_DISPLAY_NAME;
    if (!displayname || [displayname isEqualToString:@""] || [displayname isKindOfClass:[NSNull class]] ) {
        displayname = BX_BUNDLE_NAME;
    }
    self.bx_nameValueLabel.text = displayname;
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    if (!self.savedAccount) {
        [self loadImageFinished:[self captureImageFromView:self.contentView]];
        self.savedAccount = YES;
    }
}

- (void)setupViews {
    [self.view addSubview:self.contentView];
    
    [self.contentView addSubview:self.bx_navgationBar];
    [self.bx_navgationBar addSubview:self.bx_navgationBackgroundImgView];
    [self.bx_navgationBar addSubview:self.bx_titileLabel];
    [self.bx_navgationBar addSubview:self.bx_closeButton];
    
    [self.contentView addSubview:self.bx_nameTitleLabel];
    [self.contentView addSubview:self.bx_nameValueLabel];
    [self.contentView addSubview:self.bx_accountTitleLabel];
    [self.contentView addSubview:self.bx_accountValueLabel];
    [self.contentView addSubview:self.bx_passwordTitleLabel];
    [self.contentView addSubview:self.bx_passwordValueLabel];
    
    [self.view addSubview:self.captureTipsImgView];
    [self.view addSubview:self.captureTipsBottomView];
    [self.captureTipsImgView addSubview:self.captureTipsLabel];
    
    [self.view addSubview:self.captureBgView];
    [self.captureBgView addSubview:self.captureImgView];
    
    [self.view updateConstraintsIfNeeded];
}

- (void)updateViewConstraints {
    if (!_bx_didSetupConstraints) {
        [self.contentView autoCenterInSuperview];
        [self.contentView autoSetDimensionsToSize:CGSizeMake(338, 158)];
        
        // 导航栏
        [self.bx_navgationBar autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero excludingEdge:ALEdgeBottom];
        [self.bx_navgationBar autoSetDimension:ALDimensionHeight toSize:40];
        
        [self.bx_navgationBackgroundImgView autoPinEdgesToSuperviewEdges];
        
        [self.bx_closeButton autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:20];
        [self.bx_closeButton autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
        
        [self.bx_titileLabel autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:20];
        [self.bx_titileLabel autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
        
        [self.bx_nameTitleLabel autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_navgationBar withOffset:20];
        [self.bx_nameTitleLabel autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:20];
        
        [self.bx_nameValueLabel autoAlignAxis:ALAxisHorizontal toSameAxisOfView:self.bx_nameTitleLabel];
        [self.bx_nameValueLabel autoPinEdge:ALEdgeLeading toEdge:ALEdgeTrailing ofView:self.bx_nameTitleLabel withOffset:25];;
        
        [self.bx_accountTitleLabel autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_nameTitleLabel withOffset:10];
        [self.bx_accountTitleLabel autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:20];
        
        [self.bx_accountValueLabel autoAlignAxis:ALAxisHorizontal toSameAxisOfView:self.bx_accountTitleLabel];
        [self.bx_accountValueLabel autoPinEdge:ALEdgeLeading toEdge:ALEdgeTrailing ofView:self.bx_accountTitleLabel withOffset:25];;
        
        [self.bx_passwordTitleLabel autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_accountValueLabel withOffset:10];
        [self.bx_passwordTitleLabel autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:20];
        
        [self.bx_passwordValueLabel autoAlignAxis:ALAxisHorizontal toSameAxisOfView:self.bx_passwordTitleLabel];
        [self.bx_passwordValueLabel autoPinEdge:ALEdgeLeading toEdge:ALEdgeTrailing ofView:self.bx_passwordTitleLabel withOffset:25];
        
        [self.captureTipsBottomView autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero excludingEdge:ALEdgeTop];
        [self.captureTipsBottomView autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.captureTipsImgView];
        
        [self.captureTipsLabel autoCenterInSuperview];
        [self.captureTipsImgView autoPinEdgeToSuperviewEdge:ALEdgeLeading];
        [self.captureTipsImgView autoPinEdgeToSuperviewEdge:ALEdgeTrailing];
        [self.captureTipsImgView autoPinEdgeToSuperviewMargin:ALEdgeBottom];
        [self.captureTipsImgView autoSetDimension:ALDimensionHeight toSize:40];
        
        [self.captureImgView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:5];
        [self.captureImgView autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:5];
        [self.captureImgView autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:5];
        [self.captureImgView autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:5];

        [self.captureBgView autoSetDimensionsToSize:CGSizeMake(338*0.4, 158*0.4)];
        [self.captureBgView autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:30];
        [self.captureBgView autoPinEdge:ALEdgeBottom toEdge:ALEdgeTop ofView:self.captureTipsImgView withOffset:-2];
        
        _bx_didSetupConstraints = YES;
    }
    [super updateViewConstraints];
}

#pragma mark - Capture Image

-(UIImage *)captureImageFromView:(UIView *)view {
    CGRect rect = [view bounds];
    UIGraphicsBeginImageContextWithOptions(rect.size, YES, 0.0);
    [view.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *snapshotImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return snapshotImage;
}

- (void)loadImageFinished:(UIImage *)image{
    self.bx_closeButton.hidden = YES;
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        UIImageWriteToSavedPhotosAlbum(image, self, @selector(image:didFinishSavingWithError:contextInfo:), (__bridge void *)self);
    });
}

- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo{
    dispatch_async(dispatch_get_main_queue(), ^{
        self.bx_closeButton.hidden = NO;
        if (!error) {
            BXLogInfo(@"写入账号信息成功");
            [self showCaptureResult:image];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                UIViewController *preController = self.presentingViewController;
                [self bx_hideWithCompletion:^{
                    BXExecuteLoginViewController *bx_loginResult = [[BXExecuteLoginViewController alloc] initWithAccount:self.account password:self.password fromRegister:YES];
                    [preController presentViewController:bx_loginResult animated:YES completion:^{
                    }];
                }];
            });
        }else{
            BXLogError(@"保存账号信息失败: { code: %d, msg: %@ }}", error.code, error.localizedDescription);
            if (error.code == -3310) {
                [BXMBProgressHUD bx_showMessage:@"保存失败，请先在设置中开启相册访问权限!"];
            }else{
                [BXMBProgressHUD bx_showMessage:@"保存账号信息失败! 请妥善保管您的账号和密码。"];
            }
        }
    });
}

- (void)backEvent:(id)sender {
    UIViewController *preController = self.presentingViewController;
    [self bx_hideWithCompletion:^{
        BXExecuteLoginViewController *bx_loginResult = [[BXExecuteLoginViewController alloc] initWithAccount:self.account password:self.password fromRegister:YES];
        [preController presentViewController:bx_loginResult animated:YES completion:^{
        }];
    }];
}

- (void)showCaptureResult:(UIImage *)image {
    [self.captureImgView setImage:image];
    self.captureTipsLabel.hidden = NO;
    self.captureTipsImgView.hidden = NO;
    self.captureTipsBottomView.hidden = NO;
    self.captureImgView.hidden = NO;
    self.captureBgView.hidden = NO;
}

#pragma mark - Property

- (UIView *)contentView {
    if (!_contentView) {
        _contentView = [[UIView alloc] init];
        _contentView.backgroundColor = BXHexColor(0xFFFFFFF);
        _contentView.layer.cornerRadius = 8;
        _contentView.clipsToBounds = YES;
    }
    return _contentView;
}

//nav
- (UIView *)bx_navgationBar {
    if (!_bx_navgationBar) {
        _bx_navgationBar = [[UIView alloc] init];
    }
    return _bx_navgationBar;
}

- (UIButton *)bx_closeButton {
    if (!_bx_closeButton) {
        _bx_closeButton = [UIButton buttonWithType:UIButtonTypeCustom];
        UIImage *aImage = [UIImage imageNamed:@"nav_close_black" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
        [_bx_closeButton setImage:aImage forState:UIControlStateNormal];
        [_bx_closeButton addTarget:self action:@selector(backEvent:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _bx_closeButton;
}

- (UILabel *)bx_titileLabel {
    if (!_bx_titileLabel) {
        _bx_titileLabel = [[UILabel alloc] init];
        [_bx_titileLabel setText:@"注册账号成功"];
        [_bx_titileLabel setTextColor:BXHexColor(0x333333)];
        [_bx_titileLabel setFont:BXBoldSystemFont(14)];
    }
    return _bx_titileLabel;
}

- (UIImageView *)bx_navgationBackgroundImgView {
    if (!_bx_navgationBackgroundImgView) {
        _bx_navgationBackgroundImgView = [[UIImageView alloc] init];
    }
    return _bx_navgationBackgroundImgView;
}

- (UILabel *)bx_nameTitleLabel {
    if (!_bx_nameTitleLabel) {
        _bx_nameTitleLabel = [[UILabel alloc] init];
        [_bx_nameTitleLabel setText:@"游戏"];
        [_bx_nameTitleLabel setTextColor:BXHexColor(0x767B82)];
        [_bx_nameTitleLabel setFont:BXSystemFont(16)];
    }
    return _bx_nameTitleLabel;
}

- (UILabel *)bx_nameValueLabel {
    if (!_bx_nameValueLabel) {
        _bx_nameValueLabel = [[UILabel alloc] init];
        [_bx_nameValueLabel setText:@"387187127"];
        [_bx_nameValueLabel setTextColor:BXMainColor];
        [_bx_nameValueLabel setFont:BXSystemFont(16)];
    }
    return _bx_nameValueLabel;
}

- (UILabel *)bx_accountTitleLabel {
    if (!_bx_accountTitleLabel) {
        _bx_accountTitleLabel = [[UILabel alloc] init];
        [_bx_accountTitleLabel setText:@"账号"];
        [_bx_accountTitleLabel setTextColor:BXHexColor(0x767B82)];
        [_bx_accountTitleLabel setFont:BXSystemFont(16)];
    }
    return _bx_accountTitleLabel;
}

- (UILabel *)bx_accountValueLabel {
    if (!_bx_accountValueLabel) {
        _bx_accountValueLabel = [[UILabel alloc] init];
        [_bx_accountValueLabel setTextColor:BXMainColor];
        [_bx_accountValueLabel setFont:BXSystemFont(16)];
    }
    return _bx_accountValueLabel;
}

- (UILabel *)bx_passwordTitleLabel {
    if (!_bx_passwordTitleLabel) {
        _bx_passwordTitleLabel = [[UILabel alloc] init];
        [_bx_passwordTitleLabel setText:@"密码"];
        [_bx_passwordTitleLabel setTextColor:BXHexColor(0x767B82)];
        [_bx_passwordTitleLabel setFont:BXSystemFont(16)];
    }
    return _bx_passwordTitleLabel;
}

- (UILabel *)bx_passwordValueLabel {
    if (!_bx_passwordValueLabel) {
        _bx_passwordValueLabel = [[UILabel alloc] init];
        [_bx_passwordValueLabel setText:@"123456aa"];
        [_bx_passwordValueLabel setTextColor:BXMainColor];
        [_bx_passwordValueLabel setFont:BXSystemFont(16)];
    }
    return _bx_passwordValueLabel;
}

- (UIView *)captureBgView {
    if (!_captureBgView) {
        _captureBgView = [[UIView alloc] init];
        _captureBgView.layer.cornerRadius = 4;
        _captureBgView.backgroundColor = BXHexColor(0xFFFFFF);
        _captureBgView.layer.borderColor = BXHexColor(0x767B82).CGColor;
        _captureBgView.layer.borderWidth  =  0.5;
        _captureBgView.clipsToBounds = YES;
        _captureBgView.hidden = YES;
    }
    return _captureBgView;;
}

- (UIImageView *)captureImgView {
    if (!_captureImgView) {
        _captureImgView = [[UIImageView alloc] init];
        _captureImgView.layer.cornerRadius = 4;
        _captureImgView.layer.borderColor = BXHexColor(0x767B82).CGColor;
        _captureImgView.layer.borderWidth  =  0.5;
        _captureImgView.clipsToBounds = YES;
        _captureImgView.hidden = YES;
    }
    return _captureImgView;;
}

- (UIView *)captureTipsBottomView{
    if (!_captureTipsBottomView) {
        _captureTipsBottomView = [[UIView alloc] init];
        _captureTipsBottomView.backgroundColor = BXHexColor(0xFFFFFF);
        _captureTipsBottomView.hidden = YES;
    }
    return _captureTipsBottomView;;
}

- (UIImageView *)captureTipsImgView {
    if (!_captureTipsImgView) {
        _captureTipsImgView = [[UIImageView alloc] init];
        [_captureTipsImgView setBackgroundColor:BXHexColor(0xFFFFFF)];
        _captureTipsImgView.hidden = YES;
    }
    return _captureTipsImgView;;
}

- (UILabel *)captureTipsLabel {
    if (!_captureTipsLabel) {
        _captureTipsLabel = [[UILabel alloc] init];
        _captureTipsLabel.textColor = BXMainColor;
        [_captureTipsLabel setText:@"截图已保存至相册"];
        _captureTipsLabel.hidden = YES;
    }
    return _captureTipsLabel;;
}

@end
