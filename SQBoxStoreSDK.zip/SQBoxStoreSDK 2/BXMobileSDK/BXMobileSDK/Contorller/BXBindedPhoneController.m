//
//  BXBindedPhoneController.m
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/8/27.
//  Copyright © 2021 Gavin. All rights reserved.
//

#import "BXBindedPhoneController.h"
#import "BXMyH5Controller.h"
#import "BXPrivacyUtil.h"
#import "BXPhoneBindController.h"
#import "BXHeaderView.h"
#import "BXMobileManager.h"
#import "BXMobileManager+Private.h"

@interface BXBindedPhoneController ()

@property(strong, nonatomic) UIImageView *bx_centerImageView;

@property(strong, nonatomic) UILabel *bx_centerLabel;

@property(strong, nonatomic) UILabel *bx_leftLabel;

@property(strong, nonatomic) UILabel *bx_phoneLabel;

@property (nonatomic, assign) BOOL bx_didSetupConstraints;
@end

@implementation BXBindedPhoneController

- (void)dealloc
{
    BXLogInfo(@"%s",__func__);
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.preferredContentSize = [self orientationStatus] ? CGSizeMake(ScreenWidth, ScreenWidth) : CGSizeMake(ScreenWidth, ScreenHeight);
    }
    return self;
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [self notifitionSatatus];
}

-(void)notifitionSatatus{
    [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(statusBarOrientationChange:) name:UIApplicationDidChangeStatusBarOrientationNotification object:nil];
}
-(void)statusBarOrientationChange:(NSNotification*)notification{
    self.preferredContentSize = [self orientationStatus] ? CGSizeMake(ScreenWidth, ScreenWidth) : CGSizeMake(ScreenWidth, ScreenHeight);
    [self.bx_baseframeView autoSetDimensionsToSize:[self orientationStatus] ? CGSizeMake(ScreenWidth, ScreenWidth) : CGSizeMake(ScreenWidth, ScreenWidth)];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setupViews];
    
    self.view.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(screenTap:)];
    tap.cancelsTouchesInView = NO;
    [self.view addGestureRecognizer:tap];
}

- (void)setupViews {
    self.view.backgroundColor = UIColor.clearColor;
    
    
    [self.view addSubview:self.bx_baseframeView];
    
    [self.bx_baseframeView addSubview:self.bx_baseHeaderView];
    [self.bx_baseHeaderView bx_baseHeaderViewSetString:@"解绑手机"];
    @weakify(self)
    self.bx_baseHeaderView.bx_leftCallback = ^{
        @strongify(self)
        [self backAction:nil];
    };
    
    _bx_centerImageView = [[UIImageView alloc]init];
    _bx_centerImageView.image = [UIImage imageNamed:@"bxm_shouji" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
    [self.bx_baseframeView addSubview:_bx_centerImageView];
    
    _bx_centerLabel = [[UILabel alloc] init];
    _bx_centerLabel.text = @"已完成手机绑定";
    _bx_centerLabel.textColor = BXHexColor(0x388EFF);
    _bx_centerLabel.font = BXBoldSystemFont(12);
    _bx_centerLabel.textAlignment = NSTextAlignmentCenter;
    [self.bx_baseframeView addSubview:_bx_centerLabel];
    
    [self.bx_baseframeView addSubview:self.bx_baseBackView];
    
    _bx_leftLabel = [[UILabel alloc] init];
    _bx_leftLabel.text = @"绑定手机号";
    _bx_leftLabel.textColor = BXHexColor(0x666666);
    _bx_leftLabel.font = BXSystemFont(14);
    [self.bx_baseBackView addSubview:_bx_leftLabel];
    
    _bx_phoneLabel = [[UILabel alloc] init];
    _bx_phoneLabel.text = [BXMobileManager shareManager].currentUser.phoneNumber;
    _bx_phoneLabel.textColor = BXHexColor(0x333333);
    _bx_phoneLabel.font = BXSystemFont(14);
    [self.bx_baseBackView addSubview:_bx_phoneLabel];
    
    [self.bx_baseNextBtn setTitle:@"解除绑定" forState:UIControlStateNormal];
    [self.bx_baseNextBtn addTarget:self action:@selector(bx_baseNextBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.bx_baseframeView addSubview:self.bx_baseNextBtn];
    
    [self.view updateConstraintsIfNeeded];
}


- (void)updateViewConstraints {
    if (!_bx_didSetupConstraints) {
        [self.bx_baseframeView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0];
        [self.bx_baseframeView autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:0];
        [self.bx_baseframeView autoSetDimensionsToSize:[self orientationStatus] ? CGSizeMake(ScreenHeight, ScreenHeight) : CGSizeMake(ScreenWidth, ScreenWidth)];
        
        [self.bx_baseHeaderView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0];
        [self.bx_baseHeaderView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:0];
        [self.bx_baseHeaderView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:0];
        [self.bx_baseHeaderView autoSetDimension:ALDimensionHeight toSize:40];
        
        [self.bx_centerImageView sizeToFit];
        [self.bx_centerImageView autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_baseHeaderView withOffset:20];
        [self.bx_centerImageView autoAlignAxis:ALAxisVertical toSameAxisOfView:self.bx_baseframeView withOffset:0];
        
        [self.bx_centerLabel sizeToFit];
        [self.bx_centerLabel autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_centerImageView withOffset:10];
        [self.bx_centerLabel autoAlignAxis:ALAxisVertical toSameAxisOfView:self.bx_baseframeView withOffset:0];
        
        [self.bx_baseBackView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:14];
        [self.bx_baseBackView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:14];
        [self.bx_baseBackView autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_centerLabel withOffset:14];
        [self.bx_baseBackView autoSetDimension:ALDimensionHeight toSize:42];
        
        [self.bx_leftLabel autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:0];
        [self.bx_leftLabel autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:10];
        [self.bx_leftLabel autoMatchDimension:ALDimensionHeight toDimension:ALDimensionHeight ofView:self.bx_baseBackView];
        
        [self.bx_phoneLabel autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:0];
        [self.bx_phoneLabel autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.bx_leftLabel withOffset:14];
        [self.bx_phoneLabel autoMatchDimension:ALDimensionHeight toDimension:ALDimensionHeight ofView:self.bx_baseBackView];
        
        [self.bx_baseNextBtn autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:14];
        [self.bx_baseNextBtn autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:14];
        [self.bx_baseNextBtn autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_baseBackView withOffset:14];
        [self.bx_baseNextBtn autoSetDimension:ALDimensionHeight toSize:40];
        
        _bx_didSetupConstraints = YES;
    }
    [super updateViewConstraints];
}

-(void)backAction:(UIButton *)sender{
    [self bx_hideWithCompletion:^{
        
    }];
}

-(void)bx_baseNextBtnAction:(UIButton *)sender{
    BXPhoneBindController *vc = [[BXPhoneBindController alloc]initWithType:1];
    @weakify(self)
    vc.btnBlock = ^{
        @strongify(self)
        if (self.actionDisBlock) {
            self.actionDisBlock();
        }
        [self bx_hideWithCompletion:nil];
    };
    [self presentViewController:vc animated:YES completion:^{
    }];
}

- (void)screenTap:(UITapGestureRecognizer *)gesture {
    CGPoint p = [gesture locationInView:self.view];
    if (!CGRectContainsPoint(self.bx_baseframeView.frame, p)) {
        [self dismissToRootViewController];
    }
}

-(void)dismissToRootViewController{
    UIViewController *vc = self;
    while (vc.presentingViewController) {
        vc = vc.presentingViewController;
    }
    [vc dismissViewControllerAnimated:YES completion:nil];
}

@end
