//
//  BXBaseViewController.m
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/20.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXBaseViewController.h"
#import "FYLDialogTransitionDelegate.h"
#import "BXMBProgressHUD+BXExtern.h"

@interface BXBaseViewController ()
@property (nonatomic, strong) FYLDialogTransitionDelegate * dialogTransitionDelegate;
@property (nonatomic, weak) UIViewController *bx_presentingViewController;
@property (nonatomic, assign) BOOL isHiding;
@end

@implementation BXBaseViewController

- (instancetype)init
{
    self = [super init];
    if (self) {
        FYLDialogTransitionDelegate * dialogTransitionDelegate = [[FYLDialogTransitionDelegate alloc] init];
        self.dialogTransitionDelegate = dialogTransitionDelegate;
        self.modalPresentationStyle = UIModalPresentationCustom;
        self.transitioningDelegate = self.dialogTransitionDelegate;
        self.preferredContentSize = BXPreferredContentSize;
        if (!isSmallScreen) {
            self.preferredContentSize = BXPreferredContentSize;
        }else{
            self.preferredContentSize = BXPreferredContentSmallSize;
        }
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Do any additional setup after loading the view.
    self.view.backgroundColor = BXHexColor(0xFFFFFF);
    self.edgesForExtendedLayout = UIRectEdgeNone;
    self.view.layer.cornerRadius = 8;
    self.view.clipsToBounds = YES;
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    
    [self.view endEditing:YES];
}

-(BXHeaderView *)bx_baseHeaderView{
    if (!_bx_baseHeaderView) {
        _bx_baseHeaderView = [[BXHeaderView alloc]initWithFrame:CGRectZero];
    }
    return  _bx_baseHeaderView;
}

-(UIImageView *)bx_baseframeView{
    if (!_bx_baseframeView) {
        _bx_baseframeView = [[UIImageView alloc]init];
        _bx_baseframeView.backgroundColor = BXHexAColor(0xF5F5F5,0.95);
        _bx_baseframeView.layer.cornerRadius = 8;
        _bx_baseframeView.userInteractionEnabled = YES;
        _bx_baseframeView.clipsToBounds = YES;
    }
    return _bx_baseframeView;
}

-(UIImageView *)bx_baseBackView{
    if (!_bx_baseBackView) {
        _bx_baseBackView = [[UIImageView alloc]init];
        _bx_baseBackView.backgroundColor = BXBackgroundColor;
        _bx_baseBackView.userInteractionEnabled = YES;
        
        _bx_baseBackView.layer.masksToBounds = YES;
        _bx_baseBackView.layer.shadowColor = BXHexAColor(0x388EFF, 0.1).CGColor;
        _bx_baseBackView.layer.shadowOffset = CGSizeMake(0, 0);
        _bx_baseBackView.layer.shadowRadius = 8;
        _bx_baseBackView.layer.shadowOpacity = 1;
        _bx_baseBackView.layer.cornerRadius = 8;
    }
    return  _bx_baseBackView;
}

-(UIButton *)bx_baseNextBtn{
    if (!_bx_baseNextBtn) {
        _bx_baseNextBtn = [UIButton buttonWithType:UIButtonTypeSystem];
        [_bx_baseNextBtn setTitleColor:BXBackgroundColor forState:UIControlStateNormal];
        [_bx_baseNextBtn setBackgroundImage:[UIImage imageNamed:@"bxm_Anniu" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
        [_bx_baseNextBtn setTitle:@"" forState:UIControlStateNormal];
        _bx_baseNextBtn.titleLabel.font = BXSystemFont(14);
    }
    return _bx_baseNextBtn;
}

#pragma mark - present and dissmiss

- (void)bx_presentWithViewController:(UIViewController *)presentingViewController;
{
    if (presentingViewController == nil) {
        UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
        if (keyWindow.windowLevel != UIWindowLevelNormal) {
            NSArray *windows = [[UIApplication sharedApplication] windows];
            for (UIWindow *temp in windows) {
                if (temp.windowLevel == UIWindowLevelNormal) {
                    keyWindow = temp;
                    break;
                }
            }
        }
           
        //取当前展示的控制器
        self.bx_presentingViewController = keyWindow.rootViewController;
        NSAssert(self.bx_presentingViewController != nil, @"Application must have a root view controller.");
        presentingViewController = self.bx_presentingViewController;
    }
    
    [presentingViewController presentViewController:self animated:YES completion:^{
    }];
}

- (void)bx_hideWithCompletion:(void(^)(void))completion
{
    if (self.isHiding) return;
    self.isHiding = YES;

    [[self presentingViewController] dismissViewControllerAnimated:YES completion:^{
        if (completion) completion();
    }];
}

- (void)bx_dismissPresentedViewController:(UIViewController *)vc completionBlock:(void(^)(void))completionBlock {
    // if vc is presented by other view controller, dismiss it.
    if ([vc presentingViewController] && [vc.transitioningDelegate isKindOfClass:[FYLDialogTransitionDelegate class]]) {
        __block UIViewController* nextVC = vc.presentingViewController;
        [vc dismissViewControllerAnimated:NO completion:^ {
            if ([nextVC presentingViewController]) {
                [self bx_dismissPresentedViewController:nextVC completionBlock:completionBlock];
            } else {
                if (completionBlock != nil) {
                    completionBlock();
                }
            }
        }];
    } else {
        if (completionBlock != nil) {
            completionBlock();
        }
    }
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
    [super touchesEnded:touches withEvent:event];
}

- (BOOL)orientationStatus{
    UIInterfaceOrientation orientation = [[UIApplication sharedApplication] statusBarOrientation];
    if (orientation == UIInterfaceOrientationLandscapeRight || orientation == UIInterfaceOrientationLandscapeLeft) // home键靠右
    {
        return YES;
    }
    if (orientation == UIInterfaceOrientationPortrait)//home在下
    {
        return  NO;
    }
    return  NO;
}

@end
