//
//  BXPrivacyWebController.m
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/9/2.
//  Copyright © 2021 Gavin. All rights reserved.
//

#import "BXPrivacyWebController.h"
#import <WebKit/WebKit.h>
#import "BXSeviceAndPrivacyViewController.h"
#import "BXConfig.h"

@interface BXPrivacyWebController ()<WKNavigationDelegate, WKScriptMessageHandler>
@property (strong, nonatomic) WKWebView *wkView;
@property (strong, nonatomic) UIButton *refreshBtn;
@property (strong, nonatomic) UILabel *label;

@property (nonatomic, assign) BOOL bx_didSetupConstraints;

@end

@implementation BXPrivacyWebController

- (void)dealloc
{
    BXLogInfo(@"%s",__func__);
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

- (void)viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];
    
    self.preferredContentSize = CGSizeMake(338, 320);
}

- (NSAttributedString *)frameTitle
{
    NSDictionary *attDic = @{NSForegroundColorAttributeName:[UIColor whiteColor],
                             NSFontAttributeName:BXSystemFont(17)};
    NSAttributedString *att = [[NSAttributedString alloc]initWithString:@"" attributes:attDic];
    return att;
}

- (UIButton *)refreshBtn {
    if (!_refreshBtn) {
        _refreshBtn = [UIButton buttonWithType:UIButtonTypeSystem];
        [_refreshBtn setImage:[UIImage bx_bundleImageWithName:@"bxm_shuaxin"] forState:(UIControlStateNormal)];
        [_refreshBtn addTarget:self action:@selector(loadUrl) forControlEvents:UIControlEventTouchUpInside];
    }
    return _refreshBtn;
}

- (UILabel *)label {
    if (!_label) {
        _label = [[UILabel alloc] init];
        _label.text = @"加载失败，请重试";
        _label.textColor = BXHexAColor(0xFFFFFF, 0.75);
        if (@available(iOS 9.0, *)) {
            _label.font = [UIFont preferredFontForTextStyle:UIFontTextStyleCallout];
        } else {
            // Fallback on earlier versions
        }
    }
    return _label;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setupViews];
}

- (void)setupViews {
    
    self.view.backgroundColor = UIColor.clearColor;

    _wkView = [[WKWebView alloc] initWithFrame:CGRectZero];
    [self.view addSubview:_wkView];
    _wkView.navigationDelegate = self;

    [self.view addSubview:self.refreshBtn];
    [self.view addSubview:self.label];

    [self registerJSMethod];
    [self loadUrl];
    
    [self.view updateConstraintsIfNeeded];
}

- (void)updateViewConstraints {
    if (!_bx_didSetupConstraints) {

        [self.wkView autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero];
        
        [self.refreshBtn autoSetDimensionsToSize:CGSizeMake(44, 44)];
        [self.refreshBtn autoCenterInSuperview];
        
        [self.label sizeToFit];
        [self.label autoAlignAxisToSuperviewAxis:ALAxisVertical];
        [self.label autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.refreshBtn withOffset:8];
        
        _bx_didSetupConstraints = YES;
    }
    [super updateViewConstraints];
}

- (void)registerJSMethod {
    [_wkView.configuration.userContentController addScriptMessageHandler:self name:kAgreedMethod]; // 同意
    [_wkView.configuration.userContentController addScriptMessageHandler:self name:kRefuseMethod]; // 拒绝
    [_wkView.configuration.userContentController addScriptMessageHandler:self name:kOpenUserProtocol];
    [_wkView.configuration.userContentController addScriptMessageHandler:self name:kOpenPrivacyProtocol];
}

- (void)loadUrl {
    BXLog(@"开始加载url - %@", _urlStr);
    NSURL *url = [NSURL URLWithString:_urlStr];
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
    [_wkView loadRequest:request];
}

- (void)showWebView:(BOOL)show {
    _refreshBtn.hidden = show;
    _label.hidden = show;
    _wkView.hidden = !show;
}

#pragma mark - WKScriptMessageHandler
- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message {
    BXLog(@"收到h5调起 - name - %@, body - %@", message.name, message.body);
    if ([message.name isEqualToString:kAgreedMethod]) {
        BXLog(@"用户选取同意协议");
        [self backEvent:nil];
        if (_WebBtnCallback) {
            _WebBtnCallback(YES);
        }
    } else if ([message.name isEqualToString:kRefuseMethod]) {
        BXLog(@"用户选取拒绝协议");
        [self backEvent:nil];
        if (_WebBtnCallback) {
            _WebBtnCallback(NO);
        }
    } if ([message.name isEqualToString:kOpenUserProtocol] || [message.name isEqualToString:kOpenPrivacyProtocol]) {
        if ([message.name isEqualToString:kOpenUserProtocol]) {
            [self showServiceAgreementEvent];
        } else if ([message.name isEqualToString:kOpenPrivacyProtocol]) {
            [self showPrivacyPolicyEvent];
        }
    }
}

- (void)showServiceAgreementEvent {
    if ([BXConfig config].configState != BXConfigStateSUC) {
        return;
    }
    NSString *bx_serviceAgreementUrl = [NSString stringWithFormat:@"%@agree/%@_appstore/user_protocol.html", [BXConfig config].cdnImgServer, [BXConfig config].platformId];
    BXLogInfo(@"bxm_serviceAgreementUrl = %@", bx_serviceAgreementUrl);
    BXSeviceAndPrivacyViewController *bx_seviceAndPrivacyController = [[BXSeviceAndPrivacyViewController alloc] initWithUrl:[NSURL URLWithString:bx_serviceAgreementUrl] pageType:BXPageType_UserPrivate];
    [self presentViewController:bx_seviceAndPrivacyController animated:YES completion:nil];
}

- (void)showPrivacyPolicyEvent {
    if ([BXConfig config].configState != BXConfigStateSUC) {
        return;
    }
    NSString *bx_privacyPolicyUrl = [NSString stringWithFormat:@"%@agree/%@_appstore/privacy_policy_transparent_black_text.html", [BXConfig config].cdnImgServer, [BXConfig config].platformId];
    BXLogInfo(@"bxm_serviceAgreementUrl = %@", bx_privacyPolicyUrl);
    BXSeviceAndPrivacyViewController *bx_seviceAndPrivacyController = [[BXSeviceAndPrivacyViewController alloc] initWithUrl:[NSURL URLWithString:bx_privacyPolicyUrl] pageType:BXPageType_UserPrivate];
    [self presentViewController:bx_seviceAndPrivacyController animated:YES completion:nil];
}

- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler {
    BXLog(@"发送请求之前，决定是否跳转");
    decisionHandler(WKNavigationActionPolicyAllow);
}

- (void)webView:(WKWebView *)webView decidePolicyForNavigationResponse:(WKNavigationResponse *)navigationResponse decisionHandler:(void (^)(WKNavigationResponsePolicy))decisionHandler {
    BXLog(@"收到响应后，是否跳转");
    decisionHandler(WKNavigationResponsePolicyAllow);
}

- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation {
    BXLog(@"页面开始加载");
    [self showWebView:YES];
}

- (void)webView:(WKWebView *)webView didReceiveServerRedirectForProvisionalNavigation:(WKNavigation *)navigation {
    BXLog(@"接收到服务器跳转请求之后调用");
}

- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(WKNavigation *)navigation withError:(NSError *)error {
    BXLog(@"页面加载失败，注意不要漏掉这部分的处理噢，特别是全屏显示网页，而又没有关闭的原生按钮时");
    [self showWebView:NO];
}

- (void)webView:(WKWebView *)webView didCommitNavigation:(WKNavigation *)navigation {
    BXLog(@"内容开始返回");
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation {
    BXLog(@"页面加载完成后");
    [self showWebView:YES];
}

- (void)backEvent:(id)sender {
    [self bx_hideWithCompletion:^{
    }];
}

@end
