//
//  BXUserDataManagerController.h
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/8/27.
//  Copyright © 2021 Gavin. All rights reserved.
//

#import "BXBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface BXUserDataManagerController : BXBaseViewController

@end

NS_ASSUME_NONNULL_END
