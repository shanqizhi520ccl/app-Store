//
//  BXSupportViewController.m
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/31.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXSupportViewController.h"
#import <WebKit/WebKit.h>

@interface BXSupportViewController ()<WKUIDelegate, WKNavigationDelegate>
@property (nonatomic, readwrite) NSURL *url;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UIButton *closeButton;
@property (nonatomic, strong) UIView *navgationBar;
@property (nonatomic, strong) WKWebView *webView;
@property (nonatomic, assign) BOOL bx_didSetupConstraints;
@end

@implementation BXSupportViewController

#ifdef DEBUG
- (void)dealloc
{
    BXLogDebug(@"%@ dealloc", self.class);
    [self.webView removeObserver:self forKeyPath:@"title"];
}
#else
- (void)dealloc
{
    [self.webView removeObserver:self forKeyPath:@"title"];
}
#endif

- (instancetype)initWithUrl:(NSURL *)url
{
    self = [super init];
    if (self) {
        self.url = url;
        self.modalPresentationStyle = UIModalPresentationFullScreen;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self.view addSubview:self.navgationBar];
    [self.navgationBar addSubview:self.titleLabel];
    [self.navgationBar addSubview:self.closeButton];
    [self.view addSubview:self.webView];
    
    [self.view updateConstraintsIfNeeded];
    
    [self.webView addObserver:self forKeyPath:@"title" options:NSKeyValueObservingOptionNew context:NULL];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    if (self.url) {
        [self.webView loadRequest:[NSURLRequest requestWithURL:self.url]];
    }
}

- (void)updateViewConstraints {
    if (!_bx_didSetupConstraints) {
        [self.navgationBar autoPinEdgesToSuperviewMarginsExcludingEdge:ALEdgeBottom];
        [self.navgationBar autoSetDimension:ALDimensionHeight toSize:48];
        
        [self.titleLabel autoAlignAxisToSuperviewAxis:ALAxisVertical];
        [self.titleLabel autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
        
        [self.closeButton autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
        [self.closeButton autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:0];
    
        [self.webView autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.navgationBar];
        [self.webView autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero excludingEdge:ALEdgeTop];
        
        _bx_didSetupConstraints = YES;
    }
    [super updateViewConstraints];
}

#pragma mark - Property Getter

- (UIView *)navgationBar {
    if (!_navgationBar) {
        _navgationBar = [[UIView alloc] init];
        [_navgationBar  setBackgroundColor:[UIColor whiteColor]];
    }
    return _navgationBar;
}

- (UILabel *)titleLabel {
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc] init];
        [_titleLabel setText:@"加载中..."];
        [_titleLabel setTextColor:BXMainColor];
        [_titleLabel setFont:BXSystemFont(17)];
        [_titleLabel setTextAlignment:NSTextAlignmentCenter];
    }
    return _titleLabel;
}

- (UIButton *)closeButton {
    if (!_closeButton) {
        _closeButton = [[UIButton alloc] init];
        UIImage *aImage = [UIImage imageNamed:@"nav_close_black" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
        [_closeButton setImage:aImage forState:UIControlStateNormal];
        [_closeButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_closeButton addTarget:self action:@selector(closeEvent:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _closeButton;
}

- (WKWebView *)webView{
    if(_webView == nil){
        //创建网页配置对象
        WKWebViewConfiguration *config = [[WKWebViewConfiguration alloc] init];
        
        // 创建设置对象
        WKPreferences *preference = [[WKPreferences alloc] init];
        //最小字体大小 当将javaScriptEnabled属性设置为NO时，可以看到明显的效果
        preference.minimumFontSize = 0;
        //设置是否支持javaScript,默认支持
        preference.javaScriptEnabled = YES;
        // 在iOS上默认为NO，表示是否允许不经过用户交互由javaScript自动打开窗口
        preference.javaScriptCanOpenWindowsAutomatically = YES;
        
        config.preferences = preference;

        WKUserContentController * wkUController = [[WKUserContentController alloc] init];
        config.userContentController = wkUController;
        
        _webView = [[WKWebView alloc] initWithFrame:CGRectZero configuration:config];
        _webView.UIDelegate = self;
        _webView.navigationDelegate = self;
    }
    return _webView;
}

#pragma mark - User Response

- (void)closeEvent:(id)sender {
    [self bx_hideWithCompletion:^{
    }];
}

#pragma mark - WKNavigationDelegate

- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error {
    //[self hideWithCompletion:nil];
    BXLogError(@"load url error: %@", error.localizedDescription);
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(null_unspecified WKNavigation *)navigation {
    BXLogError(@"finish load url");
}

//- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler {
//    if (![navigationAction.request.URL.scheme isEqualToString:@"http"] &&
//        ![navigationAction.request.URL.scheme isEqualToString:@"https"]) {
//        [[UIApplication sharedApplication] openURL:navigationAction.request.URL];
//        decisionHandler(WKNavigationActionPolicyCancel);
//    }else{
//        decisionHandler(WKNavigationActionPolicyAllow);
//    }
//}

#pragma mark - Web KVO

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
    if ([keyPath isEqualToString:@"title"]) {
        if (object == self.webView){
            self.titleLabel.text = self.webView.title;
        }else{
            [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
        }
    }else{
        [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
    }
}

@end
