//
//  BXNoticeViewController.m
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/24.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXNoticeViewController.h"
#import <WebKit/WebKit.h>
#import "BXNotifyCell.h"

@interface BXNoticeViewController ()<UITableViewDelegate, UITableViewDataSource>
@property (nonatomic, strong) UIButton *closeButton;
@property (nonatomic, strong) UIView *contentView;
@property (nonatomic, strong) UIImageView *backgroundImgView;

@property (nonatomic, strong) UIView *navigationSectionView;
@property (nonatomic, strong) UIImageView *navgationBackgroundImageView;
@property (nonatomic, strong) UIImageView *titleImageView;
@property (nonatomic, strong) UIImageView *titleLeftImageView;
@property (nonatomic, strong) UIImageView *titleRightImageView;

@property (nonatomic, strong) UIView *itemSelectSectionView;
@property (nonatomic, strong) UITableView *itemsListTableView;

@property (nonatomic, strong) UIView *itemDetailSectionView;
@property (nonatomic, strong) UIImageView *detailBackgroundImageView;

@property (nonatomic, strong) WKWebView *webView;

@property (nonatomic, strong) NSArray *notifies;

@property (nonatomic, strong) NSLayoutConstraint *constraint;

@property (nonatomic, assign) BOOL bx_didSetupConstraints;

@end

@implementation BXNoticeViewController

- (instancetype)initWithNotifies:(NSArray *)notifies
{
    self = [super init];
    if (self) {
        self.notifies = notifies;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor clearColor];
    
    [self.view addSubview:self.contentView];
    [self.contentView addSubview:self.backgroundImgView];
    [self.view addSubview:self.closeButton];
    
    //导航栏
    [self.contentView addSubview:self.navigationSectionView];
    [self.navigationSectionView addSubview:self.navgationBackgroundImageView];
    [self.navigationSectionView addSubview:self.titleImageView];
    [self.navigationSectionView addSubview:self.titleLeftImageView];
    [self.navigationSectionView addSubview:self.titleRightImageView];
    
    //列表栏
    [self.contentView addSubview:self.itemSelectSectionView];
    [self.itemSelectSectionView addSubview:self.itemsListTableView];
    
    //详情栏
    [self.contentView addSubview:self.itemDetailSectionView];
    [self.itemDetailSectionView addSubview:self.detailBackgroundImageView];
    [self.itemDetailSectionView addSubview:self.webView];
    
    NSArray *images = @[@"notify_corner_top_left",
                        @"notify_corner_top_right",
                        @"notify_corner_bottom_left",
                        @"notify_corner_bottom_right"];
    NSInteger index = 0;
    for (NSString *image in images) {
        UIImage *aImage = [UIImage imageNamed:image inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
        UIImageView *imageView = [[UIImageView alloc] initWithImage:aImage];
        [self.itemDetailSectionView addSubview:imageView];
        
        CGFloat offset = 5;
        switch (index) {
            case 0:
                [imageView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:offset];
                [imageView autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:offset];
                break;
            case 1:
                [imageView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:offset];
                [imageView autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:offset];
                break;
            case 2:
                [imageView autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:offset];
                [imageView autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:offset];
                break;
            case 3:
                [imageView autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:offset];
                [imageView autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:offset];
                break;
                
            default:
                break;
        }
        index++;
    }
    
    [self.view updateConstraintsIfNeeded];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self.itemsListTableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] animated:NO scrollPosition:UITableViewScrollPositionNone];
    [self.webView loadHTMLString:[self.notifies.firstObject objectForKey:@"Info"] baseURL:nil];
}

- (void)updateViewConstraints {
    if (!_bx_didSetupConstraints) {
        [self.closeButton autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:12];
        [self.closeButton autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:5];
        
        [self.contentView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:12];
        [self.contentView autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:18];
        [self.contentView autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:12];
        [self.contentView autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:18];
        
        [self.backgroundImgView autoPinEdgesToSuperviewEdges];
        
        [self.navigationSectionView autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero excludingEdge:ALEdgeBottom];
        [self.navigationSectionView autoSetDimension:ALDimensionHeight toSize:44];
        
        [self.navgationBackgroundImageView autoPinEdgesToSuperviewEdges];
        [@[self.titleLeftImageView, self.titleImageView, self.titleRightImageView]  autoAlignViewsToAxis:ALAxisHorizontal];
        [self.titleImageView autoCenterInSuperview];
        [self.titleLeftImageView autoPinEdge:ALEdgeTrailing toEdge:ALEdgeLeading ofView:self.titleImageView withOffset:-10];
        [self.titleRightImageView autoPinEdge:ALEdgeLeading toEdge:ALEdgeTrailing ofView:self.titleImageView withOffset:10];
        
        [self.itemSelectSectionView autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.navigationSectionView];
        [self.itemSelectSectionView autoPinEdgeToSuperviewEdge:ALEdgeLeading];
        [self.itemSelectSectionView autoPinEdgeToSuperviewEdge:ALEdgeBottom];
        self.constraint = [self.itemSelectSectionView autoSetDimension:ALDimensionWidth toSize:120];
        
        [self.itemsListTableView autoPinEdgesToSuperviewEdges];
        
        [self.itemDetailSectionView autoPinEdge:ALEdgeTop toEdge:ALEdgeTop ofView:self.itemSelectSectionView];
        [self.itemDetailSectionView autoPinEdgeToSuperviewEdge:ALEdgeTrailing];
        [self.itemDetailSectionView autoPinEdgeToSuperviewEdge:ALEdgeBottom];
        [self.itemDetailSectionView autoPinEdge:ALEdgeLeading toEdge:ALEdgeTrailing ofView:self.itemSelectSectionView];
        
        [self.detailBackgroundImageView autoPinEdgesToSuperviewEdges];
        
        [self.webView autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsMake(15, 15, 15, 15)];
        
        _bx_didSetupConstraints = YES;
    }
    [super updateViewConstraints];
}

- (void)viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];
    
    UIInterfaceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation;
    if (UIInterfaceOrientationIsLandscape(orientation)) {
        if (!isSmallScreen) {
            self.preferredContentSize =  CGSizeMake(565+36, 308+24);
        }else{
            self.preferredContentSize =  CGSizeMake(538, 300);
        }
        self.constraint.constant = 120;
    }else{
        self.preferredContentSize =  CGSizeMake(ScreenWidth, ScreenWidth*0.8);
        self.constraint.constant = 80;
    }
}

- (UIButton *)closeButton {
    if (!_closeButton) {
        _closeButton = [[UIButton alloc] init];
        UIImage *aImage = [UIImage imageNamed:@"notify_close" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
        [_closeButton setImage:aImage forState:UIControlStateNormal];
        [_closeButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_closeButton addTarget:self action:@selector(closeEvent:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _closeButton;
}

- (UIView *)contentView {
    if (!_contentView) {
        _contentView = [[UIView alloc] init];
        [_contentView setBackgroundColor:[UIColor clearColor]];
    }
    return _contentView;
}

- (UIImageView *)backgroundImgView {
    if (!_backgroundImgView) {
        UIImage *aImage = [UIImage imageNamed:@"notify_bg" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
        _backgroundImgView = [[UIImageView alloc] initWithImage:aImage];
        _backgroundImgView.backgroundColor = [UIColor colorWithWhite:1 alpha:0.6];
    }
    return _backgroundImgView;
}

- (UIView *)navigationSectionView {
    if (!_navigationSectionView) {
        _navigationSectionView = [[UIView alloc] init];
        [_navigationSectionView  setBackgroundColor:[UIColor clearColor]];
    }
    return _navigationSectionView;
}

- (UIImageView *)navgationBackgroundImageView {
    if (!_navgationBackgroundImageView) {
        _navgationBackgroundImageView = [[UIImageView alloc] init];
        _navgationBackgroundImageView.backgroundColor = BXHexAColor(0x083e2f, 0.3);
    }
    return _navgationBackgroundImageView;
}

- (UIImageView *)titleImageView {
    if (!_titleImageView) {
        UIImage *aImage = [UIImage imageNamed:@"notify_title" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
        _titleImageView = [[UIImageView alloc] initWithImage:aImage];
    }
    return _titleImageView;
}

- (UIImageView *)titleLeftImageView {
    if (!_titleLeftImageView) {
        UIImage *aImage = [UIImage imageNamed:@"notify_title_left" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
        _titleLeftImageView = [[UIImageView alloc] initWithImage:aImage];
    }
    return _titleLeftImageView;
}

- (UIImageView *)titleRightImageView {
    if (!_titleRightImageView) {
        UIImage *aImage = [UIImage imageNamed:@"notify_title_right" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
        _titleRightImageView = [[UIImageView alloc] initWithImage:aImage];
    }
    return _titleRightImageView;
}

- (UIView *)itemSelectSectionView {
    if (!_itemSelectSectionView) {
        _itemSelectSectionView = [[UIView alloc] init];
        [_itemSelectSectionView  setBackgroundColor:[UIColor clearColor]];
    }
    return _itemSelectSectionView;
}

- (UITableView *)itemsListTableView {
    if (!_itemsListTableView ) {
        _itemsListTableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _itemsListTableView.dataSource = self;
        _itemsListTableView.delegate = self;
        _itemsListTableView.backgroundColor = [UIColor clearColor];
        _itemsListTableView.separatorColor = [UIColor clearColor];
        
        UIImage *aImage = [UIImage imageNamed:@"notify_table_bg" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
        UIImageView *imageView = [[UIImageView alloc] initWithImage:aImage];
        _itemsListTableView.backgroundView = imageView;
        
        [_itemsListTableView registerClass:[BXNotifyCell class] forCellReuseIdentifier:@"NotifyCellIdentifier"];
    }
    return _itemsListTableView;;
}

- (UIView *)itemDetailSectionView {
    if (!_itemDetailSectionView) {
        _itemDetailSectionView = [[UIView alloc] init];
        [_itemDetailSectionView  setBackgroundColor:[UIColor clearColor]];
    }
    return _itemDetailSectionView;
}

- (UIImageView *)detailBackgroundImageView {
    if (!_detailBackgroundImageView) {
        _detailBackgroundImageView = [[UIImageView alloc] init];
    }
    return _detailBackgroundImageView;
}

- (WKWebView *)webView{
    if(_webView == nil){
        //创建网页配置对象
        WKWebViewConfiguration *config = [[WKWebViewConfiguration alloc] init];
        
        // 创建设置对象
        WKPreferences *preference = [[WKPreferences alloc] init];
        //最小字体大小 当将javaScriptEnabled属性设置为NO时，可以看到明显的效果
        preference.minimumFontSize = 0;
        //设置是否支持javaScript,默认支持
        preference.javaScriptEnabled = YES;
        // 在iOS上默认为NO，表示是否允许不经过用户交互由javaScript自动打开窗口
        preference.javaScriptCanOpenWindowsAutomatically = YES;
        
        config.preferences = preference;

        WKUserContentController * wkUController = [[WKUserContentController alloc] init];
        config.userContentController = wkUController;
        
        _webView = [[WKWebView alloc] initWithFrame:CGRectZero configuration:config];
        _webView.backgroundColor = [UIColor clearColor];
        _webView.opaque = NO;
    }
    return _webView;
}

#pragma mark - User Response

- (void)closeEvent:(id)sender {
    [self bx_dismissPresentedViewController:self completionBlock:^{
    }];
}

#pragma mark - Table delegate and datasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.notifies.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"NotifyCellIdentifier" forIndexPath:indexPath];
    
    
    id obj = [self.notifies objectAtIndex:indexPath.row];
    [cell.textLabel setText:[obj valueForKey:@"Title"]];
    return cell;;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [self.webView loadHTMLString:[[self.notifies objectAtIndex:indexPath.row] objectForKey:@"Info"] baseURL:nil];
}

@end
