//
//  BXVerifyController.h
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/8/30.
//  Copyright © 2021 Gavin. All rights reserved.
//

#import "BXBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN
typedef void (^VerifyBtnCallback)(void);

@interface BXVerifyController : BXBaseViewController

@property (copy, nonatomic) VerifyBtnCallback verifyCallback;

@end

NS_ASSUME_NONNULL_END
