//
//  BXVerifyedController.m
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/8/27.
//  Copyright © 2021 Gavin. All rights reserved.
//

#import "BXVerifyedController.h"
#import "BXMyH5Controller.h"
#import "BXPrivacyUtil.h"
#import "BXPhoneBindController.h"
#import "BXMobileManager.h"
#import "BXUser.h"
#import "BXMobileManager+Private.h"

@interface BXVerifyedController ()

@property(strong, nonatomic) UIImageView *bx_centerImageView;

@property(strong, nonatomic) UILabel *bx_centerLabel;

@property(strong, nonatomic) UILabel *bx_nameleftLabel;

@property(strong, nonatomic) UILabel *bx_nameRightLabel;

@property(strong, nonatomic) UILabel *bx_verifyleftLabel;

@property(strong, nonatomic) UILabel *bx_verifyRightLabel;

@property(strong, nonatomic) UILabel *bx_phoneleftLabel;

@property(strong, nonatomic) UILabel *bx_phoneRightLabel;

@property (nonatomic, assign) BOOL bx_didSetupConstraints;
@end

@implementation BXVerifyedController

- (void)dealloc
{
    BXLogInfo(@"%s",__func__);
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.preferredContentSize = [self orientationStatus] ? CGSizeMake(ScreenWidth, ScreenWidth) : CGSizeMake(ScreenWidth, ScreenHeight);
    }
    return self;
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [self notifitionSatatus];
}

-(void)notifitionSatatus{
    [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(statusBarOrientationChange:) name:UIApplicationDidChangeStatusBarOrientationNotification object:nil];
}
-(void)statusBarOrientationChange:(NSNotification*)notification{
    self.preferredContentSize = [self orientationStatus] ? CGSizeMake(ScreenWidth, ScreenWidth) : CGSizeMake(ScreenWidth, ScreenHeight);
    [self.bx_baseframeView autoSetDimensionsToSize:[self orientationStatus] ? CGSizeMake(ScreenWidth, ScreenWidth) : CGSizeMake(ScreenWidth, ScreenWidth)];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setupViews];
    
    self.view.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(screenTap:)];
    tap.cancelsTouchesInView = NO;
    [self.view addGestureRecognizer:tap];
}

- (void)setupViews {
    self.view.backgroundColor = UIColor.clearColor;
    
    [self.view addSubview:self.bx_baseframeView];
    
    [self.bx_baseframeView addSubview:self.bx_baseHeaderView];
    [self.bx_baseHeaderView bx_baseHeaderViewSetString:@"实名认证"];
    @weakify(self)
    self.bx_baseHeaderView.bx_leftCallback = ^{
        @strongify(self)
        [self backAction:nil];
    };
    
    _bx_centerImageView = [[UIImageView alloc]init];
    _bx_centerImageView.image = [UIImage imageNamed:@"bxm_shenfenzheng" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
    [self.bx_baseframeView addSubview:_bx_centerImageView];
    
    _bx_centerLabel = [[UILabel alloc] init];
    _bx_centerLabel.text = @"已完成实名认证";
    _bx_centerLabel.textColor = BXHexColor(0x388EFF);
    _bx_centerLabel.font = BXBoldSystemFont(12);
    _bx_centerLabel.textAlignment = NSTextAlignmentCenter;
    [self.bx_baseframeView addSubview:_bx_centerLabel];
    
    [self.bx_baseframeView addSubview:self.bx_baseBackView];
    
    _bx_nameleftLabel = [[UILabel alloc] init];
    _bx_nameleftLabel.text = @"姓名";
    _bx_nameleftLabel.textColor = BXHexColor(0x666666);
    _bx_nameleftLabel.font = BXSystemFont(14);
    _bx_nameleftLabel.textAlignment = NSTextAlignmentRight;
    [self.bx_baseBackView addSubview:_bx_nameleftLabel];
    
    _bx_verifyleftLabel = [[UILabel alloc] init];
    _bx_verifyleftLabel.text = @"身份证号";
    _bx_verifyleftLabel.textColor = BXHexColor(0x666666);
    _bx_verifyleftLabel.font = BXSystemFont(14);
    _bx_verifyleftLabel.textAlignment = NSTextAlignmentRight;
    [self.bx_baseBackView addSubview:_bx_verifyleftLabel];
    
    _bx_phoneleftLabel = [[UILabel alloc] init];
    _bx_phoneleftLabel.text = @"手机号";
    _bx_phoneleftLabel.textColor = BXHexColor(0x666666);
    _bx_phoneleftLabel.font = BXSystemFont(14);
    _bx_phoneleftLabel.textAlignment = NSTextAlignmentRight;
    [self.bx_baseBackView addSubview:_bx_phoneleftLabel];
    
    _bx_nameRightLabel = [[UILabel alloc] init];
    _bx_nameRightLabel.text = [BXMobileManager shareManager].currentUser.realName;
    _bx_nameRightLabel.textColor = BXHexColor(0x333333);
    _bx_nameRightLabel.font = BXSystemFont(14);
    [self.bx_baseBackView addSubview:_bx_nameRightLabel];
    
    _bx_verifyRightLabel = [[UILabel alloc] init];
    _bx_verifyRightLabel.text = [BXMobileManager shareManager].currentUser.idcard;
    _bx_verifyRightLabel.textColor = BXHexColor(0x333333);
    _bx_verifyRightLabel.font = BXSystemFont(14);
    [self.bx_baseBackView addSubview:_bx_verifyRightLabel];
    
    _bx_phoneRightLabel = [[UILabel alloc] init];
    _bx_phoneRightLabel.text = [BXMobileManager shareManager].currentUser.phoneNumber;
    _bx_phoneRightLabel.textColor = BXHexColor(0x333333);
    _bx_phoneRightLabel.font = BXSystemFont(14);
    [self.bx_baseBackView addSubview:_bx_phoneRightLabel];
    
    [self.view updateConstraintsIfNeeded];
}

- (void)updateViewConstraints {
    if (!_bx_didSetupConstraints) {
        [self.bx_baseframeView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0];
        [self.bx_baseframeView autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:0];
        [self.bx_baseframeView autoSetDimensionsToSize:[self orientationStatus] ? CGSizeMake(ScreenHeight, ScreenHeight) : CGSizeMake(ScreenWidth, ScreenWidth)];
        
        [self.bx_baseHeaderView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0];
        [self.bx_baseHeaderView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:0];
        [self.bx_baseHeaderView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:0];
        [self.bx_baseHeaderView autoSetDimension:ALDimensionHeight toSize:40];
        
        [self.bx_centerImageView sizeToFit];
        [self.bx_centerImageView autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_baseHeaderView withOffset:20];
        [self.bx_centerImageView autoAlignAxis:ALAxisVertical toSameAxisOfView:self.bx_baseframeView withOffset:0];
        
        [self.bx_centerLabel sizeToFit];
        [self.bx_centerLabel autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_centerImageView withOffset:10];
        [self.bx_centerLabel autoAlignAxis:ALAxisVertical toSameAxisOfView:self.bx_baseframeView withOffset:0];
        
        [self.bx_baseBackView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:14];
        [self.bx_baseBackView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:14];
        [self.bx_baseBackView autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_centerLabel withOffset:14];
        [self.bx_baseBackView autoSetDimension:ALDimensionHeight toSize:120];
        
        [self.bx_nameleftLabel autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:0];
        [self.bx_nameleftLabel autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:10];
        [self.bx_nameleftLabel autoSetDimension:ALDimensionHeight toSize:40];
        [self.bx_nameleftLabel autoSetDimension:ALDimensionWidth toSize:60];
        
        [self.bx_nameRightLabel autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:0];
        [self.bx_nameRightLabel autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:10];
        [self.bx_nameRightLabel autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.bx_nameleftLabel withOffset:18];
        [self.bx_nameRightLabel autoSetDimension:ALDimensionHeight toSize:40];
        
        [self.bx_verifyleftLabel autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_nameleftLabel withOffset:0];
        [self.bx_verifyRightLabel autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_nameRightLabel withOffset:0];
        [self.bx_phoneleftLabel autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_verifyleftLabel withOffset:0];
        [self.bx_phoneRightLabel autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_verifyRightLabel withOffset:0];
        
        [@[self.bx_nameleftLabel,self.bx_verifyleftLabel] autoMatchViewsDimension:ALDimensionWidth];
        [@[self.bx_nameleftLabel,self.bx_phoneleftLabel] autoMatchViewsDimension:ALDimensionWidth];
        [@[self.bx_nameRightLabel,self.bx_verifyRightLabel] autoMatchViewsDimension:ALDimensionHeight];
        [@[self.bx_nameRightLabel,self.bx_phoneRightLabel] autoMatchViewsDimension:ALDimensionHeight];
        
        [self.bx_verifyleftLabel autoPinEdge:ALEdgeLeft toEdge:ALEdgeLeft ofView:self.bx_nameleftLabel];
        [self.bx_phoneleftLabel autoPinEdge:ALEdgeLeft toEdge:ALEdgeLeft ofView:self.bx_nameleftLabel];
        
        [self.bx_verifyRightLabel autoPinEdge:ALEdgeLeft toEdge:ALEdgeLeft ofView:self.bx_nameRightLabel];
        [self.bx_phoneRightLabel autoPinEdge:ALEdgeLeft toEdge:ALEdgeLeft ofView:self.bx_nameRightLabel];
        
        [self.bx_verifyRightLabel autoPinEdge:ALEdgeRight toEdge:ALEdgeRight ofView:self.bx_nameRightLabel];
        [self.bx_phoneRightLabel autoPinEdge:ALEdgeRight toEdge:ALEdgeRight ofView:self.bx_nameRightLabel];
        
        [self.bx_nameRightLabel autoAlignAxis:ALAxisHorizontal toSameAxisOfView:self.bx_nameleftLabel];
        [self.bx_verifyRightLabel autoAlignAxis:ALAxisHorizontal toSameAxisOfView:self.bx_verifyleftLabel];
        [self.bx_phoneRightLabel autoAlignAxis:ALAxisHorizontal toSameAxisOfView:self.bx_phoneleftLabel];
        
        NSMutableArray *lines = [NSMutableArray array];
        for (NSInteger index = 0; index < 2; index++) {
            UIView *bx_line = [[UIView alloc] init];
            [bx_line setBackgroundColor:BXHexColor(0xDEDEDE)];
            [self.bx_baseBackView addSubview:bx_line];
            [lines addObject:bx_line];
        }
        [lines.firstObject autoPinEdgeToSuperviewEdge:ALEdgeLeading];
        [lines.firstObject autoPinEdgeToSuperviewEdge:ALEdgeTrailing];
        
        [lines autoMatchViewsDimension:ALDimensionWidth];
        [lines autoDistributeViewsAlongAxis:ALAxisVertical alignedTo:ALAttributeVertical withFixedSize:0.5];
        
        self.bx_baseBackView.layer.masksToBounds = false;
        self.bx_baseBackView.layer.shadowColor = BXHexAColor(0x388EFF, 0.1).CGColor;
        self.bx_baseBackView.layer.shadowOffset = CGSizeMake(0, 0);
        self.bx_baseBackView.layer.shadowRadius = 8;
        self.bx_baseBackView.layer.shadowOpacity = 1;
        self.bx_baseBackView.layer.cornerRadius = 8;
        
        _bx_didSetupConstraints = YES;
    }
    [super updateViewConstraints];
}

-(void)backAction:(UIButton *)sender{
    [self bx_hideWithCompletion:^{
        
    }];
}

- (void)screenTap:(UITapGestureRecognizer *)gesture {
    CGPoint p = [gesture locationInView:self.view];
    if (!CGRectContainsPoint(self.bx_baseframeView.frame, p)) {
        [self dismissToRootViewController];
    }
}

-(void)dismissToRootViewController{
    UIViewController *vc = self;
    while (vc.presentingViewController) {
        vc = vc.presentingViewController;
    }
    [vc dismissViewControllerAnimated:YES completion:nil];
}

@end
