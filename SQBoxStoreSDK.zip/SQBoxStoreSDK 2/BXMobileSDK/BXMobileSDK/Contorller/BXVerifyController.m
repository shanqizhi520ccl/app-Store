//
//  BXVerifyController.m
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/8/27.
//  Copyright © 2021 Gavin. All rights reserved.
//

#import "BXVerifyController.h"
#import "BXMyH5Controller.h"
#import "BXPrivacyUtil.h"
#import "BXPhoneBindController.h"
#import "BXMobileManager.h"
#import "BXUser.h"
#import "BXMobileManager+Private.h"
#import "BXEvent.h"
#import "BXAddHeartbeatManager.h"

@interface BXVerifyController ()

@property(strong, nonatomic) UILabel *bx_centerLabel;

@property(strong, nonatomic) UILabel *bx_buttomLabel;

@property (nonatomic, strong) BXTextField *bx_nameTextField;

@property (nonatomic, strong) BXTextField *bx_icardTextField;

@property (nonatomic, strong) BXTextField *bx_phoneTextField;

@property (nonatomic, assign) BOOL bx_didSetupConstraints;
@end

@implementation BXVerifyController

- (void)dealloc
{
    BXLogInfo(@"%s",__func__);
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.preferredContentSize = [self orientationStatus] ? CGSizeMake(ScreenWidth, ScreenWidth) : CGSizeMake(ScreenWidth, ScreenHeight);
    }
    return self;
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [self notifitionSatatus];
}

-(void)notifitionSatatus{
    [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(statusBarOrientationChange:) name:UIApplicationDidChangeStatusBarOrientationNotification object:nil];
}
-(void)statusBarOrientationChange:(NSNotification*)notification{
    self.preferredContentSize = [self orientationStatus] ? CGSizeMake(ScreenWidth, ScreenWidth) : CGSizeMake(ScreenWidth, ScreenHeight);
    [self.bx_baseframeView autoSetDimensionsToSize:[self orientationStatus] ? CGSizeMake(ScreenWidth, ScreenWidth) : CGSizeMake(ScreenWidth, ScreenWidth)];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setupViews];
    
    self.view.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(screenTap:)];
    tap.cancelsTouchesInView = NO;
    [self.view addGestureRecognizer:tap];
}

- (void)setupViews {
    self.view.backgroundColor = UIColor.clearColor;
    
    [self.view addSubview:self.bx_baseframeView];
    
    [self.bx_baseframeView addSubview:self.bx_baseHeaderView];
    [self.bx_baseHeaderView bx_baseHeaderViewSetString:@"实名认证"];
    @weakify(self)
    self.bx_baseHeaderView.bx_leftCallback = ^{
        @strongify(self)
        [self backAction:nil];
    };
    
    _bx_centerLabel = [[UILabel alloc] init];
    _bx_centerLabel.text = @"根据相关法律，进行网络游戏、网络交易等行为时需要进行实名认证";
    _bx_centerLabel.numberOfLines = 0;
    _bx_centerLabel.textColor = BXHexColor(0x666666);
    _bx_centerLabel.font = BXSystemFont(12);
    [self.bx_baseframeView addSubview:_bx_centerLabel];
   
    [self.bx_baseframeView addSubview:self.bx_baseBackView];
    
    [self.bx_baseBackView addSubview:self.bx_nameTextField];
    [self.bx_baseBackView addSubview:self.bx_icardTextField];
    [self.bx_baseBackView addSubview:self.bx_phoneTextField];
    
    _bx_buttomLabel = [[UILabel alloc] init];
    _bx_buttomLabel.text = @"注意：\n1、姓名、身份证须同属一人\n2、实名认证通过之后，不可更改";
    _bx_buttomLabel.numberOfLines = 0;
    _bx_buttomLabel.textColor = BXHexColor(0x666666);
    _bx_buttomLabel.font = BXSystemFont(12);
    [self.bx_baseframeView addSubview:_bx_buttomLabel];
   
    [self.bx_baseNextBtn setTitle:@"确定" forState:UIControlStateNormal];
    [self.bx_baseNextBtn addTarget:self action:@selector(bx_baseNextBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.bx_baseframeView addSubview:self.bx_baseNextBtn];
    
    [self.view updateConstraintsIfNeeded];
}

- (BXTextField *)bx_nameTextField {
    if (!_bx_nameTextField) {
        _bx_nameTextField = [BXTextField textFieldWithTitle:nil placeHolder:@"请输入您的真实姓名"];
        _bx_nameTextField.backgroundColor = [UIColor whiteColor];
        _bx_nameTextField.borderStyle = UITextBorderStyleNone;
        _bx_nameTextField.font = BXSystemFont(14);
        _bx_nameTextField.textColor = BXHexColor(0x333333);
        _bx_nameTextField.keyboardType = UIKeyboardTypeDefault;
        _bx_nameTextField.rightViewMode = UITextFieldViewModeNever;
    }
    return _bx_nameTextField;
}

- (UITextField *)bx_icardTextField {
    if (!_bx_icardTextField) {
        _bx_icardTextField = [BXTextField textFieldWithTitle:nil placeHolder:@"请输入您的身份证号码"];
        _bx_icardTextField.backgroundColor = [UIColor whiteColor];
        _bx_icardTextField.borderStyle = UITextBorderStyleNone;
        _bx_icardTextField.font = BXSystemFont(14);
        _bx_icardTextField.textColor = BXHexColor(0x333333);
        _bx_icardTextField.keyboardType = UIKeyboardTypeASCIICapable;
        _bx_icardTextField.autocorrectionType = UITextAutocorrectionTypeNo;
        _bx_icardTextField.autocapitalizationType = UITextAutocapitalizationTypeNone;
        _bx_icardTextField.rightViewMode = UITextFieldViewModeAlways;
    }
    return _bx_icardTextField;
}

- (BXTextField *)bx_phoneTextField {
    if (!_bx_phoneTextField) {
        _bx_phoneTextField = [BXTextField textFieldWithTitle:nil placeHolder:@"请输入您的手机号码"];
        _bx_phoneTextField.backgroundColor = [UIColor whiteColor];
        _bx_phoneTextField.borderStyle = UITextBorderStyleNone;
        _bx_phoneTextField.font = BXSystemFont(14);
        _bx_phoneTextField.textColor = BXHexColor(0x333333);
        _bx_phoneTextField.keyboardType = UIKeyboardTypeNumberPad;
        _bx_phoneTextField.autocorrectionType = UITextAutocorrectionTypeNo;
        _bx_phoneTextField.autocapitalizationType = UITextAutocapitalizationTypeNone;
        _bx_phoneTextField.rightViewMode = UITextFieldViewModeAlways;
    }
    return _bx_phoneTextField;
}

- (void)updateViewConstraints {
    if (!_bx_didSetupConstraints) {
        [self.bx_baseframeView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0];
        [self.bx_baseframeView autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:0];
        [self.bx_baseframeView autoSetDimensionsToSize:[self orientationStatus] ? CGSizeMake(ScreenHeight, ScreenHeight) : CGSizeMake(ScreenWidth, ScreenWidth)];
        
        [self.bx_baseHeaderView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0];
        [self.bx_baseHeaderView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:0];
        [self.bx_baseHeaderView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:0];
        [self.bx_baseHeaderView autoSetDimension:ALDimensionHeight toSize:40];
        
        [self.bx_centerLabel sizeToFit];
        [self.bx_centerLabel autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_baseHeaderView withOffset:10];
        [self.bx_centerLabel autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:14];
        [self.bx_centerLabel autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:14];
        [self.bx_centerLabel autoAlignAxis:ALAxisVertical toSameAxisOfView:self.bx_baseframeView withOffset:0];
        
        [self.bx_baseBackView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:14];
        [self.bx_baseBackView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:14];
        [self.bx_baseBackView autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_centerLabel withOffset:18];
        [self.bx_baseBackView autoSetDimension:ALDimensionHeight toSize:120];
        
        NSArray *tfs = @[self.bx_nameTextField, self.bx_icardTextField,self.bx_phoneTextField];
        [tfs.firstObject autoPinEdgeToSuperviewEdge:ALEdgeLeading];
        [tfs.firstObject autoPinEdgeToSuperviewEdge:ALEdgeTrailing];
        [tfs autoMatchViewsDimension:ALDimensionWidth];
        [tfs autoDistributeViewsAlongAxis:ALAxisVertical alignedTo:ALAttributeVertical withFixedSpacing:0];
        
        NSMutableArray *lines = [NSMutableArray array];
        for (NSInteger index = 0; index < 2; index++) {
            UIView *bx_line = [[UIView alloc] init];
            [bx_line setBackgroundColor:BXHexColor(0xDEDEDE)];
            [self.bx_baseBackView addSubview:bx_line];
            [lines addObject:bx_line];
        }
        [lines.firstObject autoPinEdgeToSuperviewEdge:ALEdgeLeading];
        [lines.firstObject autoPinEdgeToSuperviewEdge:ALEdgeTrailing];
        
        [lines autoMatchViewsDimension:ALDimensionWidth];
        [lines autoDistributeViewsAlongAxis:ALAxisVertical alignedTo:ALAttributeVertical withFixedSize:0.5];
        
        [self.bx_buttomLabel autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_baseBackView withOffset:18];
        [self.bx_buttomLabel autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:14];
        [self.bx_buttomLabel autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:14];
        [self.bx_buttomLabel autoAlignAxis:ALAxisVertical toSameAxisOfView:self.bx_baseframeView withOffset:0];
        
        [self.bx_baseNextBtn autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:14];
        [self.bx_baseNextBtn autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:14];
        [self.bx_baseNextBtn autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_buttomLabel withOffset:14];
        [self.bx_baseNextBtn autoSetDimension:ALDimensionHeight toSize:40];
        
        _bx_didSetupConstraints = YES;
    }
    [super updateViewConstraints];
}

-(void)backAction:(UIButton *)sender{
    [self bx_hideWithCompletion:^{
        
    }];
}

-(void)bx_baseNextBtnAction:(UIButton *)sender{
#define NotNil(text) text ? text : @""
    NSString *realName = NotNil(self.bx_nameTextField.text);
    NSString *idcard = NotNil(self.bx_icardTextField.text);
    NSString *phone = NotNil(self.bx_phoneTextField.text);
    
    if (self.bx_nameTextField.text.length == 0) {
        [BXMBProgressHUD bx_showMessage:@"请输入您的姓名"];
        return;
    }
    
    if (self.bx_nameTextField.text.length < 2) {
        [BXMBProgressHUD bx_showMessage:@"请检查输入的姓名是否正确"];
        return;
    }
    
    if (self.bx_icardTextField.text.length == 0) {
        [BXMBProgressHUD bx_showMessage:@"请输入身份证号"];
        return;
    }
    
    if (![NSString bx_checkValidityForIDCard:self.bx_icardTextField.text]) {
        [BXMBProgressHUD bx_showMessage:@"身份证输入格式错误，请输入正确的身份证号码"];
        return;
    }
    
    if (self.bx_phoneTextField.text.length == 0) {
        [BXMBProgressHUD bx_showMessage:@"请输入手机号码"];
        return;
    }
    
    if (![NSString bx_checkValidityForPhoneNumber:self.bx_phoneTextField.text]) {
        [BXMBProgressHUD bx_showMessage:@"请输入正确的11位手机号码"];
        return;
    }
    
    [self.view endEditing:YES];
    
    @weakify(self)
    [BXEvent bx_doRealnameAuth:idcard realName:realName phone:phone complement:^(id obj, NSError *error) {
        @strongify(self)
        if (!error) {
            if (self.verifyCallback) {
                self.verifyCallback();
            }
            [BXMobileManager shareManager].currentUser.idcard = idcard;
            [BXMobileManager shareManager].currentUser.realName = realName;
            [[BXAddHeartbeatManager sharedInstance] bx_stopAntiAddictionTimer];
            [self bx_hideWithCompletion:nil];
        }else{
            [BXMBProgressHUD bx_showMessage:error.localizedDescription delay:YES];
        }
    }];
}

- (void)screenTap:(UITapGestureRecognizer *)gesture {
    if ([self.bx_nameTextField isFirstResponder] || [self.bx_icardTextField isFirstResponder] || [self.bx_phoneTextField isFirstResponder]) {
        [self.view endEditing:YES];
        return;
    }
    
    CGPoint p = [gesture locationInView:self.view];
    if (!CGRectContainsPoint(self.bx_baseframeView.frame, p)) {
        [self dismissToRootViewController];
    }
}

-(void)dismissToRootViewController{
    UIViewController *vc = self;
    while (vc.presentingViewController) {
        vc = vc.presentingViewController;
    }
    [vc dismissViewControllerAnimated:YES completion:nil];
}

@end
