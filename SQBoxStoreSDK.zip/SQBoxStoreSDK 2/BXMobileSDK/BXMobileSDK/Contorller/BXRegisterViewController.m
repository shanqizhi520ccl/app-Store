//
//  BXRegisterViewController.m
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/7/21.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXRegisterViewController.h"
#import "TPKeyboardAvoidingScrollView.h"
#import "BXCaptureRegisterResultViewController.h"
#import "BXBindMobileTipsViewController.h"
#import "BXSeviceAndPrivacyViewController.h"
#import "BXExecuteLoginViewController.h"
#import "BXConfig.h"
#import "BXEvent.h"
#import "UIImage+BXExtern.h"
#import "BXUser.h"

#import "BXThreeSelectionController.h"
#import "BXPrivacyUtil.h"

@interface BXRegisterViewController ()<UITextFieldDelegate>
@property (nonatomic, readwrite)BXRegisterType registerType;

@property (nonatomic, strong) UIView *bx_navgationBar;
@property (nonatomic, strong) UIImageView *bx_navgationBackgroundImgView;
@property (nonatomic, strong) UILabel *bx_titileLabel;
@property (nonatomic, strong) UIButton *bx_backButton;

@property (nonatomic, strong) TPKeyboardAvoidingScrollView *bx_scrollView;

@property (nonatomic, strong) UIView *bx_textFieldBackgroundView;
@property (nonatomic, strong) BXTextField *bx_accountTextField;
@property (nonatomic, strong) BXTextField *bx_smscodeTextField;
@property (nonatomic, strong) BXTextField *bx_passwordTextField;
@property (nonatomic, strong) UIButton *bx_smscodeButton;

@property (nonatomic, strong) UIButton *smscodeButton;

@property (nonatomic, strong) UIButton *bx_checkBoxButton;
@property (nonatomic, strong) UILabel *bx_serviceAndPrivacyHeadLabel;
@property (nonatomic, strong) UIButton *bx_serviceButton;
@property (nonatomic, strong) UILabel *bx_serviceAndPrivacyEndLabel;
@property (nonatomic, strong) UIButton *bx_privacyButton;

@property (nonatomic, strong) UIButton *bx_nextButton;

@property (nonatomic, strong) NSTimer * smscodeTimer;
@property (nonatomic, assign) NSInteger smsCodeCount;

@property (nonatomic, assign) BOOL bx_didSetupConstraints;
@end

@implementation BXRegisterViewController

- (instancetype)initWithRegisterType:(NSInteger)registerType {
    self = [super init];
    if (self) {
        self.registerType = registerType;
        
        if (registerType == BXRegisterTypeMobile) {
            if (!isSmallScreen) {
                self.preferredContentSize = CGSizeMake(338, 268);
            }else{
                self.preferredContentSize = CGSizeMake(280, 268);
            }
        }else{
            if (!isSmallScreen) {
                self.preferredContentSize = CGSizeMake(338, 185);
            }else{
                self.preferredContentSize = CGSizeMake(280, 185);
            }
        }
    }
    return self;
}

- (instancetype)init{
    NSException * exp = [NSException exceptionWithName:@"BXMobileSDK" reason:@"call -initWithRegisterType instead of -init" userInfo:nil];
    @throw exp;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    [self setupViews];
    
    if (self.registerType == BXRegisterTypeMobile) {
        self.bx_titileLabel.text = @"手机注册";
    }else{
        self.bx_titileLabel.text = @"一键注册";
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}

- (void)setupViews {
    [self.view addSubview:self.bx_navgationBar];
    [self.bx_navgationBar addSubview:self.bx_navgationBackgroundImgView];
    [self.bx_navgationBar addSubview:self.bx_titileLabel];
    [self.bx_navgationBar addSubview:self.bx_backButton];
    
    [self.view addSubview:self.bx_scrollView];
    [self.bx_scrollView addSubview:self.bx_textFieldBackgroundView];
    [self.bx_textFieldBackgroundView addSubview:self.bx_passwordTextField];

    [self.bx_scrollView addSubview:self.bx_nextButton];
    
    [self.bx_scrollView addSubview:self.bx_checkBoxButton];
    [self.bx_scrollView addSubview:self.bx_serviceAndPrivacyHeadLabel];
    [self.bx_scrollView addSubview:self.bx_serviceButton];
    [self.bx_scrollView addSubview:self.bx_serviceAndPrivacyEndLabel];
    [self.bx_scrollView addSubview:self.bx_privacyButton];
    
    if (self.registerType == BXRegisterTypeMobile) {
        [self.bx_textFieldBackgroundView addSubview:self.bx_accountTextField];
        [self.bx_textFieldBackgroundView addSubview:self.bx_smscodeTextField];
        
        NSMutableArray *lines = [NSMutableArray array];
        for (NSInteger index = 0; index < 2; index++) {
            UIView *line = [[UIView alloc] init];
            [line setBackgroundColor:BXHexColor(0xDEDEDE)];
            [self.bx_textFieldBackgroundView addSubview:line];
            [lines addObject:line];
        }
        [lines.firstObject autoPinEdgeToSuperviewEdge:ALEdgeLeading];
        [lines.firstObject autoPinEdgeToSuperviewEdge:ALEdgeTrailing];
        
        [lines autoMatchViewsDimension:ALDimensionWidth];
        [lines autoDistributeViewsAlongAxis:ALAxisVertical alignedTo:ALAttributeVertical withFixedSize:1];
    }

    [self.view updateConstraintsIfNeeded];
}

- (void)updateViewConstraints {
    if (!_bx_didSetupConstraints) {
        if (self.registerType == BXRegisterTypeMobile) {
            // 导航栏
            [self.bx_navgationBar autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero excludingEdge:ALEdgeBottom];
            [self.bx_navgationBar autoSetDimension:ALDimensionHeight toSize:40];
            
            [self.bx_navgationBackgroundImgView autoPinEdgesToSuperviewEdges];
            
            [self.bx_backButton autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:6];
            [self.bx_backButton autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
            [self.bx_backButton  autoSetDimensionsToSize:CGSizeMake(36, 36)];
            
            [self.bx_titileLabel autoPinEdge:ALEdgeLeading toEdge:ALEdgeTrailing ofView:self.bx_backButton withOffset:0];
            [self.bx_titileLabel autoPinEdgeToSuperviewEdge:(ALEdgeTop) withInset:14];
            [self.bx_titileLabel autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
            
            // background scrollView
            [self.bx_scrollView autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero excludingEdge:ALEdgeTop];
            [self.bx_scrollView autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_navgationBar];
            [self.bx_textFieldBackgroundView autoPinEdge:ALEdgeLeading toEdge:ALEdgeLeading ofView:self.view withOffset:20];
            [self.bx_textFieldBackgroundView autoPinEdge:ALEdgeTrailing toEdge:ALEdgeTrailing ofView:self.view withOffset:-20];
            
            [self.bx_textFieldBackgroundView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:10];
            [self.bx_textFieldBackgroundView autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:20];
            [self.bx_textFieldBackgroundView autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:20];
            [self.bx_textFieldBackgroundView autoSetDimension:ALDimensionHeight toSize:40*3];
        
            NSArray *tfs = @[self.bx_accountTextField, self.bx_smscodeTextField, self.bx_passwordTextField];
            [tfs.firstObject autoPinEdgeToSuperviewEdge:ALEdgeLeading];
            [tfs.firstObject autoPinEdgeToSuperviewEdge:ALEdgeTrailing];
            [tfs autoMatchViewsDimension:ALDimensionWidth];
            [tfs autoDistributeViewsAlongAxis:ALAxisVertical alignedTo:ALAttributeVertical withFixedSpacing:0];
            
            // 服务与协议
            [self.bx_checkBoxButton autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_textFieldBackgroundView withOffset:10];
            [self.bx_checkBoxButton autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:20];
            [self.bx_checkBoxButton autoPinEdgeToSuperviewEdge:ALEdgeBottom];
            [self.bx_checkBoxButton autoSetDimensionsToSize:CGSizeMake(14, 14)];
            
            [@[self.bx_checkBoxButton, self.bx_serviceAndPrivacyHeadLabel, self.bx_serviceButton, self.bx_serviceAndPrivacyEndLabel, self.bx_privacyButton] autoAlignViewsToAxis:ALAxisHorizontal];
            [self.bx_serviceAndPrivacyHeadLabel autoPinEdge:ALEdgeLeading toEdge:ALEdgeTrailing ofView:self.bx_checkBoxButton withOffset:5];
            [self.bx_serviceButton autoPinEdge:ALEdgeLeading toEdge:ALEdgeTrailing ofView:self.bx_serviceAndPrivacyHeadLabel withOffset:1];
            [self.bx_serviceAndPrivacyEndLabel autoPinEdge:ALEdgeLeading toEdge:ALEdgeTrailing ofView:self.bx_serviceButton withOffset:1];
            [self.bx_privacyButton autoPinEdge:ALEdgeLeading toEdge:ALEdgeTrailing ofView:self.bx_serviceAndPrivacyEndLabel withOffset:1];
            
            
            [self.bx_nextButton autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_checkBoxButton withOffset:10];
            [self.bx_nextButton autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:20];
            [self.bx_nextButton autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:20];
            [self.bx_nextButton autoSetDimension:ALDimensionHeight toSize:40];
        }else{
            // 导航栏
            [self.bx_navgationBar autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero excludingEdge:ALEdgeBottom];
            [self.bx_navgationBar autoSetDimension:ALDimensionHeight toSize:40];
            
            [self.bx_navgationBackgroundImgView autoPinEdgesToSuperviewEdges];
            
            [self.bx_backButton autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:6];
            [self.bx_backButton autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
            [self.bx_backButton  autoSetDimensionsToSize:CGSizeMake(36, 36)];
            
            [self.bx_titileLabel autoPinEdge:ALEdgeLeading toEdge:ALEdgeTrailing ofView:self.bx_backButton withOffset:0];
            [self.bx_titileLabel autoPinEdgeToSuperviewEdge:(ALEdgeTop) withInset:14];
            [self.bx_titileLabel autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
            
            // background scrollView
            [self.bx_scrollView autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero excludingEdge:ALEdgeTop];
            [self.bx_scrollView autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_navgationBar];
            [self.bx_textFieldBackgroundView autoPinEdge:ALEdgeLeading toEdge:ALEdgeLeading ofView:self.view withOffset:20];
            [self.bx_textFieldBackgroundView autoPinEdge:ALEdgeTrailing toEdge:ALEdgeTrailing ofView:self.view withOffset:-20];
            
            // 输入框
            [self.bx_textFieldBackgroundView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:10];
            [self.bx_textFieldBackgroundView autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:20];
            [self.bx_textFieldBackgroundView autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:20];
            [self.bx_textFieldBackgroundView autoSetDimension:ALDimensionHeight toSize:40];
        
            [self.bx_passwordTextField autoPinEdgesToSuperviewEdges];
            
            // 服务与协议
            [self.bx_checkBoxButton autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_textFieldBackgroundView withOffset:10];
            [self.bx_checkBoxButton autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:20];
            [self.bx_checkBoxButton autoPinEdgeToSuperviewEdge:ALEdgeBottom];
            [self.bx_checkBoxButton autoSetDimensionsToSize:CGSizeMake(14, 14)];
            
            [@[self.bx_checkBoxButton, self.bx_serviceAndPrivacyHeadLabel, self.bx_serviceButton, self.bx_serviceAndPrivacyEndLabel, self.bx_privacyButton] autoAlignViewsToAxis:ALAxisHorizontal];
            [self.bx_serviceAndPrivacyHeadLabel autoPinEdge:ALEdgeLeading toEdge:ALEdgeTrailing ofView:self.bx_checkBoxButton withOffset:5];
            [self.bx_serviceButton autoPinEdge:ALEdgeLeading toEdge:ALEdgeTrailing ofView:self.bx_serviceAndPrivacyHeadLabel withOffset:1];
            [self.bx_serviceAndPrivacyEndLabel autoPinEdge:ALEdgeLeading toEdge:ALEdgeTrailing ofView:self.bx_serviceButton withOffset:1];
            [self.bx_privacyButton autoPinEdge:ALEdgeLeading toEdge:ALEdgeTrailing ofView:self.bx_serviceAndPrivacyEndLabel withOffset:1];
            
            [self.bx_nextButton autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_checkBoxButton withOffset:10];
            [self.bx_nextButton autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:20];
            [self.bx_nextButton autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:20];
            [self.bx_nextButton autoSetDimension:ALDimensionHeight toSize:40];
        }
        
        _bx_didSetupConstraints = YES;
    }
    [super updateViewConstraints];
}

#pragma mark - Actions

- (void)backEvent:(id)sender {
    [self bx_hideWithCompletion:^{
    }];
}

- (void)registerEvent:(id)sender {
    switch (self.registerType) {
        case BXRegisterTypeMobile:
            [self registerByMobileAction];
            break;
        case BXRegisterTypeFast:
            [self fastRegisterAction];
            break;
    }
}

- (void)fastRegisterAction {
    if (self.bx_passwordTextField.text.length == 0) {
        [BXMBProgressHUD bx_showMessage:@"请输入密码，密码为6-20位字符"];
        return;
    }
    
    if (![NSString bx_checkValidityForPassword:self.bx_passwordTextField.text]) {
        [BXMBProgressHUD bx_showMessage:@"密码输入不正确，请输入6-20位"];
        return;
    }
    
    if (!self.bx_checkBoxButton.selected) {
        [BXMBProgressHUD bx_showMessage:@"请先仔细阅读并同意《用户注册服务协议》与《隐私政策》"];
        return;
    }

    [self.view endEditing:YES];
    
    [BXEvent bx_doFastRegister:self.bx_passwordTextField.text complement:^(BXUser *user, NSError *error) {
        if (!error) {
            UIViewController *preController = self.presentingViewController;
            [self bx_hideWithCompletion:^{
                BXCaptureRegisterResultViewController *bx_resultController = [[BXCaptureRegisterResultViewController alloc] initWithAccount:user.userId password:self.bx_passwordTextField.text];
                [preController presentViewController:bx_resultController animated:YES completion:^{
                }];
            }];
        }else{
            [BXMBProgressHUD bx_showMessage:error.localizedDescription delay:YES];
        }
    }];
}

- (void)registerByMobileAction  {
    if (self.bx_accountTextField.text.length == 0) {
        [BXMBProgressHUD bx_showMessage:@"请输入手机号码"];
        return;
    }
    
    if (![NSString bx_checkValidityForPhoneNumber:self.bx_accountTextField.text]) {
        [BXMBProgressHUD bx_showMessage:@"请输入正确的11位手机号码"];
        return;
    }
    
    if (self.bx_smscodeTextField.text.length == 0) {
        [BXMBProgressHUD bx_showMessage:@"请输入验证码"];
        return;
    }
    
    if (self.bx_smscodeTextField.text.length <= 3) {
        [BXMBProgressHUD bx_showMessage:@"验证码输入不正确"];
        return;
    }
    
    if (self.bx_passwordTextField.text.length == 0) {
        [BXMBProgressHUD bx_showMessage:@"请输入密码，密码为6-20位字符"];
        return;
    }
    
    if (![NSString bx_checkValidityForPassword:self.bx_passwordTextField.text]) {
        [BXMBProgressHUD bx_showMessage:@"密码输入不正确，请输入6-20位"];
        return;
    }
    
    if (!self.bx_checkBoxButton.selected) {
        [BXMBProgressHUD bx_showMessage:@"请先仔细阅读并同意《用户注册服务协议》与《隐私政策》"];
        return;
    }
    
    [self.view endEditing:YES];
    
    @weakify(self)
    [BXEvent bx_doRegisterByMobile:self.bx_accountTextField.text smsCode:self.bx_smscodeTextField.text password:self.bx_passwordTextField.text complement:^(id obj, NSError *error) {
        @strongify(self)
        if (!error) {
            UIViewController *preController = self.presentingViewController;
            [self bx_hideWithCompletion:^{
                BXExecuteLoginViewController *bx_loginController = [[BXExecuteLoginViewController alloc] initWithAccount:self.bx_accountTextField.text password:self.bx_passwordTextField.text fromRegister:YES];
                [preController presentViewController:bx_loginController animated:YES completion:^{
                }];
            }];
        }else{
            [BXMBProgressHUD bx_showMessage:error.localizedDescription delay:YES];
        }
    }];
}

- (void)agreementEvent:(id)sender {
    UIButton *button = (UIButton *)sender;
    button.selected = !button.selected;
}

- (void)showServiceAgreementEvent:(id)sender {
    [BXEvent bx_proxyServiceAgreementAddress:^(NSString *url, NSError *error) {
        if (!error) {
            BXSeviceAndPrivacyViewController *bx_controller = [[BXSeviceAndPrivacyViewController alloc] initWithUrl:[NSURL URLWithString:url] pageType:BXPageType_UserPrivate];
            [self presentViewController:bx_controller animated:YES completion:^{
            }];
        }else{
            [BXMBProgressHUD bx_showMessage:error.localizedDescription];
        }
    }];
}

- (void)showPrivacyPolicyEvent:(id)sender {
    [BXEvent bx_proxyPrivacyPolicyAddress:^(NSString *url, NSError *error) {
        if (!error) {
            BXSeviceAndPrivacyViewController *bx_controller = [[BXSeviceAndPrivacyViewController alloc] initWithUrl:[NSURL URLWithString:url] pageType:BXPageType_UserPrivate];
            [self presentViewController:bx_controller animated:YES completion:^{
            }];
        }else{
            [BXMBProgressHUD bx_showMessage:error.localizedDescription];
        }
    }];
}

- (void)sendSmsCodeEvent:(id)sender {
    [self.bx_smscodeTextField becomeFirstResponder];
    
    [self clearTimer:sender];
    [self onStartTimer:sender];
    
    [BXEvent bx_doGetSmsCode:self.bx_accountTextField.text smsType:1 complement:^(id obj, NSError *error) {
        if (!error) {
            [BXMBProgressHUD bx_showMessage:@"验证码发送成功,请注意查收短信!"];
        }else{
            [BXMBProgressHUD bx_showMessage:error.localizedDescription];
            [self clearTimer:sender];
        }
    }];
}

- (void)accountTextFieldValueChange:(UITextField *)tf {
    BOOL result = [NSString bx_checkValidityForPhoneNumber:tf.text];
    [[[self.bx_smscodeTextField trillingActions] firstObject] setEnabled:result];
}

#pragma mark - Smscode Timer

- (void)clearTimer:(BXTextFieldAction *)action {
    dispatch_async(dispatch_get_main_queue(), ^{
        [action setEnabled:YES];
        [action setActionTitle:@"发送验证码" forState:UIControlStateDisabled];
        if (nil != self.smscodeTimer) {
            [self.smscodeTimer invalidate];
            self.smscodeTimer = nil;
        }
    });
}

- (void)onStartTimer:(BXTextFieldAction *)action {
    dispatch_async(dispatch_get_main_queue(), ^{
        self.smsCodeCount = 60;
        [action setEnabled:NO];
        self.smscodeTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(onTimer:) userInfo:@{@"sender":action} repeats:YES];
        [self.smscodeTimer fire];
    });
}

- (void)onTimer:(NSTimer *)timer {
    self.smsCodeCount--;
    id action = timer.userInfo[@"sender"];
    if (self.smsCodeCount <= 0) {
        [self clearTimer:action];
    } else {
        NSString *message = [NSString stringWithFormat:@"%ld秒后重发", (long)self.smsCodeCount];
        [action setActionTitle:message forState:UIControlStateDisabled];
    }
}

#pragma mark - Property

//nav
- (UIView *)bx_navgationBar {
    if (!_bx_navgationBar) {
        _bx_navgationBar = [[UIView alloc] init];
    }
    return _bx_navgationBar;
}

- (UIButton *)bx_backButton {
    if (!_bx_backButton) {
        _bx_backButton = [UIButton buttonWithType:UIButtonTypeCustom];
        UIImage *aImage = [UIImage imageNamed:@"bxm_back" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
        [_bx_backButton setImage:aImage forState:UIControlStateNormal];
        [_bx_backButton addTarget:self action:@selector(backEvent:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _bx_backButton;
}

- (UILabel *)bx_titileLabel {
    if (!_bx_titileLabel) {
        _bx_titileLabel = [[UILabel alloc] init];
        [_bx_titileLabel setTextColor:BXHexColor(0x333333)];
        [_bx_titileLabel setFont:BXBoldSystemFont(14)];
    }
    return _bx_titileLabel;
}

- (UIImageView *)bx_navgationBackgroundImgView {
    if (!_bx_navgationBackgroundImgView) {
 
        _bx_navgationBackgroundImgView = [[UIImageView alloc] init];
        _bx_navgationBackgroundImgView.backgroundColor = [UIColor whiteColor];
    }
    return _bx_navgationBackgroundImgView;
}

- (TPKeyboardAvoidingScrollView *)bx_scrollView {
    if (!_bx_scrollView) {
        _bx_scrollView = [[TPKeyboardAvoidingScrollView alloc] init];
        _bx_scrollView.delaysContentTouches = NO;
        _bx_scrollView.backgroundColor  = [UIColor clearColor];
    }
    return _bx_scrollView;
}

- (UIView *)bx_textFieldBackgroundView {
    if (!_bx_textFieldBackgroundView) {
        _bx_textFieldBackgroundView = [[UIView alloc] init];
        _bx_textFieldBackgroundView.backgroundColor  = BXTextFieldBackgroundColor;
        _bx_textFieldBackgroundView.layer.cornerRadius = 4;
        _bx_textFieldBackgroundView.clipsToBounds = YES;
    }
    return _bx_textFieldBackgroundView;
}

- (BXTextField *)bx_accountTextField {
    if (!_bx_accountTextField) {
        _bx_accountTextField = [BXTextField textFieldWithTitle:nil placeHolder:@"手机号"];
        _bx_accountTextField.backgroundColor = [UIColor clearColor];
        _bx_accountTextField.borderStyle = UITextBorderStyleNone;
        _bx_accountTextField.font = BXSystemFont(14);
        _bx_accountTextField.textColor = BXTextFieldTextColor;
        _bx_accountTextField.autocorrectionType = UITextAutocorrectionTypeNo;
        _bx_accountTextField.autocapitalizationType = UITextAutocapitalizationTypeNone;
        
        _bx_accountTextField.keyboardType = UIKeyboardTypeNumberPad;
        [_bx_accountTextField addTarget:self action:@selector(accountTextFieldValueChange:) forControlEvents:UIControlEventEditingChanged];;
    }
    return _bx_accountTextField;
}

- (UITextField *)bx_smscodeTextField {
    if (!_bx_smscodeTextField) {
        _bx_smscodeTextField = [BXTextField textFieldWithTitle:nil placeHolder:@"验证码"];
        _bx_smscodeTextField.backgroundColor = [UIColor clearColor];
        _bx_smscodeTextField.borderStyle = UITextBorderStyleNone;
        _bx_smscodeTextField.font = BXSystemFont(14);
        _bx_smscodeTextField.textColor = BXTextFieldTextColor;
        _bx_smscodeTextField.keyboardType = UIKeyboardTypeASCIICapable;
        _bx_smscodeTextField.autocorrectionType = UITextAutocorrectionTypeNo;
        _bx_smscodeTextField.autocapitalizationType = UITextAutocapitalizationTypeNone;
            
        _bx_smscodeTextField.keyboardType = UIKeyboardTypeASCIICapable;
        
        @weakify(self)
        BXTextFieldAction *rightAction = [BXTextFieldAction actionWithTitle:@"发送验证码" handler:^(BXTextFieldAction *action) {
            @strongify(self)
            if ([BXPrivacyUtil bx_isNeedShowSendMsgCodePrivacy] == YES && [BXConfig config].grcAuthorityDerail == 1){
                BXThreeSelectionController *selectionVC = [[BXThreeSelectionController alloc] init];
                selectionVC.bx_Status = 1;
                selectionVC.bx_MsgCallback = ^(BOOL flag) {
                    [self sendSmsCodeEvent:action];
                };
                [self presentViewController:selectionVC animated:YES completion:nil];
            }else{
                [self sendSmsCodeEvent:action];
            }
        }];
        
        UIImage *image = [UIImage bx_imageWithColor:BXHexColor(0x388EFF) frame:CGRectMake(0, 0, 72, 24)];
        UIEdgeInsets edgeInsets = UIEdgeInsetsMake(image.size.height * 0.5, image.size.width * 0.5, image.size.height * 0.5, image.size.width * 0.5);
        UIImageResizingMode mode = UIImageResizingModeStretch;
        UIImage *newImage = [image resizableImageWithCapInsets:edgeInsets resizingMode:mode];
        [rightAction.actionButton setBackgroundImage:newImage forState:UIControlStateNormal];
        
        UIImage *disableImage = [UIImage bx_imageWithColor:BXHexColor( 0xDDDDDD) frame:CGRectMake(0, 0, 72, 24)];
        [rightAction.actionButton setBackgroundImage:disableImage forState:UIControlStateDisabled];
         
        [rightAction setEnabled:NO];
        [_bx_smscodeTextField setTrillingActions:@[rightAction]];
        _bx_smscodeTextField.rightViewMode = UITextFieldViewModeAlways;
        
    }
    return _bx_smscodeTextField;
}

- (UITextField *)bx_passwordTextField {
    if (!_bx_passwordTextField) {
        _bx_passwordTextField = [BXTextField textFieldWithTitle:nil placeHolder:@"密码"];
        _bx_passwordTextField.backgroundColor = [UIColor clearColor];
        _bx_passwordTextField.borderStyle = UITextBorderStyleNone;
        _bx_passwordTextField.font = BXSystemFont(14);
        _bx_passwordTextField.textColor = BXTextFieldTextColor;
        _bx_passwordTextField.keyboardType = UIKeyboardTypeASCIICapable;
        _bx_passwordTextField.autocorrectionType = UITextAutocorrectionTypeNo;
        _bx_passwordTextField.autocapitalizationType = UITextAutocapitalizationTypeNone;
        _bx_passwordTextField.clearsOnBeginEditing = YES;
        _bx_passwordTextField.rightViewMode = UITextFieldViewModeAlways;
        
//        BXTextFieldAction *leftAction = [BXTextFieldAction actionWithImage:@"tf_password" handler:NULL];
//        [_bx_passwordTextField setLeddingActions:@[leftAction]];
                
        @weakify(self)
        BXTextFieldAction *rightAction = [BXTextFieldAction actionWithImage:@"tf_unsecrity" selectedImage:@"tf_secrity" handler:^(BXTextFieldAction * _Nonnull action) {
            @strongify(self)
            self.bx_passwordTextField.secureTextEntry = !self.bx_passwordTextField.secureTextEntry;
            action.actionButton.selected = !action.actionButton.selected;
        }];
        [_bx_passwordTextField setTrillingActions:@[rightAction]];
        [rightAction.actionButton sendActionsForControlEvents:UIControlEventTouchUpInside];
    }
    return _bx_passwordTextField;
}

- (UIButton  *)bx_checkBoxButton {
    if (!_bx_checkBoxButton) {
        UIButton *bx_button = [UIButton buttonWithType:UIButtonTypeCustom];
        UIImage *slectedImage = [UIImage imageNamed:@"btn_check_box_selected" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
        UIImage *normalImage = [UIImage imageNamed:@"btn_check_box_unselected" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
        [bx_button setImage:normalImage forState:UIControlStateNormal];
        [bx_button setImage:slectedImage forState:UIControlStateSelected];
        [bx_button addTarget:self action:@selector(agreementEvent:) forControlEvents:UIControlEventTouchUpInside];
        bx_button.selected = YES;
        _bx_checkBoxButton = bx_button;
    }
    return _bx_checkBoxButton;
}

- (UILabel *)bx_serviceAndPrivacyHeadLabel {
    if (!_bx_serviceAndPrivacyHeadLabel) {
        _bx_serviceAndPrivacyHeadLabel = [[UILabel alloc] init];
        [_bx_serviceAndPrivacyHeadLabel setText:isSmallScreen ? @"阅读并同意" : @"您已阅读并同意"];
        [_bx_serviceAndPrivacyHeadLabel setTextColor:BXHexColor(0x333333)];
        [_bx_serviceAndPrivacyHeadLabel setFont:BXSystemFont(12)];
    }
    return _bx_serviceAndPrivacyHeadLabel;
}

- (UIButton *)bx_serviceButton {
    if (!_bx_serviceButton) {
        _bx_serviceButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_bx_serviceButton setTitle:@"用户注册服务协议" forState:UIControlStateNormal];
        [_bx_serviceButton setTitleColor:BXHexColor(0x388EFF) forState:UIControlStateNormal];
        _bx_serviceButton.titleLabel.font = BXSystemFont(12);
        [_bx_serviceButton addTarget:self action:@selector(showServiceAgreementEvent:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _bx_serviceButton;
}

- (UILabel *)bx_serviceAndPrivacyEndLabel {
    if (!_bx_serviceAndPrivacyEndLabel) {
        _bx_serviceAndPrivacyEndLabel = [[UILabel alloc] init];
        [_bx_serviceAndPrivacyEndLabel setText:@"和"];
        [_bx_serviceAndPrivacyEndLabel setTextColor:BXHexColor(0x333333)];
        [_bx_serviceAndPrivacyEndLabel setFont:BXSystemFont(12)];
    }
    return _bx_serviceAndPrivacyEndLabel;
}

- (UIButton *)bx_privacyButton {
    if (!_bx_privacyButton) {
        _bx_privacyButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_bx_privacyButton setTitle:@"隐私政策" forState:UIControlStateNormal];
        [_bx_privacyButton setTitleColor:BXHexColor(0x388EFF) forState:UIControlStateNormal];
        _bx_privacyButton.titleLabel.font = BXSystemFont(12);
        [_bx_privacyButton addTarget:self action:@selector(showPrivacyPolicyEvent:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _bx_privacyButton;
}

- (UIButton *)bx_nextButton {
    if (!_bx_nextButton) {
        UIButton *bx_button = [UIButton buttonWithType:UIButtonTypeCustom];
        [bx_button setTitle:@"立即注册" forState:UIControlStateNormal];
        [bx_button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        UIImage *aImage = [UIImage imageNamed:@"bxm_Anniu" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
        [bx_button setBackgroundImage:aImage forState:UIControlStateNormal];
        [bx_button addTarget:self action:@selector(registerEvent:) forControlEvents:UIControlEventTouchUpInside];

        
        _bx_nextButton = bx_button;
    }
    return _bx_nextButton;
}

@end
