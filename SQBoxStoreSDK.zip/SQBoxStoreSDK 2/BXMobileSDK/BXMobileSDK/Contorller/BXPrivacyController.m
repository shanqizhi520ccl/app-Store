//
//  BXPrivacyController.m
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/8/27.
//  Copyright © 2021 Gavin. All rights reserved.
//

#import "BXPrivacyController.h"
#import "BXPrivacyUtil.h"

@interface BXPrivacyController ()

@property(strong, nonatomic) UILabel *bx_deviceLabel;

@property(strong, nonatomic) UILabel *bx_deviceStatusLabel;

@property(strong, nonatomic) UILabel *bx_msgLabel;

@property(strong, nonatomic) UILabel *bx_msgStatusLabel;

@property (nonatomic, assign) BOOL bx_didSetupConstraints;
@end

@implementation BXPrivacyController

- (void)dealloc
{
    BXLogInfo(@"%s",__func__);
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.preferredContentSize = [self orientationStatus] ? CGSizeMake(ScreenWidth, ScreenWidth) : CGSizeMake(ScreenWidth, ScreenHeight);
    }
    return self;
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [self notifitionSatatus];
}

-(void)notifitionSatatus{
    [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(statusBarOrientationChange:) name:UIApplicationDidChangeStatusBarOrientationNotification object:nil];
}
-(void)statusBarOrientationChange:(NSNotification*)notification{
    self.preferredContentSize = [self orientationStatus] ? CGSizeMake(ScreenWidth, ScreenWidth) : CGSizeMake(ScreenWidth, ScreenHeight);
    [self.bx_baseframeView autoSetDimensionsToSize:[self orientationStatus] ? CGSizeMake(ScreenWidth, ScreenWidth) : CGSizeMake(ScreenWidth, ScreenWidth)];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setupViews];
    
    self.view.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(screenTap:)];
    tap.cancelsTouchesInView = NO;
    [self.view addGestureRecognizer:tap];
}

- (void)setupViews {
    self.view.backgroundColor = UIColor.clearColor;
    
    [self.view addSubview:self.bx_baseframeView];
    
    [self.bx_baseframeView addSubview:self.bx_baseHeaderView];
    [self.bx_baseHeaderView bx_baseHeaderViewSetString:@"隐私权限管理"];
    @weakify(self)
    self.bx_baseHeaderView.bx_leftCallback = ^{
        @strongify(self)
        [self backAction:nil];
    };
    
    [self.bx_baseframeView addSubview:self.bx_baseBackView];
    
    _bx_deviceLabel = [[UILabel alloc]init];
    _bx_deviceLabel.textColor = BXHexColor(0x333333);
    _bx_deviceLabel.font = BXSystemFont(14);
    _bx_deviceLabel.text = @"设备权限信息";
    _bx_deviceLabel.textAlignment = NSTextAlignmentLeft;
    [self.bx_baseBackView addSubview:_bx_deviceLabel];
    
    _bx_deviceStatusLabel = [[UILabel alloc]init];
    _bx_deviceStatusLabel.textColor = BXHexColor(0x666666);
    _bx_deviceStatusLabel.font = BXSystemFont(14);
    if (![BXPrivacyUtil bx_isNeedShowbx_devicePrivacy]){
        _bx_deviceStatusLabel.text = @"已允许";
    }else{
        _bx_deviceStatusLabel.text = @"未允许";
    }
    _bx_deviceStatusLabel.textAlignment = NSTextAlignmentRight;
    [self.bx_baseBackView addSubview:_bx_deviceStatusLabel];
    
    _bx_msgLabel = [[UILabel alloc]init];
    _bx_msgLabel.textColor = BXHexColor(0x333333);
    _bx_msgLabel.font = BXSystemFont(14);
    _bx_msgLabel.text = @"短信权限";
    _bx_msgLabel.textAlignment = NSTextAlignmentLeft;
    [self.bx_baseBackView addSubview:_bx_msgLabel];
    
    _bx_msgStatusLabel = [[UILabel alloc]init];
    _bx_msgStatusLabel.textColor = BXHexColor(0x666666);
    _bx_msgStatusLabel.font = BXSystemFont(14);
    
    if (![BXPrivacyUtil bx_isNeedShowSendMsgCodePrivacy]){
        _bx_msgStatusLabel.text = @"已允许";
    }else{
        _bx_msgStatusLabel.text = @"未允许";
    }
    
    _bx_msgStatusLabel.textAlignment = NSTextAlignmentRight;
    [self.bx_baseBackView addSubview:_bx_msgStatusLabel];
    
    [self.view updateConstraintsIfNeeded];
}

- (void)updateViewConstraints {
    if (!_bx_didSetupConstraints) {
        [self.bx_baseframeView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0];
        [self.bx_baseframeView autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:0];
        [self.bx_baseframeView autoSetDimensionsToSize:[self orientationStatus] ? CGSizeMake(ScreenHeight, ScreenHeight) : CGSizeMake(ScreenWidth, ScreenWidth)];
        
        [self.bx_baseHeaderView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0];
        [self.bx_baseHeaderView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:0];
        [self.bx_baseHeaderView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:0];
        [self.bx_baseHeaderView autoSetDimension:ALDimensionHeight toSize:40];
        
        [self.bx_baseBackView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:14];
        [self.bx_baseBackView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:14];
        [self.bx_baseBackView autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_baseHeaderView withOffset:14];
        [self.bx_baseBackView autoSetDimension:ALDimensionHeight toSize:80];
        
        [self.bx_deviceLabel autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:0];
        [self.bx_deviceLabel autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:10];
        [self.bx_deviceLabel autoSetDimension:ALDimensionHeight toSize:40];
        
        [self.bx_deviceStatusLabel autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:10];
        [self.bx_deviceStatusLabel autoPinEdge:ALEdgeTop toEdge:ALEdgeTop ofView:self.bx_deviceLabel withOffset:0];
        [self.bx_deviceStatusLabel autoMatchDimension:ALDimensionHeight toDimension:ALDimensionHeight ofView:self.bx_deviceLabel];
        
        UIView *bx_line = [[UIView alloc]init];
        bx_line.backgroundColor = BXHexColor(0xDEDEDE);
        [self.bx_baseBackView addSubview:bx_line];
        [bx_line autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0];
        [bx_line autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:0];
        [bx_line autoPinEdge:ALEdgeBottom toEdge:ALEdgeBottom ofView:self.bx_deviceLabel withOffset:0];
        [bx_line autoSetDimension:ALDimensionHeight toSize:0.5];
        
        [self.bx_msgLabel autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_deviceLabel withOffset:0];
        [self.bx_msgLabel autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:10];
        [self.bx_msgLabel autoSetDimension:ALDimensionHeight toSize:40];
        
        [self.bx_msgStatusLabel autoPinEdge:ALEdgeTop toEdge:ALEdgeTop ofView:self.bx_msgLabel withOffset:0];
        [self.bx_msgStatusLabel autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:10];
        [self.bx_msgStatusLabel autoMatchDimension:ALDimensionHeight toDimension:ALDimensionHeight ofView:self.bx_msgLabel];
        
        _bx_didSetupConstraints = YES;
    }
    [super updateViewConstraints];
}

-(void)backAction:(UIButton *)sender{
    
    [self bx_hideWithCompletion:^{
        
    }];
}

- (void)screenTap:(UITapGestureRecognizer *)gesture {
    CGPoint p = [gesture locationInView:self.view];
    if (!CGRectContainsPoint(self.bx_baseframeView.frame, p)) {
        [self dismissToRootViewController];
    }
}
-(void)dismissToRootViewController{
    UIViewController *vc = self;
    while (vc.presentingViewController) {
        vc = vc.presentingViewController;
    }
    [vc dismissViewControllerAnimated:YES completion:nil];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
