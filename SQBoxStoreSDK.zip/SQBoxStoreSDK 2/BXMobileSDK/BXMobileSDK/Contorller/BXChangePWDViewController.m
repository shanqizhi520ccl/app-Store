//
//  BXChangePWDViewController.m
//  BXMobileSDK
//
//  Created by shanqizhi on 2021/9/7.
//  Copyright © 2021 Gavin. All rights reserved.
//

#import "BXChangePWDViewController.h"
#import "BXMyH5Controller.h"
#import "BXPrivacyUtil.h"
#import "BXMobileManager.h"
#import "BXUser.h"
#import "BXMobileManager+Private.h"
#import "BXEvent.h"
#import "BXAddHeartbeatManager.h"

@interface BXChangePWDViewController ()

@property (nonatomic, strong) BXTextField *bx_oldTextField;

@property (nonatomic, strong) BXTextField *bx_newPWDTextField;

@property (nonatomic, strong) BXTextField *bx_newTwoPWDTextField;

@property (nonatomic, assign) BOOL bx_didSetupConstraints;
@end

@implementation BXChangePWDViewController

- (void)dealloc
{
    BXLogInfo(@"%s",__func__);
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.preferredContentSize = [self orientationStatus] ? CGSizeMake(ScreenWidth, ScreenWidth) : CGSizeMake(ScreenWidth, ScreenHeight);
    }
    return self;
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [self notifitionSatatus];
}

-(void)notifitionSatatus{
    [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(statusBarOrientationChange:) name:UIApplicationDidChangeStatusBarOrientationNotification object:nil];
}
-(void)statusBarOrientationChange:(NSNotification*)notification{
    self.preferredContentSize = [self orientationStatus] ? CGSizeMake(ScreenWidth, ScreenWidth) : CGSizeMake(ScreenWidth, ScreenHeight);
    [self.bx_baseframeView autoSetDimensionsToSize:[self orientationStatus] ? CGSizeMake(ScreenWidth, ScreenWidth) : CGSizeMake(ScreenWidth, ScreenWidth)];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setupViews];
    
    self.view.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(screenTap:)];
    tap.cancelsTouchesInView = NO;
    [self.view addGestureRecognizer:tap];
}

- (void)setupViews {
    self.view.backgroundColor = UIColor.clearColor;
    
    [self.view addSubview:self.bx_baseframeView];
    
    [self.bx_baseframeView addSubview:self.bx_baseHeaderView];
    [self.bx_baseHeaderView bx_baseHeaderViewSetString:@"修改密码"];
    @weakify(self)
    self.bx_baseHeaderView.bx_leftCallback = ^{
        @strongify(self)
        [self backAction:nil];
    };
    
    [self.bx_baseframeView addSubview:self.bx_baseBackView];
    
    [self.bx_baseBackView addSubview:self.bx_oldTextField];
    [self.bx_baseBackView addSubview:self.bx_newPWDTextField];
    [self.bx_baseBackView addSubview:self.bx_newTwoPWDTextField];
   
    [self.bx_baseNextBtn setTitle:@"确定" forState:UIControlStateNormal];
    [self.bx_baseNextBtn addTarget:self action:@selector(bx_baseNextBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.bx_baseframeView addSubview:self.bx_baseNextBtn];
    
    [self.view updateConstraintsIfNeeded];
}

- (BXTextField *)bx_oldTextField {
    if (!_bx_oldTextField) {
        _bx_oldTextField = [BXTextField textFieldWithTitle:nil placeHolder:@"请输入原始密码"];
        _bx_oldTextField.backgroundColor = [UIColor whiteColor];
        _bx_oldTextField.borderStyle = UITextBorderStyleNone;
        _bx_oldTextField.font = BXSystemFont(14);
        _bx_oldTextField.textColor = BXHexColor(0x333333);
        _bx_oldTextField.keyboardType = UIKeyboardTypeASCIICapable;
        _bx_oldTextField.clearsOnBeginEditing = YES;
        _bx_oldTextField.secureTextEntry = YES;
        _bx_oldTextField.rightViewMode = UITextFieldViewModeAlways;
    }
    return _bx_oldTextField;
}

- (UITextField *)bx_newPWDTextField {
    if (!_bx_newPWDTextField) {
        _bx_newPWDTextField = [BXTextField textFieldWithTitle:nil placeHolder:@"请输入新密码"];
        _bx_newPWDTextField.backgroundColor = [UIColor whiteColor];
        _bx_newPWDTextField.borderStyle = UITextBorderStyleNone;
        _bx_newPWDTextField.font = BXSystemFont(14);
        _bx_newPWDTextField.textColor = BXHexColor(0x333333);
        _bx_newPWDTextField.keyboardType = UIKeyboardTypeASCIICapable;
        _bx_newPWDTextField.clearsOnBeginEditing = YES;
        _bx_newPWDTextField.secureTextEntry = YES;
        _bx_newPWDTextField.rightViewMode = UITextFieldViewModeAlways;
    }
    return _bx_newPWDTextField;
}

- (BXTextField *)bx_newTwoPWDTextField {
    if (!_bx_newTwoPWDTextField) {
        _bx_newTwoPWDTextField = [BXTextField textFieldWithTitle:nil placeHolder:@"请再次输入新密码"];
        _bx_newTwoPWDTextField.backgroundColor = [UIColor whiteColor];
        _bx_newTwoPWDTextField.borderStyle = UITextBorderStyleNone;
        _bx_newTwoPWDTextField.font = BXSystemFont(14);
        _bx_newTwoPWDTextField.textColor = BXHexColor(0x333333);
        _bx_newTwoPWDTextField.keyboardType = UIKeyboardTypeASCIICapable;
        _bx_newTwoPWDTextField.clearsOnBeginEditing = YES;
        _bx_newTwoPWDTextField.secureTextEntry = YES;
        _bx_newTwoPWDTextField.rightViewMode = UITextFieldViewModeAlways;
    }
    return _bx_newTwoPWDTextField;
}

- (void)updateViewConstraints {
    if (!_bx_didSetupConstraints) {
        [self.bx_baseframeView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0];
        [self.bx_baseframeView autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:0];
        [self.bx_baseframeView autoSetDimensionsToSize:[self orientationStatus] ? CGSizeMake(ScreenHeight, ScreenHeight) : CGSizeMake(ScreenWidth, ScreenWidth)];
        
        [self.bx_baseHeaderView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0];
        [self.bx_baseHeaderView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:0];
        [self.bx_baseHeaderView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:0];
        [self.bx_baseHeaderView autoSetDimension:ALDimensionHeight toSize:40];
        
        [self.bx_baseBackView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:14];
        [self.bx_baseBackView autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:14];
        [self.bx_baseBackView autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_baseHeaderView withOffset:14];
        [self.bx_baseBackView autoSetDimension:ALDimensionHeight toSize:120];
        
        NSArray *tfs = @[self.bx_oldTextField, self.bx_newPWDTextField,self.bx_newTwoPWDTextField];
        [tfs.firstObject autoPinEdgeToSuperviewEdge:ALEdgeLeading];
        [tfs.firstObject autoPinEdgeToSuperviewEdge:ALEdgeTrailing];
        [tfs autoMatchViewsDimension:ALDimensionWidth];
        [tfs autoDistributeViewsAlongAxis:ALAxisVertical alignedTo:ALAttributeVertical withFixedSpacing:0];
        
        NSMutableArray *lines = [NSMutableArray array];
        for (NSInteger index = 0; index < 2; index++) {
            UIView *bx_line = [[UIView alloc] init];
            [bx_line setBackgroundColor:BXHexColor(0xDEDEDE)];
            [self.bx_baseBackView addSubview:bx_line];
            [lines addObject:bx_line];
        }
        [lines.firstObject autoPinEdgeToSuperviewEdge:ALEdgeLeading];
        [lines.firstObject autoPinEdgeToSuperviewEdge:ALEdgeTrailing];
        
        [lines autoMatchViewsDimension:ALDimensionWidth];
        [lines autoDistributeViewsAlongAxis:ALAxisVertical alignedTo:ALAttributeVertical withFixedSize:0.5];
        
        [self.bx_baseNextBtn autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:14];
        [self.bx_baseNextBtn autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:14];
        [self.bx_baseNextBtn autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_baseBackView withOffset:14];
        [self.bx_baseNextBtn autoSetDimension:ALDimensionHeight toSize:40];
        
        _bx_didSetupConstraints = YES;
    }
    [super updateViewConstraints];
}

-(void)backAction:(UIButton *)sender{
    [self bx_hideWithCompletion:^{
        
    }];
}

-(void)bx_baseNextBtnAction:(UIButton *)sender{
    NSString *oldPwd = self.bx_oldTextField.text;
    NSString *newPwd = self.bx_newPWDTextField.text;
    
    if (self.bx_oldTextField.text.length == 0) {
            [BXMBProgressHUD bx_showMessage:@"请输入原始密码"];
            return;
        }
        if (self.bx_newPWDTextField.text.length == 0) {
            [BXMBProgressHUD bx_showMessage:@"请输入新密码"];
            return;
        }
        if (self.bx_newTwoPWDTextField.text.length == 0) {
            [BXMBProgressHUD bx_showMessage:@"请再次输入新密码"];
            return;
        }
        
        if (![NSString bx_checkValidityForPassword:self.bx_oldTextField.text]) {
            [BXMBProgressHUD bx_showMessage:@"请输入6-20位"];
            return;
        }
        if (![NSString bx_checkValidityForPassword:self.bx_newPWDTextField.text]) {
            [BXMBProgressHUD bx_showMessage:@"请输入6-20位"];
            return;
        }
        if (![NSString bx_checkValidityForPassword:self.bx_newTwoPWDTextField.text]) {
            [BXMBProgressHUD bx_showMessage:@"请输入6-20位"];
            return;
        }
        
        if (self.bx_newPWDTextField.text.length != self.bx_newTwoPWDTextField.text.length) {
            [BXMBProgressHUD bx_showMessage:@"请保持新密码一致"];
            return;
        }
    
    [self.view endEditing:YES];
    
    @weakify(self)
    [BXEvent doUpdateUserOldPassword:oldPwd newPassword:newPwd complement:^(id obj, NSError *error) {
        @strongify(self)
        if (!error) {
            BXUser *user = [BXMobileManager shareManager].currentUser;
            [user save];
            [user recordAccount:user.userId password:newPwd];
            [BXMBProgressHUD bx_showMessage:@"密码修改成功"];
            [self bx_hideWithCompletion:nil];
        }else{
            [BXMBProgressHUD bx_showMessage:error.localizedDescription delay:YES];
        }
    }];
}

- (void)screenTap:(UITapGestureRecognizer *)gesture {
    if ([self.bx_oldTextField isFirstResponder] || [self.bx_newPWDTextField isFirstResponder] || [self.bx_newTwoPWDTextField isFirstResponder]) {
        [self.view endEditing:YES];
        return;
    }
    
    CGPoint p = [gesture locationInView:self.view];
    if (!CGRectContainsPoint(self.bx_baseframeView.frame, p)) {
        [self dismissToRootViewController];
    }
}

-(void)dismissToRootViewController{
    UIViewController *vc = self;
    while (vc.presentingViewController) {
        vc = vc.presentingViewController;
    }
    [vc dismissViewControllerAnimated:YES completion:nil];
}

@end
