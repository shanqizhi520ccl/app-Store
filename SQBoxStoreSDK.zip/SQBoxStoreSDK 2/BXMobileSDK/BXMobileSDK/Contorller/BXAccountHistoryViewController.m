//
//  BXAccountHistoryViewController.m
//  BXMobileSDK
//
//  Created by BD-Benjamin on 2020/8/3.
//  Copyright © 2020 Gavin. All rights reserved.
//

#import "BXAccountHistoryViewController.h"
#import "BXHistoryCell.h"
#import "BXUser.h"

@interface BXAccountHistoryViewController ()<UITableViewDelegate, UITableViewDataSource>
@property (nonatomic, strong) UIView *bx_navgationBar;
@property (nonatomic, strong) UIImageView *bx_navgationBackgroundImgView;
@property (nonatomic, strong) UILabel *bx_titileLabel;
@property (nonatomic, strong) UIButton *bx_backButton;

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSLayoutConstraint *hightConstraint;
@property (nonatomic, strong) NSArray *users;
@property (nonatomic, assign) BOOL bx_didSetupConstraints;
@end

@implementation BXAccountHistoryViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Do any additional setup after loading the view.
    [self.view addSubview:self.bx_navgationBar];
    [self.bx_navgationBar addSubview:self.bx_navgationBackgroundImgView];
    [self.bx_navgationBar addSubview:self.bx_titileLabel];
    [self.bx_navgationBar addSubview:self.bx_backButton];

    self.users = [BXUser allUsers];
    
    [self.view addSubview:self.tableView];
    [self.view updateConstraintsIfNeeded];
    
    [self.tableView registerClass:[BXHistoryCell class] forCellReuseIdentifier:@"BXHistoryCellIdentifier"];
}

- (void)updateViewConstraints {
    if (!_bx_didSetupConstraints) {
        // 导航栏
        [self.bx_navgationBar autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero excludingEdge:ALEdgeBottom];
        [self.bx_navgationBar autoSetDimension:ALDimensionHeight toSize:40];
        
        [self.bx_navgationBackgroundImgView autoPinEdgesToSuperviewEdges];
        
        [self.bx_backButton autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:6];
        [self.bx_backButton autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
        [self.bx_backButton  autoSetDimensionsToSize:CGSizeMake(36, 36)];
        
        [self.bx_titileLabel autoPinEdge:ALEdgeLeading toEdge:ALEdgeTrailing ofView:self.bx_backButton withOffset:0];
        [self.bx_titileLabel autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
        
        [self.tableView autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.bx_navgationBar withOffset:10];
        [self.tableView autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:20];
        [self.tableView autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:20];
        [self.tableView autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:10 relation:NSLayoutRelationGreaterThanOrEqual];
    
        [NSLayoutConstraint autoSetPriority:UILayoutPriorityDefaultHigh forConstraints:^{
            self.hightConstraint = [self.tableView autoSetDimension:ALDimensionHeight toSize:0];
        }];
        
        _bx_didSetupConstraints = YES;
    }
    [super updateViewConstraints];
}

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.backgroundColor = BXTextFieldBackgroundColor;
        _tableView.backgroundView = nil;
        _tableView.dataSource= self;
        _tableView.delegate = self;
        _tableView.estimatedRowHeight = 0;
        _tableView.estimatedSectionFooterHeight = 0;
        _tableView.estimatedSectionFooterHeight = 0;
        _tableView.sectionFooterHeight = 0;
        _tableView.sectionHeaderHeight = 0;
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.separatorColor = [UIColor whiteColor];
        _tableView.delaysContentTouches = NO;
        _tableView.layer.cornerRadius = 4;
    }
    return _tableView;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSInteger number = self.users.count;
    
    if (self.hightConstraint) {
        [UIView animateWithDuration:0.25 animations:^{
            self.hightConstraint.constant = MIN(number*50, (floor((self.view.bounds.size.height-40)/50))*50);
        }];
    }
    return number;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    BXHistoryCell *cell = [tableView dequeueReusableCellWithIdentifier:@"BXHistoryCellIdentifier" forIndexPath:indexPath];
    BXUser *user = [self.users objectAtIndex:indexPath.row];
    cell.titleLabel.text = user.userName ? user.userName : user.userId;
    cell.accessoryView.tag = indexPath.row;
    [(UIButton *)(cell.accessoryView) addTarget:self action:@selector(accessoryButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
    
    if (user.zoneName) {
        NSDateFormatter *format = [[NSDateFormatter alloc] init];
        format.dateFormat = @"yyyy-MM-dd";
        NSString *loginTime = [format stringFromDate:user.localLoginTime];
        cell.subTitleLabel.text = [NSString stringWithFormat:@"登录区服: %@ %@",user.zoneName, loginTime];
    }else{
        NSDateFormatter *format = [[NSDateFormatter alloc] init];
        format.dateFormat = @"yyyy-MM-dd";
        NSString *loginTime = [format stringFromDate:user.localLoginTime];
        cell.subTitleLabel.text = [NSString stringWithFormat:@"登录区服: %@", loginTime];
    }
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 50;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 0.0001;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 0.0001;
}

- (void)accessoryButtonTapped:(id)sender {
    if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectItem:)]) {
        BXUser *user = [self.users objectAtIndex:[(UIButton *)sender tag]];
        [self.delegate didSelectItem:user];
        [self bx_hideWithCompletion:^{
        }];
    }
}

- (void)backEvent:(id)sender {
    [self bx_hideWithCompletion:^{
    }];
}

#pragma mark - Property

//nav
- (UIView *)bx_navgationBar {
    if (!_bx_navgationBar) {
        _bx_navgationBar = [[UIView alloc] init];
    }
    return _bx_navgationBar;
}

- (UIButton *)bx_backButton {
    if (!_bx_backButton) {
        _bx_backButton = [UIButton buttonWithType:UIButtonTypeCustom];
        UIImage *aImage = [UIImage imageNamed:@"nav_back" inBundle:BXMobileSDKBundle compatibleWithTraitCollection:nil];
        [_bx_backButton setImage:aImage forState:UIControlStateNormal];
        [_bx_backButton addTarget:self action:@selector(backEvent:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _bx_backButton;
}

- (UILabel *)bx_titileLabel {
    if (!_bx_titileLabel) {
        _bx_titileLabel = [[UILabel alloc] init];
        [_bx_titileLabel setText:@"历史账号"];
        [_bx_titileLabel setTextColor:BXHexColor(0x333333)];
        [_bx_titileLabel setFont:BXBoldSystemFont(14)];
    }
    return _bx_titileLabel;
}

- (UIImageView *)bx_navgationBackgroundImgView {
    if (!_bx_navgationBackgroundImgView) {
        _bx_navgationBackgroundImgView = [[UIImageView alloc] init];
    }
    return _bx_navgationBackgroundImgView;
}

@end
